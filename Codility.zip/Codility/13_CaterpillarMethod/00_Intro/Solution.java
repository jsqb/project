public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{6, 2, 7, 4, 1, 3, 6};
		Test.assertEquals(true, caterpillarMethod(A, 12));

		A = new int[]{6, 2, 7, 4, 1, 3, 6};
		Test.assertEquals(11, triangles(A));
		Test.assertEquals(11, trianglesO3(A));
		Test.printResults();

	}

	// 13.1: Caterpillar in O(n) time complexity.
	private static boolean caterpillarMethod(int[] A, int s) {
		int n = A.length, front = 0, total = 0;

		for (int back=0; back<n; back++) {
			while (front < n && (total + A[front]) <= s) {
				total += A[front];
				//System.out.println("total="+total+", A["+front+"]="+A[front]);
				front++;
			}

			if (total == s) return true;
			total -= A[back];
		}
		return false;
	}

	// 13.2: The number of triangles in O(n^2).
	private static int triangles(int[] A) {
		int n = A.length, result = 0;

		for (int x=0; x<n; x++) {
			int z = 0;
			for (int y=x+1; y<n; y++) {
				while (z < n && (A[x] + A[y] > A[z])) z++;
System.out.println("x="+x+", y="+y+", z="+z+", result="+result);
				result += z - y -1;
			}
		}
		return result;
	}

	// 13.2: The number of triangles in O(n^3).
	private static int trianglesO3(int[] A) {
		int n = A.length, result = 0;

		for (int x=0; x<n-2; x++) {
			for (int y=x+1; y<n-1; y++) {
				for (int z=y+1; z<n; z++) {
					if (A[x] + A[y] > A[z]) {


System.out.println("x="+x+", y="+y+", z="+z+", result="+result);


						
						}result++;
				}
			}
		}
		return result;
	}

}
