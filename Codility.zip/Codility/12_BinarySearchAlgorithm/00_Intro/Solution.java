public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{12,15,15,19,24,31,53,59,60};
		Test.assertEquals(5, binarySearch(A,31));
		Test.printResults();

	}

	// 12.1: Binary search in O(log n).
	private static int binarySearch(int[] A, int x) {
		int n = A.length;
		int beg = 0;
		int end = n - 1;
		int result = -1;

		while (beg <= end) {
			int mid = (beg + end) / 2;
			if (A[mid] <= x) {
				beg = mid + 1;
				result = mid;
			} else {
				end = mid - 1;
			}
		}

		return result;
	}

}
