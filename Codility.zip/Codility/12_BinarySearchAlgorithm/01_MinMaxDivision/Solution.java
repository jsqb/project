public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{2,1,5,1,2,2,2};
		Test.assertEquals(6, solution(3,5,A));
		Test.assertEquals(6, solution0(3,5,A));
		Test.printResults();
	}

	// given integers K, M and a non-empty zero-indexed array A consisting of N integers,
	// returns the minimal large sum.

	// time:O(N*log(N*M)), space:O(1)
	// Correctness: 0%
	// Performance: 0%
	// Task score: 0%
	private static int solution(int K, int M, int[] A) {
		int N = A.length;
		int max = 0, largeSum = 0;
 
    for (int i=K-1; i<N; i++) largeSum += A[i];
 
    for (int i=0; i<N; i++) {
			if (A[i] > max) max = A[i];
		}
 
    if (K == N) return max;
    largeSum= Math.max(max, largeSum);
 
    int b = max;
    int e = largeSum;
    if (e < b) {
			// swap
			int tmp = e;
			e = b;
			b = tmp;
		}
		int largeSumR = e;
 
    // Bin Search
		while (b <= e) {
			largeSum = (b+e)/2;
			if (testLargeSum(A, K, largeSum))  {
				e = largeSum -1;
				largeSumR = largeSum;
			} else {
				b = largeSum +1;
			}
		}
    return largeSumR;
	}

	// check to see if A can be divided into K blocks
	// with maximum sum of each block is less than largeSum
	private static boolean testLargeSum(int[] A, int K, int largeSum) {
		int N = A.length;
		int j=0;
		long sum = 0;

    for (int i=0; i<N; i++) {
			sum += A[i];
			if (sum > largeSum) {
				j++;
				if (j > (K-1)) return false;
				sum = A[i];
			}
		}

		return true;
	}

	private static int solution0(int K, int M, int[] A) {
		// each time given an expected minimum sum 'expMinSum',
		// then get the minimum group number 'mgn' we should divide into to meet the 'expMinSum'
		// if 'mgn' <= 'K', then try to decrease 'expMinSum'; else versa;

		int N = A.length, left = 0, right = 0;
		for (int i=0; i<N; i++) {
			if (A[i] > left) left = A[i]; // max
			right += A[i]; // sum
		}

		while (left <= right) {
			int expMinSum = (right-left)/2+left;
			int minGrpNum = getMinimumGroupNumber(A, expMinSum);
			if (minGrpNum <= K) { // we can decrease 'expMinSum'
				right = expMinSum-1;
			} else { // we should increase 'expMinSum' to decrease 'minGrpNum' 
				left = expMinSum+1;
			}
		}
		return left;
	}

	private static int getMinimumGroupNumber(int[] A, int expMinSum) {
		int minGrpNum = 0, sum = 0;

		for (int a : A) {
			sum += a;
			if (sum > expMinSum) {
				sum = a;
				minGrpNum++;
			}
		}

    if (sum > 0) minGrpNum++;

		return minGrpNum;
	}

}
