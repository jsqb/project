function solution(A) {
    // you can use console.log for debugging purposes, i.e.
    // console.log('this is debug message');
    // write your code in JavaScript (ECMA-262, 5th edition)

	var N = A.length, min = Number.MAX_VALUE;
	for (var i=1; i<(N-1); i++) {
		var a = 0, b = 0;
		for (var j=0; j<N; j++) {
			if (j < i) {
				a += A[j];
			} else {
				b += A[j];
			}
		}
		var diff = Math.abs(a - b);
		if (diff < min) min = diff;
	}

	return min;
}
