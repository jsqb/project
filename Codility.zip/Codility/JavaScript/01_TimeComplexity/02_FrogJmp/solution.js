function solution(X, Y, D) {
	return X >= Y ? 0 : (((Y - X - 1) / D)|0) + 1;
}
