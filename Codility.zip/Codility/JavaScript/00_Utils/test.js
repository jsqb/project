function debug(message) {
	var t = document.createElement("div");
	t.innerHTML = message;
	document.body.appendChild(t);
}

function test(exp, act) {
	debug((exp==act?"Passed":"FAILED") + " Expected=("+exp+") Actual=("+act+")");
}
