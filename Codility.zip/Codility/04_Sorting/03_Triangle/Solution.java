public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{10,2,5,1,8,20};
		Test.assertEquals(1, solution(A));
		A = new int[]{10,50,5,1};
		Test.assertEquals(0, solution(A));
		A = new int[]{10,50};
		Test.assertEquals(0, solution(A));
		A = new int[]{10,2,-2,5,1,8,20,-1};
		Test.assertEquals(1, solution(A));
		A = new int[]{1,2,2}; // simple test case
		Test.assertEquals(1, solution(A));
		A = new int[]{Integer.MAX_VALUE/2,Integer.MAX_VALUE,Integer.MAX_VALUE}; // overflow
		Test.assertEquals(1, solution(A));
		Test.printResults();
	}

	// given a zero-indexed array A consisting of N integers,
	// returns 1 if there exists a triangular triplet for this array and returns 0 otherwise.

	// Once the A is sorted, we know A[i] <= A[i+1] <= A[i+2], so A[i] < A[i+1] + A[i+2]
	// Similarly, A[i+1] < A[i] + A[i+2].
	// We only need to check A[i+2] < A[i] + A[i+1].

	// O(N*log(N))
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length;
		if (N < 3) return 0;

		java.util.Arrays.sort(A);

		for (int i=0; i<N-2; i++) {
			//if (A[i] >= 0 && A[i+2] < A[i] + A[i+1]) return 1; // overflow happens when in-values are over MAX_VALUE/2
			if (A[i] >= 0 && A[i+2] - A[i+1] < A[i]) return 1;
		}
		return 0;
	}
}
