public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{-3,1,2,-2,5,6};
		Test.assertEquals(60, solution(A));
		A = new int[]{-100,-99,0,1};
		Test.assertEquals(9900, solution(A));
		Test.printResults();
	}

	// given a non-empty zero-indexed array A,
	// returns the value of the maximal product of any triplet.
	// N is an integer within the range [3..100,000];

	// e.g. [0..100] max=> 98*99*100
	//   [-100..100] max=> -100*-99*100

	// O(N*log(N))
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length;
		java.util.Arrays.sort(A);

		if (A[0] < 0 && A[1] < 0) {
			return Math.max(A[0] * A[1] * A[N-1], A[N-3] * A[N-2] * A[N-1]);
		}
		return A[N-3] * A[N-2] * A[N-1];
	}
}
