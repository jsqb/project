public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{1,5,2,1,4,0};
		Test.assertEquals(11, solution(A));
		Test.printResults();
	}

	// given an array A describing N discs as explained above,
	// returns the number of pairs of intersecting discs.

	// O(N*log(N))
	// Correctness: 87%
	// Performance: 75%
	// Task score: 81%
	private static int solution(int[] A) {
		int N = A.length, result = 0;
		int[] dps = new int[N]; // start
		int[] dpe = new int[N]; // end

		for (int i=0; i<N; i++) {
			dps[Math.max(0, i - A[i])]++;
			dpe[Math.min(N-1, i + A[i])]++;
		}

//		System.out.print("dps ");
//		for (int i=0; i<N; i++) {
//			System.out.print("["+dps[i]+"]");
//		}
//		System.out.println();
//		System.out.print("dpe ");
//		for (int i=0; i<N; i++) {
//			System.out.print("["+dpe[i]+"]");
//		}
//		System.out.println();

		int t = 0;
		for (int i=0; i<N; i++) {
			if (dps[i] > 0) {
				result += t * dps[i];
				result += dps[i] * (dps[i] - 1) / 2; // [sum formula] sum(1..dps[i])
				t += dps[i];
			}
			t -= dpe[i];
		}

		return result;
	}
}
