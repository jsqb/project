public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{2,1,1,2,3,1};
		Test.assertEquals(3, solution(A));
		Test.printResults();
	}

	// given a zero-indexed array A consisting of N integers,
	// returns the number of distinct values in array A.

	// O(N*log(N))
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, count = 1;

		if (N == 0) return 0;

		java.util.Arrays.sort(A);
		//quickSort(A);

		for (int i=1; i<N; i++) {
			if (A[i] != A[i-1]) count++;
		}

		return count;
	}

/******************************
	static void quickSort(int[] a) {
		quickSort(a, 0, a.length-1);
	}

	static void quickSort(int[] a, int low, int high) {
		if (low >= high) return;
		int l = low, h = high;
		int pivot = a[(l + h)/2];

		while (l <= h) {
			while (a[l] < pivot) l++;
			while (a[h] > pivot) h--;

			if (l <= h) {
				int tmp = a[l];
				a[l] = a[h];
				a[h] = tmp;
				l++;
				h--;
			}
		}

		if (low < h) quickSort(a, low, h);
		if (l < high) quickSort(a, l, high);
	}
******************************/
}
