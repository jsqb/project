public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{7,-7,3,5,-2,4,-1};
		Test.assertEquals(10, solution(A));
		Test.printResults();
	}

	// Maximal slice
	// returns the largest sum in a slice.

	// 7.4 O(N)
	// For each position, we compute the largest sum that ends in that position.
	// If we assume that the maximum sum of a slice ending in position i equals max_ending,
	// then the maximum slice ending in position i+1 equals max( 0, max_ending+a(i+1) ).
	private static int solution(int[] A) {
		int max_ending = 0, max_slice = 0;

		for (int a : A) {
			max_ending = Math.max(0, max_ending + a);
			max_slice = Math.max(max_slice, max_ending);
		}
		return max_slice;
	}

/**********************
	// 7.3 O(N^2)
	// Sum of slice: s(p, q) = a(p) + a(p+1) + ...+ a(q).
	// The sum of the slice with one more element s(p, q+1) = s(p, q) + a(q+1).
	private static int solution(int[] A) {
		int N = A.length, max = Integer.MIN_VALUE;

		for (int i=0; i<N; i++) {
			int sum = 0;
			for (int j=i; j<N; j++) {
				sum += A[j];
				if (sum > max) max = sum;
			}
		}

		return max;
	}

	// 7.2 O(N^2) + prefix sums
	private static int solution(int[] A) {
		int N = A.length, max = Integer.MIN_VALUE;

		// This should be done outside this function in real world.
		int[] prefixSums = new int[N];
		if (N > 0) prefixSums[0] = A[0];
		for (int i=1; i<N; i++) {
			prefixSums[i] = prefixSums[i-1] + A[i];
		}

		for (int i=0; i<N; i++) {
			for (int j=i; j<N; j++) {
				int sum = prefixSums[j] - prefixSums[i];
				if (sum > max) max = sum;
			}
		}
		return max;
	}

	// 7.1 O(N^3)
	private static int solution(int[] A) {
		int N = A.length, max = Integer.MIN_VALUE;
		for (int i=0; i<N; i++) {
			for (int j=i; j<N; j++) {
				int sum = 0;
				for (int k=i; k<=j; k++) {
					sum += A[k];
				}
				if (sum > max) max = sum;
			}
		}
		return max;
	}
**********************/
}
