public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,2,-6,4,0};
		Test.assertEquals(5, solution(A));
		A = new int[]{-1,-2,-3};
		Test.assertEquals(-1, solution(A));
		A = new int[]{123};
		Test.assertEquals(123, solution(A));
		A = new int[]{-1,2};
		Test.assertEquals(2, solution(A));
		A = new int[]{-1,-2,-3,1,2,3,-4,-5};
		Test.assertEquals(6, solution(A));
		A = new int[]{1000000,1000000,1000000,1000000,1000000};
		Test.assertEquals(5000000, solution(A));
		A = new int[]{-1000000,-1000000,-1000000,-1000000,-1000000};
		Test.assertEquals(-1000000, solution(A));
		A = new int[]{-5,-4,-3,-2,-1}; // growing_negative
		Test.assertEquals(-1, solution(A));
		Test.printResults();
	}

	// given an array A consisting of N integers,
	// returns the maximum sum of any slice of A.

	// integers (P, Q), such that 0 <= P <= Q < N, is called a slice of array A.
	// The sum of a slice (P, Q) is the total of A[P] + A[P+1] + ... + A[Q]

	// time:O(N), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, maxEnding = 0,
		    maxSlice = Integer.MIN_VALUE, min = Integer.MIN_VALUE;
		for (int a : A) {
			if (a >= min && maxEnding < 0) maxEnding = 0; // throw away previous negative values
			if (a > min) min = Math.min(0, a); // for growing_negaive case
			maxEnding = maxEnding + a;
			maxSlice = Math.max(maxSlice, maxEnding);
		}
		return maxSlice;
	}

}
