public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{23171, 21011, 21123, 21366, 21013, 21367};
		Test.assertEquals(356, solution(A));
		A = new int[]{2,4,1,3};
		Test.assertEquals(2, solution(A));
		A = new int[0];
		Test.assertEquals(0, solution(A));
		A = new int[]{23171};
		Test.assertEquals(0, solution(A));
		A = new int[]{100,99,98,97,96,95};
		Test.assertEquals(0, solution(A));
		Test.printResults();
	}

	// given a zero-indexed array A consisting of N integers
	// containing daily prices of a stock share for a period of N consecutive days,
	// returns the maximum possible profit from one transaction during this period.
	// The function should return 0 if it was impossible to gain any profit.

	// time:O(N), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, min = Integer.MAX_VALUE, profit = 0;
		for (int i=0; i<N-1; i++) {
			if (A[i] < min) min = A[i];
			int tmp = A[i+1] - min;
			if (tmp > profit) profit = tmp;
//System.out.println("Day["+i+"-"+(i+1)+"] min("+min+") sell("+A[i+1]+") profit("+profit+")");
		}
		return profit;
	}

/***************************
	// time:O(N^2), space:O(1)
	private static int solution(int[] A) {
		int N = A.length, max = 0;
		for (int i=0; i<N-1; i++) {
			for (int j=i+1; j<N; j++) {
				int profit = A[j] - A[i];
				if (profit > max) max = profit;
			}
		}
		return max;
	}
***************************/

}
