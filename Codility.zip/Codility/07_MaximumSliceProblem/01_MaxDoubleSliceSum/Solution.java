public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,2,6,-1,4,5,-1,2};

		Test.assertEquals(17, solution(A));
		A = new int[]{1,1,0,10,-100,10,0};
		Test.assertEquals(21, solution(A));
		A = new int[]{-1,-1,-3,-4};
		Test.assertEquals(0, solution(A));
		A = new int[]{1,2,3,4};
		Test.assertEquals(3, solution(A));
		A = new int[]{1,2,3};
		Test.assertEquals(0, solution(A));
		A = new int[]{-56,-78,90,-98,76,-54};
		Test.assertEquals(166, solution(A));
 		A = new int[]{3,-12,7,-6,-12,25,-5}; // same min value twise
		Test.assertEquals(26, solution(A));
		Test.printResults();
	}

	// Maximal sum of double slice
	// given a non-empty zero-indexed array A consisting of N integers,
	// returns the maximal sum of any double slice.
	// 0 <= X < Y < Z < N,

	// [Approach]
	// find a max-slice(X,Z) and min value A[Y], then calculate max-slice(X,Z) - A[Y]
	// to do this, max_ending must include a min value but exclude all old min values.

	// O(N)
	// Correctness: 100%
	// Performance: 28%
	// Task score: 61%
	private static int solution(int[] A) {
		int N = A.length, min = Integer.MAX_VALUE,
		    actual_max_ending  = 0, // max ending excluding negative min values
		    max_ending_inc_min = 0, // max ending including prevous negative min value
		    max_slice = 0;

		for (int i=1; i<N-1; i++) {
			if (A[i] <= min) {
				min = A[i];
				max_ending_inc_min = actual_max_ending; // throw away previous min value from max_ending
			}
			max_ending_inc_min = max_ending_inc_min + A[i];
			actual_max_ending = Math.max(0, actual_max_ending + A[i]);
			max_slice = Math.max(max_slice, max_ending_inc_min - min);
		}
		return max_slice;
	}

/************************
	// time:O(N*3)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, max = 0;
		if (N == 3) return 0;

		int[] prefMaxEnding = new int[N], prefMaxStarting = new int[N];

		// generate prefix sums
		for (int i=1; i<N-1; i++) {
			prefMaxEnding[i] = Math.max(0, prefMaxEnding[i-1] + A[i]);
		}
		for (int i=N-2; i>0; i--) {
			prefMaxStarting[i] = Math.max(0, prefMaxStarting[i+1] + A[i]);
		}

		for (int i=1; i<N-1; i++) {
			int sum = prefMaxEnding[i-1] + prefMaxStarting[i+1];
			if (sum > max) max = sum;
		}

		return max;
	}
************************/
}
