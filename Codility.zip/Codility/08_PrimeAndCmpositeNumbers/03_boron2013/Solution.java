public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{1,5,3,4,3,4,1,2,3,4,6,2};
		Test.assertEquals(3, solution(A));
		Test.assertEquals(3, solution0(A));
		Test.assertEquals(3, solution_fast(A));
		Test.assertEquals(3, solution_gold(A));

		A = new int[]{1,10,4,8,10,9,1,8,4,1,9,0};
		Test.assertEquals(3, solution(A));
		Test.assertEquals(3, solution0(A));
		Test.assertEquals(3, solution_fast(A));
		Test.assertEquals(3, solution_gold(A));
		Test.printResults();
	}

	// given a non-empty zero-indexed array A of N integers,
	// returns the maximum number of flags that can be set on the peaks of the array.

//packed_peaks 
//possible to set floor(sqrt(N))+1 flags

	// time:O(N), space:O(N)
	// Correctness: 87% - over time limit
	// Performance: 100%
	// Task score: 93%
	private static int solution(int[] A) {
		int N = A.length, peakCount = 0, max = 0;
		int distsCount = 0;
		int[] dists = new int[N]; // distance between flags

		int prevPeakIdx = -1;
		for (int i=1; i<N-1; i++) {
			if (A[i-1] < A[i] && A[i] > A[i+1]) {
				peakCount++;
				if (prevPeakIdx != -1) dists[distsCount++] = i - prevPeakIdx; // distance from the prev peak
				prevPeakIdx = i;
			}
		}
		if (peakCount < 2) return peakCount;

		for (int K=(int)Math.sqrt(N)/*peakCount*/; K>1 && K>max; K--) { // try to take K frags
			int sum = 0, flagCount = 1;
			for (int i=0; i<distsCount; i++) {
				sum += dists[i];
				if (sum >= K) {
					flagCount++;
					sum = 0;
				}
			}
			if (flagCount > max) max = Math.min(flagCount, K); // K is the max limit.
		}

		return max;
	}


	private static int solution0(int[] A) {
		int A_len = A.length;
    int[] next_peak = new int[A_len];
		for (int i=0; i<A_len; i++) {
			next_peak[i] = -1;
		}

    int peaks_count = 0;
    int first_peak = -1;

    // Generate the information, where the next peak is.
    for (int index=A_len-2; index>0; index--) {
        if (A[index] > A[index+1] && A[index] > A[index-1]) {
            next_peak[index] = index;
            peaks_count += 1;
            first_peak = index;
        } else {
            next_peak[index] = next_peak[index+1];
        }
    }
    if (peaks_count < 2) {
        // There is no peak or only one.
        return peaks_count;
    }

    int max_flags = 1;
    for (int min_distance=(int)Math.sqrt(A_len); min_distance>1; min_distance--) {
        // Try for every possible distance.
        int flags_used = 1;
        int flags_have = min_distance-1; // Use one flag at the first peak
        int pos = first_peak;
        while (flags_have > 0) {
            if (pos + min_distance >= A_len-1) {
                // Reach or beyond the end of the array
                break;
            }
            pos = next_peak[pos+min_distance];
            if (pos == -1) {
                // No peak available afterward
                break;
            }
            flags_used += 1;
            flags_have -= 1;
				}
        max_flags = Math.max(max_flags, flags_used);
    }
    return max_flags;
	}

	// Fast Solution
	private static int solution_fast(int[] A) {
		int N = A.length;

		// Create an array of peaks
		boolean[] peaks = new boolean[N];
		for (int i=1; i<N-1; i++) {
			if (A[i] > Math.max(A[i-1], A[i+1])) {
				peaks[i] = true;
			}
		}

		for (int K=(int)Math.sqrt(N); K>1; K--) { // try to take K frags
			if (check(K, A, peaks)) return K;
		}
		return 0;
	}

	// Check whether x flags can be set
	private static boolean check(int x, int[] A, boolean[] peaks) {
		int N = A.length;
		int flags = x, pos = 0;
		while (pos < N && flags > 0) {
			if (peaks[pos]) {
				flags -= 1;
				pos += x;
			} else {
				pos += 1;
			}
		}
		return flags == 0;
	}


	// Golden Solution
	// time:O(N), space:O(N)
	// Correctness: 87% - possible to set floor(sqrt(N))+1 flags
	// Performance: 100%
	// Task score: 93%
	private static int solution_gold(int[] A) {
		int N = A.length;

		// Create an array of peaks
		boolean[] peaks = new boolean[N];
		for (int i=1; i<N-1; i++) {
			if (A[i] > Math.max(A[i-1], A[i+1])) {
				peaks[i] = true;
			}
		}

		// Next peak
		int[] next = new int[N];
		next[N-1] = -1;
		for (int i=N-2; i>=0; i--) {
			if (peaks[i]) {
				next[i] = i;
			} else {
				next[i] = next[i+1];
			}
		}

		// Solution
		int i = 1, result = 0;
		while (i * i <= N) {
			int pos = 0, num = 0;
			while (pos < N && num < i) {
				pos = next[pos];
				if (pos == -1) break;
				num += 1;
				pos += i;
			}
			result = Math.max(result, num);
			i += 1;
		}
		return result;
	}

}
