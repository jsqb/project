public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{1,2,3,4,3,4,1,2,3,4,6,2};
		Test.assertEquals(3, solution(A));

		A = new int[]{1,2,1,2,1,2,1,2,1,2,1,2};
		Test.assertEquals(4, solution(A));

		A = new int[]{1,2,1,2,1,2,1,2,1,2,1};
		Test.assertEquals(1, solution(A));

		A = new int[]{4,6,6,1,5,2,3,1};
		Test.assertEquals(1, solution(A));

/**********
		A = new int[8];
for (int j=0;j<1000;j++) {
		for (int i=0; i<A.length; i++) {
			A[i] = (int)(Math.random() * 6 + 1);
		}
		if (solution0(A) != solution(A)) {
System.out.println(java.util.Arrays.toString(A));
		}
//		Test.assertEquals(1, solution0(A));
//		Test.assertEquals(1, solution(A));
//		Test.printResults();
	}
******************/
}

	// returns the maximum number of blocks into which A can be divided.
	// If A cannot be divided into some number of blocks, the function should return 0.

	// time:O(N*log(log(N))), space:O(N)
	// Correctness: 90%
	// Performance: N/A
	// Task score: 90%
	private static int solution(int[] A) {
		int N = A.length, peakCount = 0, max = 0;
		boolean[] peaks = new boolean[N];

		for (int i=1; i<N-1; i++) {
			if (A[i-1] < A[i] && A[i] > A[i+1]) {
				peakCount++;
				peaks[i] = true;
			}
		}
		if (peakCount == 0) return 0;

		int minBlockSize = N/peakCount + (N % peakCount == 0 ? 0 : 1);

		int i = 1;
		while (i * i < N) {
			if (N % i == 0) { // i is divisor of N
				int blockSize = N/i;
				if (i > max && blockSize >= minBlockSize && containPeak(peaks, blockSize)) max = i;

				int numOfBlks = N / i;
				if (numOfBlks > max && i >= minBlockSize && containPeak(peaks, i)) {
					max = numOfBlks; // this must be the biggist number
					break;
				}
			}
			i++;
		}
		return max;
	}

	private static boolean containPeak(boolean[] peaks, int blockSize) {
		int N = peaks.length;
		for (int i=0; i<N; i+=blockSize) {
			boolean foundPeak = false;
			for (int j=i; j<i+blockSize; j++) {
				if (peaks[j]) {
					foundPeak = true;
					break;
				}
			}
			if (!foundPeak) return false;
		}
		return true;
	}

}
