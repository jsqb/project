public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(2, countDivisors(13)); // 1, 13
		Test.assertEquals(4, countDivisors(14)); // 1,2,7,14
		Test.assertEquals(8, countDivisors(24)); // 1,2,3,4,6,8,12,24
		Test.assertEquals(9, countDivisors(36)); // 1,2,3,4,6,9,12,18,36
		Test.printResults();

		Test.assertEquals(true, testPrimality(1));
		Test.assertEquals(true, testPrimality(2));
		Test.assertEquals(true, testPrimality(3));
		Test.assertEquals(false, testPrimality(4));
		Test.assertEquals(true, testPrimality(5));
		Test.assertEquals(false, testPrimality(6));
		Test.assertEquals(true, testPrimality(7));
		Test.assertEquals(false, testPrimality(8));
		Test.assertEquals(false, testPrimality(9));
		Test.assertEquals(false, testPrimality(10));
		Test.printResults();

		Test.assertEquals(3, reverseCoins(10));
		Test.printResults();
	}

	// Counting the number of divisors
	// 8.1 O(sqrt(N))
	private static int countDivisors(int n) {
		int i = 1, result = 0;

		while (i * i < n) {
			if (n % i == 0) result += 2; // (i and n/i; e.g. 1&36, 2&18, 3&12, ...)
			i++;
		}
		if (i * i == n) result++; // (e.g. 6&6)
		return result;
	}

	// Primality test
	// 8.2 O(sqrt(N))
	private static boolean testPrimality(int n) {
		int i = 2;
		while (i * i <= n) {
			if (n % i == 0) return false; // find two divisors (plus 1)
			i++;
		}
		return true;
	}

	// Exercises - Reversing coins
	// 8.3 O(N*log(N))
	private static int reverseCoins(int n) {
		int result = 0;
		int[] coin = new int[n+1];

		for (int i=1; i<n+1; i++) {
			int k = i;
			while (k <= n) {
				coin[k] = (coin[k] + 1) % 2;
				k += i;
			}
			result += coin[i];
		}
		return result;
	}

}
