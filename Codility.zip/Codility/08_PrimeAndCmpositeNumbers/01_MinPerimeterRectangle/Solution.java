public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(22, solution(30));
		Test.assertEquals(28, solution(13));
		Test.assertEquals(18, solution(14));
		Test.assertEquals(20, solution(24));
		Test.assertEquals(24, solution(36));
		Test.printResults();
	}

	// given an integer N,
	// returns the minimal perimeter of any rectangle whose area is exactly equal to N.

	// time:O(sqrt(N)), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int N) {
		int i = 1, divisor = 0;
		while (i * i <= N) {
			if (N % i == 0) divisor = i;
			i++;
		}
		return (divisor + N/divisor)*2;
	}
}
