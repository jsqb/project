import java.util.*;
public class Solution {
	public static void main(String[] args) {
		String S = "CAGCCTA";
		int[] P = new int[]{2,5,0};
		int[] Q = new int[]{4,5,6};
		Test.assertEquals(new int[]{2,4,1}, solution(S,P,Q));
		Test.printResults();
	}

	// given a non-empty zero-indexed string S consisting of N characters
	// and two non-empty zero-indexed arrays P and Q consisting of M integers,
	// returns an array consisting of M integers specifying the consecutive answers to all queries.
	// Nucleotides of types A, C, G and T have impact factors of 1, 2, 3 and 4, respectively.

	// time: O(N+M), space: O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int[] solution(String S, int[] P, int[] Q) {
		int N = S.length(), M = P.length;
		int[] answers = new int[M];
		int[][] preSumsTbl = new int[4][N+1]; // [A,C,G,T] x S[1..N+1]

		// construct PrefixSums table
		for (int i=0; i<N; i++) {
			for (int j=0; j<4; j++) {
				preSumsTbl[j][i+1] = preSumsTbl[j][i]; // brought from previous sum
			}

			// Add into a specific sum
			char c = S.charAt(i);
			switch(c) {
				case 'A': preSumsTbl[0][i+1]++; break;
				case 'C': preSumsTbl[1][i+1]++; break;
				case 'G': preSumsTbl[2][i+1]++; break;
				case 'T': preSumsTbl[3][i+1]++; break;
			}
		}

		for (int i=0; i<M; i++) {
			for (int j=0; j<4; j++) {
				if (preSumsTbl[j][Q[i]+1] - preSumsTbl[j][P[i]] > 0) {
					answers[i] = j+1;
					break;
				}
			}
		}

		return answers;
	}

/******************************
	// time: O(N*M), space: O(N)
	private static int[] solution(String S, int[] P, int[] Q) {
		int N = S.length(), M = P.length;
		int[] s = new int[N], answers = new int[M];

		// convert S into indexed int
		for (int i=0; i<N; i++) {
			char c = S.charAt(i);
			s[i] = (c=='A'?1:(c=='C'?2:(c=='G'?3:4)));
		}

		for (int i=0; i<M; i++) {
			int min = Integer.MAX_VALUE;
			for (int j=P[i]; j<=Q[i]; j++) {
				if (s[j] < min) min = s[j];
			}
			answers[i] = min;
		}
		return answers;
	}
******************************/
}
