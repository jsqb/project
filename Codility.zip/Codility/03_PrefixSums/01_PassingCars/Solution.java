public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{0,1,0,1,1};
		Test.assertEquals(5, solution(A));
		A = new int[]{1,0,1,0,0};
		Test.assertEquals(1, solution(A));
		Test.printResults();
	}

	// given a non-empty zero-indexed array A of N integers,
	// returns the number of passing cars.
	// The function should return -1 if the number of passing cars exceeds 1,000,000,000.

	// O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, passingCars = 0;
		int[] prefixSums = new int[N+1];

		// construct PrefixSums
		for (int i=0; i<N; i++) {
			prefixSums[i+1] = prefixSums[i] + A[i];
		}

		for (int i=0; i<N-1; i++) {
			if (A[i] == 0) {
				passingCars += prefixSums[N] - prefixSums[i+1];
				if (passingCars > 1000000000) return -1;
			}
		}

		return passingCars;
	}
}
