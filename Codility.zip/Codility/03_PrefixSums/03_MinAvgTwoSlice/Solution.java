import java.util.*;
public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{4,2,2,5,1,5,8};
		Test.assertEquals(1, solution(A));
		Test.printResults();
	}

	// given a non-empty zero-indexed array A consisting of N integers,
	// returns the starting position of the slice with the minimal average.
	// If there is more than one slice with a minimal average, you should return the smallest starting position of such a slice.

	// The key to solve this task is these two patterns:  
	// (1) There must be some slices, with length of two or three, having the minimal average value among all the slices. 
	// (2) And all the longer slices with minimal average are built up with these 2-element and/or 3-element small slices.

	// time: O(N), space: O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, minIndex = 0;
		if (N < 2) return 0;

		double min = Double.MAX_VALUE, val = 0.0;
		for (int i=0; i<N-2; i++) {
			val = (A[i]+A[i+1])/2.0;
			if (val < min) {
				min = val;
				minIndex = i;
			}

			val = (A[i]+A[i+1]+A[i+2])/3.0;
			if (val < min) {
				min = val;
				minIndex = i;
			}
		}

		if ((A[N-2]+A[N-1])/2.0 < min) {
			minIndex = N-2;
		}

		return minIndex;
	}

/******************************
	// time: O(N^2), space: O(N)
	private static int solution(int[] A) {
		int N = A.length;
		int[] preSums = new int[N+1]; // A[1..N]

		// construct PrefixSums
		for (int i=0; i<N; i++) {
			preSums[i+1] = preSums[i] + A[i];
		}

		double minVal = Double.MAX_VALUE;
		int minIndex = 0;
		for (int i=0; i<N-1; i++) {
			for (int j=i+1; j<N; j++) {
				// the average equals (A[P] + A[P + 1] + ... + A[Q]) / (Q - P + 1).
				double val = (preSums[j+1] - preSums[i]) / (double)(j - i + 1);
				if (val < minVal) {
					minVal = val;
					minIndex = i;
				}
			}
		}

		return minIndex;
	}
******************************/
}
