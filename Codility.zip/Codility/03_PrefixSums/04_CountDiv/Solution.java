import java.util.*;
public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(3, solution(6,11,2));
		Test.assertEquals(4, solution(7,18,3));
		Test.assertEquals(10, solution(1,10,1));
		Test.assertEquals(5, solution(1,10,2));
		Test.assertEquals(6, solution(0,10,2));
		Test.assertEquals(1, solution(0,0,2));
		Test.assertEquals(1, solution(6,6,2));
		Test.assertEquals(2000000001, solution(0,Integer.MAX_VALUE,1));
		Test.assertEquals(3, solution(0,2,1));
		Test.printResults();
	}

	// given three integers A, B and K, returns the number of integers within the range [A..B] that are divisible by K

	// time: O(1), space: O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int A, int B, int K) {
		if (A > 2000000000) A = 2000000000;
		if (B > 2000000000) B = 2000000000;
		if (K > 2000000000) K = 2000000000;

		return B/K - (A>0 ? (A-1)/K : -1);

//		if (A % K == 0) return (B - A) / K + 1;
//		else            return (B - (A - A % K)) / K;
	}

}
