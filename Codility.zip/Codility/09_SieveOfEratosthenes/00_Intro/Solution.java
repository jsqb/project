public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(8, sieve0(17));
		Test.assertEquals(8, sieve(17));
		Test.printResults();

		Test.assertEquals(new int[]{2,2,3}, factorization(12, arrayF(12)));
		Test.assertEquals(new int[]{13}, factorization(13, arrayF(13)));
		Test.printResults();
	}

	// Sieve of Eratosthenes
	private static int sieve0(int n) {
		boolean[] sieve = new boolean[n+1];
		for (int i=2; i<=n; i++) {
			sieve[i] = true;
		}

		for (int i=2; i<=n; i++) {
			for (int j=2; i * j <= n; j++) {
				int k = i * j;
				sieve[k] = false;
			}
		}

		int count = 1;
		for (boolean s : sieve) if (s) count++;
		return count;
	}

	// 9.1: Sieve of Eratosthenes.
	// we don't need cross out multiples of i which are less than i^2.
	// Such multiples are of the form k * i, where k < i.
	// These have already been removed by one of the prime divisors of k.

	// O(n log log n).
	private static int sieve(int n) {
		boolean[] sieve = new boolean[n+1];
		for (int i=2; i<=n; i++) {
			sieve[i] = true;
		}

		int i = 2;
		while (i * i <= n) {
			if (sieve[i]) {
				int k = i * i; // start to cross out at i^2
				while (k <= n) {
					sieve[k] = false;
					k += i; // multiply *2, *3, ... 
				}
			}
			i++;
		}

		int count = 1;
		for (boolean s : sieve) if (s) count++;
		return count;
	}



	// 9.2: Preparing the array F for factorization.
	// O(log n).
	private static int[] arrayF(int n) {
		int[] F = new int[n+1];
		int i = 2;
		while (i * i <= n) {
			if (F[i] == 0) {
				int k = i * i;
				while (k <= n) {
					if (F[k] == 0) {
						F[k] = i;
					}
					k += i;
				}
			}
			i += 1;
		}
		return F;
	}

	// 9.3: Factorization of x
	// O(log x)
	private static int[] factorization(int x, int[] F) {
		java.util.List<Integer> primeFactors = new java.util.ArrayList<Integer>();
		while (F[x] > 0) {
			primeFactors.add(F[x]);
			x /= F[x];
		}
		primeFactors.add(x);

		int[] pfs = new int[primeFactors.size()];
		int i = 0;
		for (Integer primeFactor : primeFactors) {
			pfs[i++] = primeFactor;
		}
		return pfs;
	}

}
