public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,1,2,3,6};
		Test.assertEquals(new int[]{2,4,3,2,0}, solution(A));

		A = new int[]{4,2};
		Test.assertEquals(new int[]{0,1}, solution(A));

		A = new int[]{2,2,3,1};
		Test.assertEquals(new int[]{1,1,0,1}, solution(A));
		Test.assertEquals(new int[]{1,1,0,1}, solution0(A));
		Test.printResults();

/*
		int[] A1 = new int[100], A2 = new int[A1.length];
		for (int j=0;j<100;j++) {
			for (int i=0; i<A1.length; i++) {
				A1[i] = A2[i] = (int)(Math.random() * 100 + 1);
			}
			if (!java.util.Arrays.equals(solution0(A1), solution(A2))) {
				System.out.println(java.util.Arrays.toString(A1));
			}
		}
*/

	}

	// given a non-empty zero-indexed array A consisting of N integers,
	// returns a sequence of integers representing the amount of non-divisors.

	// time:O(N*log(N)), space:O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int[] solution(int[] A) {
		int N = A.length;
		java.util.Map<Integer, Integer> counts = new java.util.HashMap<Integer, Integer>();

		for (int a : A) {
			counts.put(a, (counts.get(a)!=null?counts.get(a):0)+1);
		}

		int[] nds = new int[N];
		for (int i=0; i<N; i++) {
			int n = A[i], j = 1, cnt = 0;
			while (j * j <= n) {
				if (n % j == 0) {
					if (counts.containsKey(j)) cnt += counts.get(j);

					int d = n / j;
					if (n > 1 && j != d && counts.containsKey(d)) cnt += counts.get(d);
				}
				j++;
			}
			nds[i] = N - cnt;
		}
		return nds;
	}

	private static int[] solution0(int[] A) {
    int[][] D = new int[A.length*2 + 1][2];

    for (int i = 0; i < A.length; i++) {
        D[A[i]][0]++;
        D[A[i]][1] = -1;
    }

    for (int i = 0; i < A.length; i++) {
        if (D[A[i]][1] == -1) {
            D[A[i]][1] = 0;
            for (int j = 1; j <= Math.sqrt(A[i]) ; j++) {
                if (A[i] % j == 0 && A[i] / j != j) {
                    D[A[i]][1] += D[j][0];
                    D[A[i]][1] += D[A[i]/j][0];
                } else if (A[i] % j == 0 && A[i] / j == j) {
                    D[A[i]][1] += D[j][0];
                }
            }
        }
    }
    for (int i = 0; i < A.length; i++) {
        A[i] = A.length - D[A[i]][1];
    }
    return A;
	}

}
