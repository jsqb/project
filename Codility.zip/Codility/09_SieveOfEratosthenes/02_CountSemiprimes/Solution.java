public class Solution {
	public static void main(String[] args) {
		int[] P = new int[]{1,4,16};
		int[] Q = new int[]{26,10,20};
		Test.assertEquals(new int[]{10,4,0}, solution(26,P,Q));

		Test.printResults();
	}

	// given an integer N and two non-empty zero-indexed arrays P and Q consisting of M integers,
	// returns an array consisting of M elements specifying the consecutive answers to all the queries.

	// time:O(N*log(log(N))+M), space:O(N+M)
	// Correctness: 100%
	// Performance: 20%
	// Task score: 55%
	private static int[] solution(int N, int[] P, int[] Q) {
		int M = P.length;
		int[] semiprimes = new int[N+1];
		int[] primes = sieve(N);

		for (int i=0; i<primes.length; i++) {
			for (int j=i; j<primes.length; j++) {
				int n = primes[i] * primes[j];
				if (n <= N) {
					for (int k=n; k<N+1; k++) {
						semiprimes[k] += 1;
					}
				}	else {
					break;
				}
			}
		}

		int[] results = new int[M];
		for (int i=0; i<M; i++) {
			results[i] = semiprimes[Q[i]] - semiprimes[P[i]-1];
		}
		return results;
	}

	// O(n log log n).
	private static int[] sieve(int n) {
		boolean[] sieve = new boolean[n+1];
		for (int i=2; i<=n; i++) {
			sieve[i] = true;
		}

		int i = 2;
		while (i * i <= n) {
			if (sieve[i]) {
				int k = i * i; // start to cross out at i^2
				while (k <= n) {
					sieve[k] = false;
					k += i; // multiply *2, *3, ... 
				}
			}
			i++;
		}

		int primeCount = 0;
		for (boolean s : sieve) {
			if (s) primeCount++;
		}
		int[] primes = new int[primeCount];
		for (int j=2, cnt=0; j<=n; j++) {
			if (sieve[j]) primes[cnt++] = j;
		}
		return primes;
	}

}
