import java.util.Arrays;
public class Test {
	private static int total   = 0;
	private static int failure = 0;

	// Asserts that two ints are equal.
	public static void assertEquals(int expected, int actual) {
		printTestResult(expected == actual, expected+"", actual+"");
	}

	// Asserts that two int arrays are equal. 
	public static void assertEquals(int[] expected, int[] actual) {
		printTestResult(Arrays.equals(expected,actual), Arrays.toString(expected), Arrays.toString(actual));
	}

	// Asserts that actual int equals any expected int values
	public static void assertEquals(int[] expected, int actual) {
		boolean isPassed = false;
		if (expected != null) {
			for (int expValue : expected) {
				if (actual == expValue) {
					isPassed = true;
					break;
				}
			}
		}
		printTestResult(isPassed, "<any>"+Arrays.toString(expected), actual+"");
	}

	// Asserts that two booleans are equal.
	public static void assertEquals(boolean expected, boolean actual) {
		printTestResult(expected == actual, expected+"", actual+"");
	}

	// Asserts that two strings are equal.
	public static void assertEquals(String expected, String actual) {
		printTestResult((expected==null && actual==null) || (expected!=null && expected.equals(actual)), expected, actual);
	}

	// Print total and failure counts
	public static void printResults() {
		System.out.println("Runs: "+total+", Failures: "+failure);
		total = failure = 0;
	}

	private static void printTestResult(boolean isPassed, String expected, String actual) {
		System.out.println((++total)+" ["+(!isPassed&&++failure>0?"FAILED":"Passed")+"] Expected=("+expected+") Actual=("+actual+")");
	}
}
