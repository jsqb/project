public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{4,3,4,4,4,2};
		Test.assertEquals(2, solution(A));
		A = new int[]{4,3,4,4,4,4};
		Test.assertEquals(4, solution(A));
		A = new int[]{2,4,6,8,10};
		Test.assertEquals(0, solution(A));
		Test.printResults();
	}

	// given a non-empty zero-indexed array A consisting of N integers,
	// returns the number of equi leaders.

	// time:O(N), space:O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int count = 0; //  the number of equi leaders

		// find a leader using O(N) algorithm
		int N = A.length, size = 0, preValue = -1,
		    candidate = -1, leader = Integer.MIN_VALUE,
		    leaderCount = 0; // num of leader number in A
		for (int i=0; i<N; i++) {
			if (size == 0) {
				size++;
				preValue = A[i];
			} else {
				size += preValue == A[i] ? 1 : -1;
			}
		}
		if (size > 0) {
			candidate = preValue;

			// verify if the candidate is a leader
			for (int i=0; i<N; i++) {
				if (A[i] == candidate) leaderCount++;
			}

			if (leaderCount > N/2) {
				leader = candidate;
			}
		}
		if (leaderCount == 0) return 0; // not found

		// count the num of leaders in left and right sequences.
		for (int S=0, leftCount=0; S<N; S++) {
			int N1 = S+1, N2 = N-N1;
			if (A[S] == leader) leftCount++;
			if (leftCount > N1/2 && (leaderCount - leftCount) > N2/2) {
				count++;
			}
		}
		return count;
	}

/***********************
	// time:O(N^2), space:O(N)
	private static int solution(int[] A) {
		int N = A.length, count = 0;

		for (int S=0; S<N; S++) {
			int N1 = S+1, N2 = N-N1;
			int cand1 = Integer.MIN_VALUE, cand2 = Integer.MIN_VALUE;

			int size = 0, preValue = -1;
			for (int i=0; i<N; i++) {
				if (size == 0) {
					size++;
					preValue = A[i];
				} else {
					size += preValue == A[i] ? 1 : -1;
				}
				if (i == S && size > 0) {
					cand1 = preValue;
					size = 0;
				} else if (i == N-1 && size > 0) {
					cand2 = preValue;
				}
			}

			if (cand1 != Integer.MIN_VALUE && cand1 == cand2) {
				// verify if the candidate is a leader
				boolean isLeader = false;
				for (int i=0, cnt=0; i<N1; i++) {
					if (A[i] == cand1 && ++cnt > N1/2) {
						isLeader = true;
						break;
					}
				}
				if (isLeader) {
					for (int i=S, cnt=0; i<N; i++) {
						if (A[i] == cand2 && ++cnt > N2/2) {
							count++;
							break;
						}
					}
				}
			}
		}
		return count;
	}
***********************/

}
