public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,4,3,2,3,-1,3,3};
		Test.assertEquals(new int[]{0,2,4,6,7}, solution(A));
		A = new int[]{8,6,4,6,8,6,6};
		Test.assertEquals(new int[]{1,3,5,6}, solution(A));
		A = new int[]{2,4,6,8,10};
		Test.assertEquals(-1, solution(A));
		Test.printResults();
	}

	// given a zero-indexed array A consisting of N integers,
	// returns index of any element of array A in which the dominator of A occurs.
	// The function should return -1 if array A does not have a dominator.

	// time:O(N), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, size = 0, preValue = -1, candidate = -1;
		for (int i=0; i<N; i++) {
			if (size == 0) {
				size++;
				preValue = A[i];
			} else {
				size += preValue == A[i] ? 1 : -1;
			}
		}
		if (size == 0) return -1;
		candidate = preValue;

		// verify if the candidate is a leader
		for (int i=0, count=0; i<N; i++) {
			if (A[i] == candidate && ++count > N/2) return i;
		}
		return -1;
	}

/******************************
	// time:O(NlogN), space:O(N)
	private static int solution(int[] A) {
		int N = A.length;
		int[] B = new int[N];
		System.arraycopy(A,0,B,0,N); // keep A to see the original index number
		java.util.Arrays.sort(B);
		int candidate = B[N/2];

		// verify if the candidate is a leader
		for (int i=0, count=0; i<N; i++) {
			if (A[i] == candidate && ++count > N/2) return i;
		}
		return -1;
	}

	// time:O(N^2), space:O(1)
	private static int solution(int[] A) {
		int N = A.length;

		for (int i=0; i<N; i++) {
			for (int j=0, count= 0; j<N; j++) {
				if (A[j] == A[i] && ++count > N/2) return i;
			}
		}
		return -1;
	}
******************************/
}
