public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(5, solution(10, 4));
		Test.assertEquals(5, solution0(10, 4));
		Test.assertEquals(5, solution1(10, 4));

		Test.assertEquals(41, solution(123, 6));
		Test.assertEquals(41, solution0(123, 6));
		Test.assertEquals(41, solution1(123, 6));

		Test.printResults();

	}

	// given two positive integers N and M,
	// returns the number of chocolates that you will eat.

	// time:O(), space:O(N)
	// Correctness: 100%
	// Performance: 25% - large tests - RUNTIME ERROR java.lang.OutOfMemoryError
	// Task score: 62%
	private static int solution(int N, int M) {
		boolean[] chocos = new boolean[N];

		int x = 0, count = 0;
		while (!chocos[x]) {
			chocos[x] = true;
			count++;
			x = (x + M) % N;
		}

		return count;
	}

	// time:O(log(N+M)), space:O(1)
	private static int solution0(int N, int M) {
		int n = N, m = 0, count = 1;
		while ((m = n % M) != 0) {
			n = N - m;
			count += n / M;
		}
		return count + (n / M);
	}

	// Correctness: 100%
	// Performance: 0%
	// Task score: 50%
	private static int solution1(int N, int M) {
		//int lcm = N*M / gcd(N, M);
		//return lcm / M;
		return N / gcd(N, M);
	}

	private static int gcd(int a, int b) {
		if (a % b == 0) return b;
		return gcd(b, a % b);
	}

}
