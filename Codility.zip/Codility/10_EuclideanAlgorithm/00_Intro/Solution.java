public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(5, gcd1(10,15));
		Test.assertEquals(16, gcd1(32,48));
		Test.assertEquals(5, gcd2(10,15));
		Test.assertEquals(16, gcd2(32,48));
		Test.assertEquals(5, gcd3(10,15,1));
		Test.assertEquals(16, gcd3(32,48,1));

		Test.assertEquals(30, lcm(10,15));
		Test.assertEquals(96, lcm(32,48));
		Test.printResults();
	}

	// 10.1. Euclidean algorithm by subtraction
	private static int gcd1(int a, int b) {
		if (a == b) {
			return a;
		} else if (a > b) {
			return gcd1(a - b, b);
		}
		return gcd1(a, b - a);
	}

	// 10.2. Euclidean algorithm by division
	private static int gcd2(int a, int b) {
		if (a % b == 0) return b;
		return gcd2(b, a % b);
	}

	// 10.3: Greatest common divisor using binary Euclidean algorithm.
	// This algorithm finds the gcd using only subtraction, binary representation, shifting and parity
	// testing. We will use a divide and conquer technique.
	private static int gcd3(int a, int b, int res) {
		if (a == b) {
			return res * a;
		} else if (a % 2 == 0 && b % 2 == 0) {
			return gcd3(a / 2, b / 2, 2 * res);
		} else if (a % 2 == 0) {
			return gcd3(a / 2, b, res);
		} else if (b % 2 == 0) {
			return gcd3(a, b / 2, res);
		} else if (a > b) {
			return gcd3(a - b, b, res);
		}
		return gcd3(a, b - a, res);
	}

	// lcm(a, b) = (a*b)/gcd(a,b)
	private static int lcm(int a, int b) {
		return (a * b)/gcd2(a, b);
	}

}
