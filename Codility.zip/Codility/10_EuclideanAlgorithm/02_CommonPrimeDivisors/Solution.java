public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{15,10,3};
		int[] B = new int[]{75,30,5};
		Test.assertEquals(1, solution(A, B));
		Test.assertEquals(1, solution0(A, B));

		A = new int[]{6};
		B = new int[]{8};
		Test.assertEquals(0, solution(A, B));
		Test.assertEquals(0, solution0(A, B));

		A = new int[]{2};
		B = new int[]{6};
		Test.assertEquals(0, solution(A, B));
		Test.assertEquals(0, solution0(A, B));

		A = new int[]{1};
		B = new int[]{1};
		Test.assertEquals(1, solution(A, B));
		Test.assertEquals(1, solution0(A, B));

		Test.printResults();
	}

	// given two non-empty zero-indexed arrays A and B of Z integers,
	// returns the number of positions K for which the prime divisors of A[K] and B[K] are exactly the same.

	// time:O(Z*log(max(A)+max(B))2), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A, int[] B) {
		int Z = A.length, count = 0;
		for (int i=0; i<Z; i++) {
			if(hasSamePrimeDivisors(A[i], B[i])) count++;
		}
		return count;
	}

	private static boolean hasSamePrimeDivisors(int a, int b) {
		int gcdValue = gcd(a, b);
		int gcdA, gcdB;
		while (a != 1) {
			gcdA = gcd(a, gcdValue);
			if(gcdA == 1) break;
			a = a / gcdA;
		}
		if (a != 1) {
			return false;
		}

		while (b != 1) {
			gcdB = gcd(b, gcdValue);
			if(gcdB == 1) break;
			b = b / gcdB;
		}
		return b == 1;
	}

	private static int gcd(int a, int b) {
		if (a % b == 0) return b;
		return gcd(b, a % b);
	}


	// Bad performance
	private static int solution0(int[] A, int[] B) {
		int Z = A.length, count = Z, maxPrime = 0;

		for (int i=0; i<Z; i++) {
			int max = Math.max(A[i], B[i]);
			if (max > maxPrime) maxPrime = max;
		}

		boolean[] primes = sieve(maxPrime);

		for (int i=0; i<Z; i++) {
			int N = A[i], M = B[i];
			if (N == M) continue; // has same prime divisors

			int max = Math.max(A[i], B[i]);
//			if (max < 2) count--; 
			for (int j=2; j<=max; j++) {
				if (!primes[j]) continue;
//System.out.println("i("+i+") j("+j+") A("+A[i]+") B("+B[i]+")");
				int mod1 = A[i] % j, mod2 = B[i] % j;
				if ((mod1 != 0 && mod2 == 0) || (mod1 == 0 && mod2 != 0)) {
					count--;
					break;
				}
			}
		}

		return count;
	}

	private static boolean[] sieve(int n) {
		boolean[] sieve = new boolean[n+1];
		for (int i=2; i<=n; i++) {
			sieve[i] = true;
		}

		int i = 2;
		while (i * i <= n) {
			if (sieve[i]) {
				int k = i * i; // start to cross out at i^2
				while (k <= n) {
					sieve[k] = false;
					k += i; // multiply *2, *3, ... 
				}
			}
			i++;
		}

		return sieve;
	}

}
