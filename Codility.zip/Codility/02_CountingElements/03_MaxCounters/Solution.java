public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,4,4,6,1,4,4};
		Test.assertEquals(new int[]{3,2,2,4,2}, solution(5, A));
		Test.printResults();
	}

	// given an integer N and a non-empty zero-indexed array A consisting of M integers,
	// returns a sequence of integers representing the values of the counters.

	// O(N+M)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int[] solution(int N, int[] A) {
		int M = A.length, max = 0, maxN = 0;
		int[] counters = new int[N];

		for (int i=0; i<M; i++) {
			int idx = A[i] - 1;
			if (idx < N) {
				if (counters[idx] < maxN) counters[idx] = maxN;
				if (++counters[idx] > max) max = counters[idx];
			} else {
				maxN = max; // save max to be updated on all elements
			}
		}

		for (int j=0; j<N; j++) {
			if (counters[j] < maxN) counters[j] = maxN;
		}

		return counters;
	}

/**********************************
	// O(N*M)
	private static int[] solution(int N, int[] A) {
		int M = A.length, max = 0;
		int[] counters = new int[N];

		for (int i=0; i<M; i++) {
			int idx = A[i] - 1;
			if (idx < N) {
				if (++counters[idx] > max) max = counters[idx];
			} else {
				for (int j=0; j<N; j++) counters[j] = max;
			}
		}
		return counters;
	}
**********************************/
}
