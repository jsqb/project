public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{4,1,3,2};
		Test.assertEquals(1, solution(A));
		A = new int[]{4,1,3};
		Test.assertEquals(0, solution(A));
		A = new int[]{4,2,2,2};
		Test.assertEquals(0, solution(A));
		Test.printResults();
	}

	// returns 1 if array A is a permutation and 0 if it is not.

	// O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int A[]) {
		int N = A.length;
		boolean[] perm = new boolean[N];
		for (int i=0; i<N; i++) {
			int idx = A[i] - 1;
			if (idx >= N || perm[idx]) return 0;
			perm[idx] = true;
		}
		return 1;
	}
}
