public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{1,3,1,4,2,3,5,4};
		Test.assertEquals(6, solution(5, A));
		A = new int[]{1,3,1,4,1,3,5,4};
		Test.assertEquals(-1, solution(5, A));
		Test.printResults();
	}

	// Frog wants to get to position X.
	// Returns the earliest time when the frog can jump to the other side of the river.
	// If the frog is never able to jump to the other side of the river, the function should return -1.

	// O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int X, int A[]) {
		boolean[] path = new boolean[X];
		int N = A.length;
		for (int i=0; i<N; i++) {
			int idx = A[i] - 1;
			if (!path[idx]) {
				path[idx] = true;
				if (--X == 0) return i;
			}
		}
		return -1;
	}
}
