public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{0,0,0,1,1,0,1,0,0,0,0};
		Test.assertEquals(3, solution(A));

		Test.printResults();
	}

	// given a zero-indexed array A consisting of N integers,
	// returns the minimum number of jumps by which the frog can get to the other side of the river.
	// If the frog cannot reach the other side of the river, the function should return -1.

	// time:O(N*log(N)), space:O(N)
	// Correctness: 0%
	// Performance: 0%
	// Task score: 0%
	private static int solution(int[] A) {
		int N = A.length, pos = -1, count = 0;
		int[] fb = createFibonacciArray(25);

		boolean found = false;
		do {
			int dist = N - pos, start = fb.length-1;
			if (dist < 10) {
				start = 6;
			} else if (dist < 100) {
				start = 11;
			} else if (dist < 1000) {
				start = 16;
			} else if (dist < 10000) {
				start = 20;
			}

			for (int i=start; i>0; i--) {
				int jump = fb[i];
//System.out.println("dist("+dist+") pos("+pos+") fb["+i+"]=("+fb[i]+")");
				if (jump > dist) continue;
				if (jump == dist) {
					return ++count;
				}
				if (A[jump+pos] == 1) {
					pos += fb[i];
					count++;
					found = true;
					break;
				}
			}
		} while (found);

		return -1;
	}


	// fb[25]= 75,025
	// fb[26]=121,393 <== not needed due to max(N)=100,000
	private static int[] createFibonacciArray(int n) {
		int[] fb = new int[n+1];
		if (n > 0) fb[1] = 1;
		for (int i=2; i<=n; i++) {
			fb[i] = fb[i-1] + fb[i-2];
		}
		return fb;
	}


}
