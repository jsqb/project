public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{4,4,5,5,1};
		int[] B = new int[]{3,2,4,3,1};
		Test.assertEquals(new int[]{5,1,8,0,1}, solution_slow(A,B));
		Test.assertEquals(new int[]{5,1,8,0,1}, solution(A,B));

		Test.printResults();
	}




	// given two non-empty zero-indexed arrays A and B of L integers,
	// returns an array consisting of L integers specifying the consecutive answers;
	// position I should contain the number of different ways of climbing
	// the ladder with A[I] rungs modulo 2^B[I].

	// each element of array A is an integer within the range [1..L];

	// time:O(L), space:O(L)
	// Correctness: 0%
	// Performance: 0%
	// Task score: 0%

	// Good performance
	private static int[] solution(int[] A, int[] B) {
		int L = A.length;          // The possible largest N rungs
		int[] counts = new int[L]; // The result for each query
		int[] B2 = new int[L];

		// Pre-compute B for optimization
    for (int i=0; i<L; i++) {
			B2[i] = (1<<B[i])-1;
		}

    // Compute the Fibonacci numbers for later use
    int[] fib = new int[L+2];
		fib[1] = 1;
		for (int i=2; i<L+2; i++) {
			fib[i] = fib[i- 1] + fib[i-2];
		}

		for (int i=0; i<L; i++) {
			counts[i] = fib[A[i]+1] & B2[i];
		}
 
    return counts;
	}

	// Slow solution
	private static int[] solution_slow(int[] A, int[] B) {
		int L = A.length;
		int[] counts = new int[L];

		// Create a fibonacci array
		int[] fib = new int[L+2];
		fib[1] = 1;
		for (int i=2; i<L+2; i++) {
			fib[i] = fib[i-1] + fib[i-2];
		}

		// Count (Fib number = The num of diff ways of climing)
		for (int i=0; i<L; i++) {
			counts[i] = fib[A[i]+1] % (1<<B[i]);
		}

		return counts;
	}

}
