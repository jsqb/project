public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,1,2,4,3};
		Test.assertEquals(1, solution(A));
		A = new int[]{-9,5,17,-10};
		Test.assertEquals(11, solution(A));
		Test.printResults();
	}

	// Param: a non-empty zero-indexed array A of N integers
	// Returns the minimal difference that can be achieved.

	// O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int A[]) {
		int N = A.length, min = Integer.MAX_VALUE;
		int left = 0, right = 0;

		for (int i=0; i<N; i++) {
			right += A[i];
		}

		for (int i=0; i<(N-1); i++) {
			left += A[i];
			right -= A[i];
			int sum = Math.abs(left - right);
			if (sum < min) min = sum;
		}
		return min;
	}

/*************************************
	// O(N^2)
	private static int solution(int A[]) {
		int N = A.length, min = Integer.MAX_VALUE;
		for (int p=1; p<N; p++) {
			int sum = 0;
			for (int i=0; i<N; i++) {
				if (i < p) {
					sum += A[i];
				} else {
					sum -= A[i];
				}
			}
			sum = Math.abs(sum);
			if (sum < min) min = sum;
		}
		return min;
	}
*************************************/
}
