public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{3,2,1,5};
		Test.assertEquals(4, solution(A));
		Test.printResults();
	}

	// Returns the value of the missing element.

	// O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A) {
		int N = A.length, sum = 0;
		for (int i=0; i<N; i++) {
			sum += (i+1) - A[i];
		}
		return sum + N + 1;
	}

}
