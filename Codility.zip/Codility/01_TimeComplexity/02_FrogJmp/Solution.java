public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(0, solution(1, 1, 1000000000));
		Test.assertEquals(1, solution(3, 1, 1000000000));
		Test.assertEquals(3, solution(10, 85, 30));
		Test.assertEquals(3, solution(10, 99, 30));
		Test.assertEquals(3, solution(10, 100, 30));
		Test.assertEquals(4, solution(10, 101, 30));
		Test.printResults();
	}

	// Returns the minimal number of jumps
	// from position X to a position equal to or greater than Y step by distance D

	// O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int X, int Y, int D) {
		return X == Y ? 0 : ((Y - X - 1) / D) + 1;
	}

}
