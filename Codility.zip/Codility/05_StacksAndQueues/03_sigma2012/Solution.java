public class Solution {
	public static void main(String[] args) {
		int[] H = new int[]{8,8,5,7,9,8,7,4,8};
		Test.assertEquals(7, solution(H));
		H = new int[]{2,1,2};
		Test.assertEquals(3, solution(H));
		H = new int[]{1,2,1,2,1};
		Test.assertEquals(3, solution(H));
		Test.printResults();
	}

	// given a zero-indexed array H of N positive integers specifying the height of the wall,
	// returns the minimum number of blocks needed to build it.

	// time:O(N), space:O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] H) {
		int N = H.length, stones = 0;
		java.util.Stack<Integer> s = new java.util.Stack<Integer>();

		for (int i=0; i<N; i++) {
			while (!s.isEmpty() && s.peek() > H[i]) s.pop();
			if (s.isEmpty() || s.peek() != H[i]) {
				stones++;
				s.push(H[i]);
			}
		}

		return stones;
	}

/***********************
	private static int solution(int[] H) {
		int N = H.length, stones = 0, prevH = -1;

		for (int i=0; i<N; i++) {
			if (prevH != H[i]) stones++;
			prevH = H[i];
		}

		return stones;
	}
***********************/

}
