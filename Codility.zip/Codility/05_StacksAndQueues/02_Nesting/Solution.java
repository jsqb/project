public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(1, solution("(()(())())"));
		Test.assertEquals(0, solution("())"));
		Test.assertEquals(1, solution(""));
		Test.assertEquals(0, solution(")()("));
		Test.assertEquals(0, solution("())(()"));
		Test.assertEquals(1, solution("(((()())((()))(())))"));
		Test.printResults();
	}

	// given a string S consisting of N characters,
	// returns 1 if string S is properly nested and 0 otherwise.

	// time:O(N), space:O(1)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(String S) {
		int N = S.length(), count = 0;
		if (N > 0 && S.charAt(0) != '(') return 0;

		for (int i=0; i<N; i++) {
			count += S.charAt(i) == '(' ? 1 : -1;
			if (count < 0) return 0;
		}
		return count == 0 ? 1 : 0;
	}
}
