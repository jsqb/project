public class Solution {
	public static void main(String[] args) {
		int[] A = new int[]{0, 0, 1, 0, 0, 1, 1, 1};
		Test.assertEquals(3, solution(A));
		Test.printResults();
	}

	// Exercise

	// 0 represents the action of a new person joining the line in the grocery store,
	// 1 represents the action of the person at the front of the queue being served and leaving the line.

	// The goal is to count the minimum number of people who should have been in the line before
	// the above scenario, so that the scenario is possible.

	// O(N)
	// A : array of data {0, 1}
	private static int solution(int[] A) {
		int max = 0, queueSize = 0;

		for (int n : A) {
			if (n == 0) {
				queueSize++;
				max = Math.max(max, queueSize);
			} else {
				queueSize--;
			}
		}

		return max;
	}

}
