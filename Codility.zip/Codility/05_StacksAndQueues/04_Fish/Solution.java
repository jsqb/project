public class Solution {
	public static void main(String[] args) {
		int[] A = { 4, 3, 2, 1, 5 };
		int[] B = { 0, 1, 0, 0, 0 }; // 0:upstream, 1:downstream
		Test.assertEquals(2, solution(A,B));
		A = new int[] { 4, 3, 2, 1, 5 };
		B = new int[] { 0, 1, 0, 1, 0 };
		Test.assertEquals(2, solution(A,B));
		A = new int[] { 4, 3, 2, 1, 5 };
		B = new int[] { 0, 0, 0, 0, 0 };
		Test.assertEquals(5, solution(A,B));
		A = new int[] { 4, 3, 2, 1, 5 };
		B = new int[] { 1, 1, 1, 1, 1 };
		Test.assertEquals(5, solution(A,B));
		A = new int[] { 4, 3, 2, 1, 5 };
		B = new int[] { 0, 0, 0, 1, 1 };
		Test.assertEquals(5, solution(A,B));
		A = new int[] { 5, 3, 2, 1, 4 };
		B = new int[] { 1, 0, 0, 0, 0 };
		Test.assertEquals(1, solution(A,B));
		A = new int[] { 1, 2, 3, 4, 5 };
		B = new int[] { 1, 1, 1, 1, 0 };
		Test.assertEquals(1, solution(A,B));
		A = new int[0];
		B = new int[0];
		Test.assertEquals(0, solution(A,B));
		Test.printResults();
	}

	// given two non-empty zero-indexed arrays A and B consisting of N integers,
	// returns the number of fish that will stay alive.

	// time:O(N), space:O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(int[] A, int[] B) {
		int N = A.length;
		java.util.Stack<Integer> s = new java.util.Stack<Integer>();

		if (N > 0) s.push(0);
		for (int Q=1; Q<N; Q++) {
			while (!s.isEmpty() && B[s.peek()] == 1 && B[Q] == 0 && A[s.peek()] < A[Q]) { // eat weakers in stack
				s.pop();
			}
			if (s.isEmpty() || B[s.peek()] != 1 || B[Q] != 0 ||  A[s.peek()] < A[Q]) { // add an own index in stack if stronger than the top in the stack
				s.push(Q);
			}
		}
		return s.size();
	}

/************************************
	// time:O(N), space:O(N)
	private static int solution(int[] A, int[] B) {
		int N = A.length;
		java.util.Stack<Integer> s = new java.util.Stack<Integer>();

		for (int Q=0; Q<N; Q++) {
			if (s.isEmpty()) {
				s.push(Q);
			} else {
				while (!s.empty() && B[Q] - B[s.peek()] == -1 && A[s.peek()] < A[Q]) {
					s.pop();
				}

				if (!s.isEmpty()) {
					if (B[Q] - B[s.peek()] != -1) s.push(Q);
				} else {
					s.push(Q);
				}
			}
		}
		return s.size();
	}
************************************/
}
