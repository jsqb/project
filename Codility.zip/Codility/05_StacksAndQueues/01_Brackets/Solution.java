public class Solution {
	public static void main(String[] args) {
		Test.assertEquals(1, solution("{[()()]}"));
		Test.assertEquals(0, solution("([)()]"));
		Test.assertEquals(0, solution(")))"));
		Test.assertEquals(0, solution("((("));
		Test.assertEquals(1, solution(""));
		Test.printResults();
	}

	// given a string S consisting of N characters,
	// returns 1 if S is properly nested and 0 otherwise.

	// time:O(N), space:O(N)
	// Correctness: 100%
	// Performance: 100%
	// Task score: 100%
	private static int solution(String S) {
		int N = S.length();
		java.util.Stack<Character> s = new java.util.Stack<Character>();

		for (int i=0; i<N; i++) {
			char c = S.charAt(i);
			if (c == '(') {
				s.push(')');
			} else if (c == '{') {
				s.push('}');
			} else if (c == '[') {
				s.push(']');
			} else {
				if (s.isEmpty() || s.pop() != c) return 0;
			}
		}
		return s.isEmpty() ? 1 : 0;
	}
}
