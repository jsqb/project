package controller;

import java.util.HashMap;

import org.springframework.ui.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloWorldController {

	@Autowired
	@Qualifier("siteSearchContext")
	private HashMap siteSearchContext = null;

	@RequestMapping(value="/hello", headers="Accept=application/xml, application/json")
//	public @ResponseBody ModelAndView helloWorld(HelloBean helloBean) {
	public @ResponseBody HelloBean helloWorld(HelloBean helloBean) {

		System.out.println("param1=("+helloBean.getParam1()+")");
		System.out.println("param2=("+helloBean.getParam2()+")");
//		System.out.println("model=("+model+")");

//	if (helloBean) {
		String message = "Hello World, Spring 3.0! SiteSearchHost=("+siteSearchContext.get("host")+":"+siteSearchContext.get("port")+")";
//		return new ModelAndView("hello", "message", message);
		//return "abcdefg-12345";
		return helloBean;
	}

}
