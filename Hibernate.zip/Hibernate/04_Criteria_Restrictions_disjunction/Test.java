// disjunction ('or' for among multiple conditions)

import static org.hibernate.criterion.Restrictions.in;
import static org.hibernate.criterion.Restrictions.disjunction;
import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.isNull;

import java.util.*;
import org.hibernate.*;


public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		@SuppressWarnings("unchecked")
		List<Cat> cats = session.createCriteria(Cat.class)
			.add(in("name", new String[]{"Cat101","Cat103","Cat105"}))
			.add(disjunction()
				.add(isNull("age"))
				.add(eq("age", 101))
				.add(eq("age", 102))
				.add(eq("age", 103))
			)
			.list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}
		System.out.println("-----------------------------------");

		HibernateUtils.close(session);
	}
}
