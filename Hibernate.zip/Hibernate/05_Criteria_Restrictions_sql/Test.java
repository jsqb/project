// sqlRestriction (allows you to specify SQL directly)

import static org.hibernate.criterion.Restrictions.sqlRestriction;
import static org.hibernate.criterion.Restrictions.disjunction;
import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.isNull;

import java.util.*;
import org.hibernate.*;


public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		@SuppressWarnings("unchecked")
		List<Cat> cats = session.createCriteria(Cat.class)
			.add(sqlRestriction("lower({alias}.name) like lower(?)", "CAT%", Hibernate.STRING))
			.list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}
		System.out.println("-----------------------------------");

		HibernateUtils.close(session);
	}
}
