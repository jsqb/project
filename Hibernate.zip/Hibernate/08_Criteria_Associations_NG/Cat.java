import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Cat {
	
	private String name;
	private Date birthDate;
	private int id;
	private Cat mother;
	private List<Cat> kittens;

	public Cat() {
		super();
		setKittens(new ArrayList<Cat>());
	}
	
	public void addKitten(Cat kitten) {
		this.getKittens().add(kitten);
		kitten.setMother(this);
	}

	// -- GETTERs and SETTERs --
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy="mother")
	public List<Cat> getKittens() {
		return kittens;
	}

	public void setKittens(List<Cat> kittens) {
		this.kittens = kittens;
	}

	@ManyToOne(optional=true)
	public Cat getMother() {
		return mother;
	}

	public void setMother(Cat parent) {
		this.mother = parent;
	}

	@Id	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

}
