import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtils {

	private static final SessionFactory sessionFactory;

	static {
		try {
			sessionFactory = new AnnotationConfiguration()
								.configure("./hibernate.cfg.xml")
								//.addPackage("com.loiane.model")
								//.addAnnotatedClass(Message.class)
								.buildSessionFactory();

		} catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void close(Session session) {
		if (session == null) return;
		try {
			session.connection().createStatement().execute("SHUTDOWN");
			session.close();
		} catch (Throwable ex) {
			System.err.println("Failed to shutdown: " + ex);
		}
	}
}