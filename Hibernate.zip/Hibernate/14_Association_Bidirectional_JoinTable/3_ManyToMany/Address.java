//import java.io.Serializable;
import java.util.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

@Entity
@Table(name = "ADDRESS")
public class Address {

	@Id
	@Column(name = "ADDRESS_ID", unique = true, nullable = false)
	private Long id;

	@Column(name= "STREET", nullable = false, length = 100)
	private String street;

	@ManyToMany
	@JoinTable(name="PERSON_ADDRESS",
		joinColumns = @JoinColumn(name="ADDRESS_ID"),
		inverseJoinColumns = @JoinColumn(name="PERSON_ID"))
	private Set<Person> persons = new HashSet<Person>();

	public Address() {
	}

	public Address(Long id, String street) {
		this.id = id;
		this.street = street;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public Set<Person> getPersons() {
		return persons;
	}

	public void setPersons(Set<Person> persons) {
		this.persons = persons;
	}

	public void addPerson(Person person) {
		persons.add(person);
	}

	@Override
	public String toString() {
		return "Address {id="+id+
			", street="+street+
			"}";
  }
}
