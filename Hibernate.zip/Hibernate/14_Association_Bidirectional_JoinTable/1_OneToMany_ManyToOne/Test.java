// ==> One to Many (<== Many to One) with a join table
// [Person]<1> <==> <n>[Address]
// a bidirectional one-to-many association on a join table

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Person person1 = new Person(new Long(1), "Eswar");

		Address address1 = new Address(new Long(101), "101 Test St");
		address1.setPerson(person1);
//		person1.addAddress(address1); // for update

		Address address2 = new Address(new Long(102), "102 Test St");
		address2.setPerson(person1);
//		person1.addAddress(address2); // for update

		session.saveOrUpdate(person1);
		session.saveOrUpdate(address1);
		session.saveOrUpdate(address2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <n>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddresses());
		}

		// Person<1> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPerson());
		}

		HibernateUtils.close(session);
	}
}
