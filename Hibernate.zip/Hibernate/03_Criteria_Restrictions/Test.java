import static org.hibernate.criterion.Restrictions.and;
import static org.hibernate.criterion.Restrictions.or;
import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.between;
import static org.hibernate.criterion.Restrictions.like;
import static org.hibernate.criterion.Restrictions.isNull;

import java.util.*;
import org.hibernate.*;


public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		// select
		Criteria criteria = session.createCriteria(Cat.class);

		@SuppressWarnings("unchecked")
		List<Cat> cats = criteria
		                     .add(like("name", "Cat%"))
		                     .add(between("age", 102, 104))
		                     .setMaxResults(50)
		                     .list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}
		System.out.println("-----------------------------------");

		// grouped logically
		@SuppressWarnings("unchecked")
		List<Cat> cats2 = session.createCriteria(Cat.class)
			.add(like("name", "Cat%"))
			.add(or(eq("age", 101), isNull("createdDate")))
			.setMaxResults(50)
			.list();

		for (Cat cat : cats2) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}
		System.out.println("-----------------------------------");




		HibernateUtils.close(session);
	}
}
