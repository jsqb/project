// One to one
// [Person]<1>---<1>[Address]
// ADDRESS_ID in PERSON is marked as UNIQUE
// A unidirectional one-to-one association on a foreign key is almost identical (unique).
// The only difference from many-to-one is the column unique constraint.

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Address address1 = new Address(new Long(101), "11 Test St");
		Address address2 = new Address(new Long(102), "12 Test St");

		Person person1 = new Person(new Long(1), "Eswar", address1);
		Person person2 = new Person(new Long(2), "John", address2);

		session.saveOrUpdate(address1);
		session.saveOrUpdate(address2);

		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <1>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddress());
		}

/*
		// Person<n> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPerson());
		}
*/

		HibernateUtils.close(session);
	}
}
