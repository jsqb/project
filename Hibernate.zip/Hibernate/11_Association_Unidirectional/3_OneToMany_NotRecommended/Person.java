//import java.io.Serializable;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;

@Entity
@Table(name = "PERSON")
public class Person {

	@Id
	@Column(name = "PERSON_ID", unique = true, nullable = false)
	private Long id;

	@Column(name= "NAME", nullable = false, length = 100)
	private String name;

	@OneToMany
	@JoinColumn(name="PERSON_ID")
	private Set<Address> addresses = new HashSet<Address>();

	public Person() {
	}

	public Person(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Set<Address> addresses) {
		this.addresses = addresses;
	}

	public void addAddress(Address address) {
		addresses.add(address);
	}

	@Override
	public String toString() {
		return "Person {id="+id+
			", name="+name+
			"}";
  }
}
