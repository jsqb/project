// One to Many
// [Person]<1>---<n>[Address]
// This is not recommended. ==> Use Join Table

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Person person1 = new Person(new Long(1), "Eswar");
		for (int i=1; i<=3; i++) {
			Address address = new Address(new Long(i+100), i+" Test St");
			session.save(address);
			person1.addAddress(address);
		}

		session.save(person1);

		tran.commit();
		HibernateUtils.close(session);
	}
}
