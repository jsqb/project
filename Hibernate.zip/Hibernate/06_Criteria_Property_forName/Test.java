// obtain a criterion from a Property instance
// You can create a Property by calling Property.forName()

import static org.hibernate.criterion.Restrictions.sqlRestriction;
import static org.hibernate.criterion.Restrictions.disjunction;
import static org.hibernate.criterion.Restrictions.eq;
import static org.hibernate.criterion.Restrictions.isNull;

import java.util.*;
import org.hibernate.*;
import org.hibernate.criterion.Property;


public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		Property age = Property.forName("age");

		@SuppressWarnings("unchecked")
		List<Cat> cats = session.createCriteria(Cat.class)
			.add(disjunction()
				.add(age.isNull())
				.add(age.eq(101))
				.add(age.eq(102))
				.add(age.eq(103))
			)
			.list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}
		System.out.println("-----------------------------------");

		HibernateUtils.close(session);
	}
}
