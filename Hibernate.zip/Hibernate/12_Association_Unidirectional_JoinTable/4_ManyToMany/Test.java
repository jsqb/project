// Many to Many via Join table
// [Person]<n>---<n>[Address]

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Address address1 = new Address(new Long(11), "11 Test St");
		Address address2 = new Address(new Long(12), "12 Test St");

		Person person1 = new Person(new Long(1), "Eswar");
		person1.addAddress(address1);
		person1.addAddress(address2);

		Person person2 = new Person(new Long(2), "John");
		person2.addAddress(address2); // Can associate with address1 and/or 2

		session.saveOrUpdate(address1);
		session.saveOrUpdate(address2);
		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <n>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddresses());
		}

/*
		// Person<n1> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPersons());
		}
*/

		HibernateUtils.close(session);
	}
}
