// Many to One via Join tabe
// [Person]<n>---<1>[Address]
// This is common when the association is optional.

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Address address = new Address(new Long(101), "11 Test St");

		Person person1 = new Person(new Long(1), "Eswar");
		//person1.setAddress(address); // Assigning address is optional

		Person person2 = new Person(new Long(2), "John");
		person2.setAddress(address);

		session.saveOrUpdate(address);
		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <1>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddress());
		}

/*
		// Person<n> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPerson());
		}
*/

		HibernateUtils.close(session);
	}
}
