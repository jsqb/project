// One to Many via Join table
// [Person]<1>---<n>[Address]
// This is the preferred option.
// Cannot associate with addresses that already associated with other pseson object.
// Specifying unique="true", changes the multiplicity from many-to-many to one-to-many.


import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Address address1 = new Address(new Long(11), "11 Test St");
		Address address2 = new Address(new Long(12), "12 Test St");
		Address address3 = new Address(new Long(13), "13 Test St");

		Person person1 = new Person(new Long(1), "Eswar");
		person1.addAddress(address1);
		person1.addAddress(address2);

		Person person2 = new Person(new Long(2), "John");
		person2.addAddress(address3); // Cannot associate with address1 and 2

		session.saveOrUpdate(address1);
		session.saveOrUpdate(address2);
		session.saveOrUpdate(address3);
		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <n>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddresses());
		}

/*
		// Person<1> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPerson());
		}
*/

		HibernateUtils.close(session);
	}
}
