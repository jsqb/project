//import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

@Entity
@Table(name = "ADDRESS")
public class Address {

	@Id
	@Column(name = "ADDRESS_ID", unique = true, nullable = false)
	private Long id;

	@Column(name= "STREET", nullable = false, length = 100)
	private String street;

	@OneToOne
	@JoinColumn(name="PERSON_ID")
	private Person person;

	public Address() {
	}

	public Address(Long id, String street) {
		this.id = id;
		this.street = street;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Address {id="+id+
			", street="+street+
			"}";
  }
}
