// One to One (bidirectional)
// [Person]<1>---<1>[Address]
// A bidirectional one-to-one association on a foreign key is common

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) throws Exception {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Person person1 = new Person(new Long(1), "Eswar");
		Address address1 = new Address(new Long(101), "11 Test St");
		address1.setPerson(person1);

		Person person2 = new Person(new Long(2), "John");
		Address address2 = new Address(new Long(102), "12 Test St");
		address2.setPerson(person2);

		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);

		session.saveOrUpdate(address1);
		session.saveOrUpdate(address2);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <1>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getAddress());
		}

		// Person<1> <== Address
		@SuppressWarnings("unchecked")
		List<Address> addrs = session.createCriteria(Address.class).list();
		System.out.println("-----------------------------");
		for (Address a : addrs) {
			System.out.println(a+", "+a.getPerson());
		}

		HibernateUtils.close(session);
	}
}
