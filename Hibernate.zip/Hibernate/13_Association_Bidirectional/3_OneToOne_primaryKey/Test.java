// One to One (bidirectional)
// [Person]<1>---<1>[PersonDetails]
// A bidirectional one-to-one association on a primary key

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();
		Transaction tran = session.beginTransaction();

		Person person1 = new Person(new Long(1), "Eswar");
		Person person2 = new Person(new Long(2), "John");
		PersonDetails details = new PersonDetails(new Long(1), "11 Test St");

		session.saveOrUpdate(person1);
		session.saveOrUpdate(person2);
		session.saveOrUpdate(details);

		tran.commit();
		session.close(); // need to close not to reuse the generated objects
		session = HibernateUtils.getSessionFactory().openSession();

		// Person ==> <1>Address
		@SuppressWarnings("unchecked")
		List<Person> people = session.createCriteria(Person.class).list();
		System.out.println("-----------------------------");
		for (Person p : people) {
			System.out.println(p+", "+p.getPersonDetails());
		}

		// Person<1> <== Address
		@SuppressWarnings("unchecked")
		List<PersonDetails> detailsList = session.createCriteria(PersonDetails.class).list();
		System.out.println("-----------------------------");
		for (PersonDetails d : detailsList) {
			System.out.println(d+", "+d.getPerson());
		}

		HibernateUtils.close(session);
	}
}
