import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import javax.persistence.*;

@Entity
@Table(name="person_details")
public class PersonDetails {
  @Id
//  @GeneratedValue(generator="foreign")
//    @GenericGenerator(name="foreign", strategy = "foreign", parameters={
//      @Parameter(name="property", value="person")
//    })
  @Column(name="person_id")
  private Long personId;

  @Column(name="street")
  private String street;

  @OneToOne(fetch = FetchType.LAZY, optional=true)
  //@Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
  @PrimaryKeyJoinColumn
  private Person person;

	public PersonDetails() {
	}

	public PersonDetails(Long personId, String street) {
		this.personId = personId;
		this.street = street;
	}

  public Long getPersonId() {
    return personId;
  }
  public void setPersonId(Long personId) {
    this.personId = personId;
  }

  public String getStreet() {
    return street;
  }
  public void setStreet(String street) {
    this.street = street;
  }

  public Person getPerson() {
    return person;
  }

  public void setPerson(Person person) {
    this.person = person;
  }

	@Override
	public String toString() {
		return "PersonDetails {id="+personId+
			", street="+street+
			"}";
  }

}
