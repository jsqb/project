//import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "MESSAGE")
public class Message {

	@Id
	@Column(name = "ID", unique = true, nullable = false)
	private Long id;

	@Column(name= "TEXT", nullable = false, length = 100)
	private String text;

	@Column(name= "GENERATED_DATE", nullable = true)
	private Date generatedDate;

	public Message() {
	}

	public Message(Long id, String text) {
		this.id = id;
		this.text = text;
		generatedDate = new Date();
	}

	public Date getGeneratedDate() {
		return generatedDate;
	}

	public void setGeneratedDate(Date generated) {
		this.generatedDate = generated;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
