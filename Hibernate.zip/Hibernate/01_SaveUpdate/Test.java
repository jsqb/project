import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		Transaction tx = session.beginTransaction();

		// insert
		Message msg = new Message(new Long(1), "Hello World");
		session.save(msg);

		// select
		Criteria criteria = session.createCriteria(Message.class);

		@SuppressWarnings("unchecked")
		List<Message> messages = criteria.list();

		for (Message m : messages) {
			System.out.println("id=("+m.getId()+") text=("+m.getText()+") date=("+m.getGeneratedDate()+")");

			if (m.getId().longValue() == 1) {
				// delete
				session.delete(m);
			} else {
				// update
				m.setGeneratedDate(new Date());
				session.update(m);
			}
		}

		tx.commit();
		HibernateUtils.close(session);
	}
}
