import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		// select
		@SuppressWarnings("unchecked")
		List<Cat> cats = session.createCriteria(Cat.class)
			.setMaxResults(50)
			.list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}

		HibernateUtils.close(session);
	}
}
