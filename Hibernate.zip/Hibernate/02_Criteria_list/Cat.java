//import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CAT")
public class Cat {

	@Id
	@Column(name = "ID", unique = true, nullable = false)
	private Long id;

	@Column(name= "NAME", nullable = false, length = 100)
	private String name;

	@Column(name= "AGE", nullable = false)
	private Integer age;

	@Column(name= "CREATED_DATE", nullable = true)
	private Date createdDate;

	public Cat() {
	}

	public Cat(long id, String name, int age) {
		this.id = new Long(id);
		this.name = name;
		this.age = new Integer(age);
		createdDate = new Date();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "Cat {id="+id+
			", name="+name+
			", age="+age+
			", createdDate="+createdDate+
			"}";
  }
}
