import static org.hibernate.criterion.Order.asc;
import static org.hibernate.criterion.Order.desc;
import static org.hibernate.criterion.Restrictions.like;

import java.util.*;
import org.hibernate.*;

public class Test {

	public static void main(String[] args) {
		Session session = HibernateUtils.getSessionFactory().openSession();

		@SuppressWarnings("unchecked")
		List<Cat> cats = session.createCriteria(Cat.class)
			.add(like("name", "Cat%"))
			.addOrder(desc("name"))
			.addOrder(asc("age"))
			.list();

		for (Cat cat : cats) {
			System.out.println("id=("+cat.getId()+") name=("+cat.getName()+") age=("+cat.getAge()+") date=("+cat.getCreatedDate()+")");
		}

		HibernateUtils.close(session);
	}
}
