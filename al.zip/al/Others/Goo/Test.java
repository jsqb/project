public class Test {
	public static void main(String[] args) {
		int count = 0;
		for (int i=1; i<Integer.MAX_VALUE; i++) {
			count += countOnes(i+"");
			if (i> 1 && i == count) {
				System.out.println(i); // Expected number is 199981
				break;
			}
		}
	}

	private static int countOnes(String value) {
		int count = 0;
		for (int i=0, len=value.length(); i<len; i++) {
			if (value.charAt(i) == '1') count++;
		}
		return count;
	}

}