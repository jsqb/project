import java.util.*;
public class Main {
	public static void main(String[] args) {
		Map<String,Integer> data = new TreeMap<String,Integer>();

		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		for (int i=0, len=s.length(); i<len; i++) {
			String c = s.charAt(i)+"";
			if (data.containsKey(c)) {
				data.put(c, data.get(c).intValue()+1);
			} else {
				data.put(c, 1);
			}
		}

		Map<String,Integer> data2 = new TreeMap<String,Integer>(new ValueComparator(data));
		for (Map.Entry<String, Integer> entry : data.entrySet()) {
			data2.put(entry.getKey(), entry.getValue());
		}
		for (Map.Entry<String, Integer> entry : data2.entrySet()) {
			System.out.println(entry.getKey());
		}
	}

private static class ValueComparator implements Comparator<String> {
    Map<String, Integer> base;
    public ValueComparator(Map<String, Integer> base) {
        this.base = base;
    }

    public int compare(String a, String b) {
				Integer o1 = base.get(a);
				Integer o2 = base.get(b);
				int n1 = o1 != null ? o1.intValue() : 0;
				int n2 = o2 != null ? o2.intValue() : 0;

        if (n1 > n2) {
            return -1;
        } else {
            return 1;
        }
    }
}
}
