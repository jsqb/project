import java.util.Arrays;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] prices = new int[n];
		for (int i=0; i<n; i++) prices[i] = sc.nextInt();

		Arrays.sort(prices);
		for (int i=n-2; i>=0; i--) {
			if (prices[i] != prices[i+1]) {
				System.out.println(prices[i]);
				break;
			}
		}
	}
}
