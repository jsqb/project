public class Test {

	public static void main(String[] args) throws Exception {
		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, 4, 4, 3, 5)+" ==> 4");
		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, 2, 3, 5, 2)+" ==> 8");
		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, 2, 3, 3, 2)+" ==> 6");

		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, -1, -1, 3, 5)+" ==> 2");
		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, -2, 3, 5, 2)+" ==> 4");
		System.out.println(Test.calcOverlappedArea(1, 2, 5, 4, 2, 3, 3, 4)+" ==> 9");
	}

	private static int calcOverlappedArea(int xa, int ya, int wa, int ha, int xb, int yb, int wb, int hb) {
		return calcOverlappedLength(xa, wa, xb, wb) * calcOverlappedLength(ya, ha, yb, hb);
	}

	private static int calcOverlappedLength(int xa, int wa, int xb, int wb) {
		if (xa > xb) {
			int tmp = xa;
			xa = xb;
			xb = tmp;

			tmp = wa;
			wa = wb;
			wb = tmp;
		}

		int xa2 = xa + wa;
		int xb2 = xb + wb;

		if (xa2 <= xb) {
			return 0;
		} else if (xa2 > xb2) {
			return xb2 - xb;
		}
		return xa2 - xb;
	}

}
