import java.math.BigInteger;

public class D {

	public static void main(String[] args) {
		for (int i=0; i<10; i++) {
			System.out.println(i+" ==> "+d(new BigInteger(i+"")));
		}
		for (int i=0; i<10; i++) {
			System.out.println((i+1)+" ==> "+d(new BigInteger("1"+i)));
		}
		System.out.println("15 ==> "+d(new BigInteger("12345")));
		System.out.println("40 ==> "+d(new BigInteger("1111111111111111111")));

		try {
			d(new BigInteger("-1"));
			System.out.println("Failed to throw an IllegalArgumentException");
		} catch (IllegalArgumentException ex) {
			System.out.println("Passed: IllegalArgumentException");
		}

		try {
			d(null);
			System.out.println("Failed to throw an IllegalArgumentException");
		} catch (IllegalArgumentException ex) {
			System.out.println("Passed: IllegalArgumentException");
		}

	}

	public static int d(BigInteger input) {
		if (input == null || input.compareTo(BigInteger.ZERO) < 0) {
			throw new IllegalArgumentException("input value must be greater or equal to 0");
		}

		long n = input.longValue();
		if (n < 10) return (int) n;

		int sum = 0;
		while (n > 0) {
			sum += n % 10;
			n /= 10;
		}
		return sum;
	}

}
