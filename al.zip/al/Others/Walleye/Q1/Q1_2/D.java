import java.math.BigInteger;

public class D {

	public static void main(String[] args) {
		long n = 1;
		for (long i=314159265358979l; i>0; i--) {
			n *= i;
		}
		System.out.println("xx ==> "+d(new BigInteger(n+"")));
	}

	public static int d(BigInteger input) {
		if (input == null || input.compareTo(BigInteger.ZERO) < 0) {
			throw new IllegalArgumentException("input value must be greater or equal to 0");
		}

		long n = input.longValue();
		if (n < 10) return (int) n;

		int sum = 0;
		while (n > 0) {
			sum += n % 10;
			n /= 10;
		}
		return sum;
	}

}
