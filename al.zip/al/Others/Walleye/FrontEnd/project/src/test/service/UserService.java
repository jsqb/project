package test.service;

import test.dao.UserDao;

public class UserService {

	private UserService() {}

	public static boolean authenticate(String username, String password) throws Exception {
		if (username == null || username.trim().length() == 0 ||
		    password == null || password.trim().length() == 0) return false;

		if (UserDao.existByName(username)) return UserDao.existByNameAndPassword(username, password);
		UserDao.insert(username, password);
		return true;
	}

}
