package test;

import java.io.*;
import java.lang.annotation.*;
import java.lang.reflect.Method;
import javax.servlet.*;
import javax.servlet.http.*;

import test.annotation.ReqMapping;

public class WebDispatcher implements Filter {

	public void init(FilterConfig filterConfig) throws ServletException {}
	public void destroy() {}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest  request  = (HttpServletRequest)  req;
		HttpServletResponse response = (HttpServletResponse) res;

		// Process JSON request only
		if (!"application/json".equals(request.getHeader("Accept"))) {
			chain.doFilter(request, response);
			return;
		}

		response.setContentType("application/json; charset=UTF-8");

		try {
			String path = getServletPath(request);
			String username = getReqParameter(request, "username");
			String data = getReqParameter(request, "data");

			for (Method m : Controller.class.getDeclaredMethods()) {
				ReqMapping reqMap = m.getAnnotation(ReqMapping.class);
				if (reqMap != null && reqMap.value().equals(path)) {
					String result = (String) m.invoke(new Controller(), username, data);
					PrintWriter out = response.getWriter();
					out.print(result);
					break;
				}
			}
		} catch (Exception ex) {
			response.sendError(500, ex.toString());
			ex.printStackTrace();
		}
	}

	private static String getServletPath(HttpServletRequest request) {
		String path = request.getRequestURI();
		String ctxPath = request.getContextPath();
		int startIndex = ctxPath == null ? 1 : ctxPath.length()+1;
		if (path.endsWith("/")) {
			path = path.substring(startIndex, path.length()-1);
		} else {
			path = path.substring(startIndex);
		}
		return path;
	}

	private static String getReqParameter(HttpServletRequest request, String name) throws UnsupportedEncodingException {
		String value = request.getParameter(name);
		if (value == null || "null".equals(value)) return null;
		return new String(value.getBytes("iso-8859-1"), "UTF-8");
	}

}
