package test.bean;

import java.text.*;
import java.util.Date;

public class Post {

	private DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	private String username;
	private String content;
	private Date createdDate;

	public Post() {}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "{\"username\":\""+username+"\""+
		", \"content\":\""+(content!=null?content.replaceAll("\n|\r","").replaceAll("\"","\\\""):null)+"\""+
		", \"createdDate\":\""+(createdDate!=null?df.format(createdDate):"")+"\"}";
	}

}
