package test.service;

import test.bean.*;
import test.dao.*;

public class PostService {

	private PostService() {}

	public static boolean post(String username, String content) throws Exception {
		if (!UserDao.existByName(username)) throw new Exception("Failed to post due to invalid username: "+username);
		if (content == null) return false;
		return PostDao.insert(username, content);
	}

	public static Posts getPosts(String username, String dummy) throws Exception {
		Posts posts = PostDao.findAll();
		if (!UserDao.existByName(username)) posts.mask();
		return posts;
	}

}
