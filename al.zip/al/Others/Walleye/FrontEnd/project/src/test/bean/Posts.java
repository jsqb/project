package test.bean;

import java.util.*;

public class Posts {

	private List<Post> posts = new ArrayList<Post>();

	public Posts() {}

	public void add(Post p) {
		posts.add(p);
	}

	public void mask() {
		for (Post p : posts) {
			String username = p.getUsername();
			p.setUsername(username != null ? username.replaceAll(".","U") : null);

			String content = p.getContent();
			p.setContent(content != null ? content.replaceAll("[^\\s]","V") : null);
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		for (int i=0, len=posts.size(); i<len; i++) {
			if (i > 0) sb.append(',');
			sb.append(posts.get(i).toString());
		}
		sb.append(']');
		return sb.toString();
	}

}
