package test.dao;

import java.sql.*;

public class UserDao {

	private UserDao() {}

	public static boolean insert(final String username, final String password) throws SQLException {
		if (username == null) return false;
		JdbcTemplate<Boolean> t = new JdbcTemplate<Boolean>("INSERT INTO PB_USER (USERNAME, PASSWORD, CREATED_DATE) VALUES (?, ?, CURRENT_TIMESTAMP)") {
			@Override
			public Boolean doInStatement(PreparedStatement st) throws SQLException {
				st.setString(1, username.toUpperCase());
				st.setString(2, password);
				return st.execute();
			}
		};
		return t.execute();
	}

	public static boolean existByName(final String username) throws SQLException {
		if (username == null) return false;
		JdbcTemplate<Boolean> t = new JdbcTemplate<Boolean>("SELECT 1 FROM PB_USER WHERE USERNAME = ?") {
			@Override
			public Boolean doInStatement(PreparedStatement st) throws SQLException {
				st.setString(1, username.toUpperCase());
				ResultSet rs = st.executeQuery();
				return rs.next();
			}
		};
		return t.execute();
	}

	public static boolean existByNameAndPassword(final String username, final String password) throws SQLException {
		if (username == null) return false;
		JdbcTemplate<Boolean> t = new JdbcTemplate<Boolean>("SELECT 1 FROM PB_USER WHERE USERNAME = ? AND PASSWORD = ?") {
			@Override
			public Boolean doInStatement(PreparedStatement st) throws SQLException {
				st.setString(1, username.toUpperCase());
				st.setString(2, password);
				ResultSet rs = st.executeQuery();
				return rs.next();
			}
		};
		return t.execute();
	}

}
