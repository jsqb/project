package test;

import test.annotation.ReqMapping;
import test.bean.ReturnValue;
import test.service.*;

public class Controller {

	@ReqMapping("Auth")
	public String authenticateUser(String username, String password) throws Exception {
		return new ReturnValue(UserService.authenticate(username, password)).toString();
	}

	@ReqMapping("Post")
	public String postContent(String username, String content) throws Exception {
		return new ReturnValue(PostService.post(username, content)).toString();
	}

	@ReqMapping("GetPosts")
	public String getPosts(String username, String password) throws Exception {
		return PostService.getPosts(username, password).toString();
	}

}
