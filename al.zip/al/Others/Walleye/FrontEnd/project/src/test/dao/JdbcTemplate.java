package test.dao;

import java.sql.*;

public class JdbcTemplate<T> {
	private String query;

	public JdbcTemplate(String query) {
		this.query = query;
	}

	public T execute() throws SQLException {
		Connection conn = null;
		try {
			conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(query);
			return doInStatement(statement);
		} finally {
			if (conn != null && !conn.isClosed()) conn.close();
		}
	}

	public T doInStatement(PreparedStatement statement) throws SQLException {
		throw new UnsupportedOperationException("doInStatement is not implemented yet.");
	}


	// ---------------------------------------------
	// Database Access Utilities
	// ---------------------------------------------

	private static boolean hasInitialized = false;

	private static void init() throws SQLException {
		if (hasInitialized == false) {
			synchronized(JdbcTemplate.class) {
				if (hasInitialized == false) {
					createTables();
					hasInitialized = true;
				}
			}
		}
	}

	private static void createTables() throws SQLException {
		try {
			Class.forName("org.hsqldb.jdbcDriver");
		} catch (ClassNotFoundException ex) {
			throw new SQLException(ex.toString());
		}

		Connection conn = null;
		Statement st = null;
		try {
			conn = getDatabaseConnection();
			conn.setAutoCommit(false);
			st = conn.createStatement();
			st.executeQuery("SELECT TOP 1 USERNAME FROM PB_USER");
		} catch (Exception ex) {
			st.execute("CREATE TABLE PB_USER (USERNAME VARCHAR(50) PRIMARY KEY, PASSWORD VARCHAR(50) NOT NULL, CREATED_DATE TIMESTAMP NOT NULL)");
			st.execute("CREATE TABLE PB_POST (USERNAME VARCHAR(50) NOT NULL, CONTENT VARCHAR(2000) NULL, CREATED_DATE TIMESTAMP NOT NULL)");
		} finally {
			st.close();
			conn.setAutoCommit(true);
			conn.close();
		}
	}

	private static Connection getConnection() throws SQLException {
		init();
		return getDatabaseConnection();
	}

	private static Connection getDatabaseConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:hsqldb:file:pastebin;shutdown=true", "sa", "");
	}

}
