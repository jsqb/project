package test.dao;

import java.sql.*;
import test.bean.*;

public class PostDao {

	private PostDao() {}

	public static boolean insert(final String username, final String content) throws SQLException {
		JdbcTemplate<Boolean> t = new JdbcTemplate<Boolean>("INSERT INTO PB_POST (USERNAME, CONTENT, CREATED_DATE) VALUES (?, ?, CURRENT_TIMESTAMP)") {
			@Override
			public Boolean doInStatement(PreparedStatement st) throws SQLException {
				st.setString(1, username);
				st.setString(2, content);
				st.execute();
				return true;
			}
		};
		return t.execute();
	}

	public static Posts findAll() throws SQLException {
		JdbcTemplate<Posts> t = new JdbcTemplate<Posts>("SELECT USERNAME, CONTENT, CREATED_DATE FROM PB_POST ORDER BY CREATED_DATE DESC") {
			@Override
			public Posts doInStatement(PreparedStatement st) throws SQLException {
				Posts posts = new Posts();
				ResultSet rs = st.executeQuery();
				while (rs.next()) {
					Post p = new Post();
					p.setUsername(rs.getString(1));
					p.setContent(rs.getString(2));
					p.setCreatedDate(rs.getTimestamp(3));
					posts.add(p);
				}
				return posts;
			}
		};
		return t.execute();
	}

}
