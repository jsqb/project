package test.bean;

public class ReturnValue {

	private boolean value;

	public ReturnValue(boolean value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "{\"value\":"+value+"}";
	}

}
