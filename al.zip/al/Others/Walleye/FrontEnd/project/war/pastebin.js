(function() {
window.$ = function (element) {
	return element && typeof element == "string" ? document.getElementById(element) : element;
};

var PasteBin = window.PasteBin = function() {
	this.loggedInUser = null;
};

PasteBin.that = null;

PasteBin.prototype = {
	login: function() {
		var username = null, password = null,
		    nodes = $("dialogContent").childNodes;
		for (var i=0; i < nodes.length; i++){
			var ch = nodes.item(i);
			if (ch.nodeType != 1 || ch.nodeName != "INPUT") continue;
			var name = ch.getAttribute("name");
			if (name == "username") {
				username = ch.value;
				if (username) username = username.toUpperCase();
			} else if (name == "password") {
				password = ch.value;
			}
		}
		PasteBin.dialog.close();

		var that = this;
		PasteBin.fn.invoke("Auth", {username:username, data:password}, function(root) {
			if (root.value) {
				that.loggedInUser = username;
				PasteBin.fn.writeCookie("pastebin_loggedInUser", username, "/");

				PasteBin.fn.hide("loginLink");
				PasteBin.fn.show("postLink");
				PasteBin.fn.show("logoutLink");
				PasteBin.fn.show("username", "User: "+username);
				that.updatePosts();
			} else {
				that.loggedInUser = null;
				alert("Either the username or password entered is incorrect.");
			}
		});
	},

	logout: function() {
		this.loggedInUser = null;
		PasteBin.fn.removeCookie("pastebin_loggedInUser", "/");

		PasteBin.fn.show("loginLink");
		PasteBin.fn.hide("postLink");
		PasteBin.fn.hide("logoutLink");
		PasteBin.fn.hide("username", "");
		this.updatePosts();
	},

	updatePosts: function() {
		PasteBin.fn.invoke("GetPosts", {username:this.loggedInUser}, function(root) {
			var posts = $("posts");
			while (posts.firstChild) posts.removeChild(posts.firstChild); // remove all posts

			for (var i=0, len=root.length; i<len; i++) {
				var post = root[i];
				var d = document.createElement("div");
				d.innerHTML = post.createdDate+" "+post.username+" "+post.content;
				posts.appendChild(d);
			}
		});
	},

	postContent: function() {
		var content = null;
		var nodes = $("dialogContent").childNodes;
		for (var i=0; i < nodes.length; i++){
			var ch = nodes.item(i);
			if (ch.nodeType != 1 || ch.nodeName != "TEXTAREA") continue;
			if (ch.getAttribute("name") == "content") {
				content = PasteBin.fn.encodeXml(ch.value);
				break;
			}
		}
		PasteBin.dialog.close();

		var that = this;
		PasteBin.fn.invoke("Post", {username:this.loggedInUser, data:content}, function(root) {
			if (root.value) {
				that.updatePosts();
			} else {
				alert("Failed to post the content entered.");
			}
		});
	}
};

PasteBin.dialog = {
	openPostDialog: function(event) {
		PasteBin.dialog.open(event);
		$("dialogContent").innerHTML = '<br>Please enter a message.<br><br>'+
		    '<textarea name="content" cols="40" rows="10"></textarea><br><br>'+
		    '<center><input type="submit" value="Post" onclick="PasteBin.that.postContent(event)"></center>';
	},

	openLoginDialog: function(event) {
		PasteBin.dialog.open(event);
		$("dialogContent").innerHTML = '<br>Please enter your username and password.<br><br>'+
		    'Username: <input type="text" name="username" size="20" value=""><br>'+
		    'Password: <input type="password" name="password" size="20" value=""><br><br>'+
		    '<center><input type="submit" value="Log In" onclick="PasteBin.that.login(event)"></center>';
	},

	open: function(event) {
		var d = $("dialog");
		d.style.left = event.clientX + "px";
		d.style.top  = event.clientY + "px";
		d.style.visibility = "visible";
	},

	close: function() {
		$("dialog").style.visibility = "hidden";
	}
};

PasteBin.fn = {
	init: function() {
		var that = PasteBin.that = new PasteBin();
		that.loggedInUser = PasteBin.fn.readCookie("pastebin_loggedInUser");
		if (that.loggedInUser) {
			PasteBin.fn.hide("loginLink");
			PasteBin.fn.show("postLink");
			PasteBin.fn.show("logoutLink");
			PasteBin.fn.show("username", "User: "+that.loggedInUser);
		}

		PasteBin.fn.addListener($("postLink"), "click", PasteBin.dialog.openPostDialog);
		PasteBin.fn.addListener($("loginLink"), "click", PasteBin.dialog.openLoginDialog);
		PasteBin.fn.addListener($("dialogClose"), "click", PasteBin.dialog.close);
		PasteBin.fn.addListener($("logoutLink"), "click", function() { that.logout(); });
		that.updatePosts();
	},

	addListener: function(element, eventType, func) {
		if(element.addEventListener) {
			element.addEventListener(eventType, func, false);
		} else if(element.attachEvent) {
			element.attachEvent("on" + eventType, func);
		}
	},

	invoke: function(path, params, load, error) {
		var xmlhttp = PasteBin.fn.createHttpRequest();
		if (xmlhttp == null) return;

		if (params == null) params = {};
		params['t'] = new Date().getTime();
		var queryStr = [];
		for (var p in params) {
			queryStr.push(p + "=" + encodeURIComponent(params[p]));
		}

		path += "?"+queryStr.join("&");

		try {
			xmlhttp.open("GET", "/pastebin/"+path, true);
			xmlhttp.setRequestHeader("Accept", "application/json");

			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4) {
					if (xmlhttp.status == 0 || xmlhttp.status == 200) {
						if (load) load(JSON.parse(xmlhttp.responseText));
					} else {
						if (error) error(xmlhttp.responseText);
					}
				}
			};
			xmlhttp.send(null);
		} catch(e) {
			alert("Not found such an URL: "+path);
		}
	},

	createHttpRequest: function() {
		if (window.ActiveXObject) {
			try { return new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try { return new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e2) { return null; }
	 		}
		} else if (window.XMLHttpRequest) {
			return new XMLHttpRequest();
		}
		return null ;
	},

	show: function(element, text) {
		var el = $(element);
		if (text != null) el.innerHTML = text;
		el.style.display ="inline";
	},

	hide: function(element, text) {
		var el = $(element);
		el.style.display ="none";
		if (text != null) el.innerHTML = text;
	},

	encodeXml: function(s) {
		if (s == null) return null;
		return s.replace(/&/g, '&amp;').replace(/</g, '&lt;')
		    .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
	},

	readCookie: function(key) {
		if (key == null || !navigator.cookieEnabled) return null;
		var cookies = document.cookie.split(";");
		for (var i=0, len=cookies.length; i < len; i++) {
			var c = cookies[i].split("=");
			if (c.length > 1 && key == PasteBin.fn.trim(c[0])) return unescape(PasteBin.fn.trim(c[1]));
		}
		return null;
	},

	writeCookie: function(key, value, path, days) {
		if (key == null || !navigator.cookieEnabled) return;

		var buf = [];
		buf.push(key + "=" + escape(value));

		if (days != 0) {
			var d = new Date();
			d.setDate(d.getDate() + days);
			buf.push("expires=" + d.toGMTString());
		}

		if (path != null) {
			buf.push("path=" + path);
		}
		document.cookie = buf.join(";");
	},

	removeCookie: function(key, path) {
		if (key == null || !navigator.cookieEnabled) return;
		document.cookie = key + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (path!=null?"; path="+path:"");
	},

	trim: function(text) {
		return (text || "").replace(/^\s+|\s+$/g, "");
	}
};
})();

PasteBin.fn.addListener(window, "load", PasteBin.fn.init);
