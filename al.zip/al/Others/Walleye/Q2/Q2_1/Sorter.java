import java.util.Arrays;
import java.util.Random;

public class Sorter {

    public void sort(int[] in) {
        Arrays.sort(in);
    }

    public void quickSort(int[] in) {
        quickSort(in, 0, in.length-1);
    }

    private void quickSort(int[] in, int low, int high) {
        if (low >= high) return;
        int l = low, h = high;

        int pivot = in[(l + h)/2];

        while (l <= h) {
            while (in[l] < pivot) l++;
            while (in[h] > pivot) h--;

            if (l <= h) {
               int tmp = in[l];
               in[l] = in[h];
               in[h] = tmp;
               l++;
               h--;
           }
       }

       if (low < h) quickSort(in, low, h);
       if (l < high) quickSort(in, l, high);
    }

    public static void main(String[] args) throws Exception {

        final int[] input = new int[1<<27];

        Random rand = new Random();

        for(int i = 0;i < input.length;i++) {
            input[i] = Math.abs(rand.nextInt())%10;
        }
        Sorter sorter = new Sorter();

        long t0 = System.nanoTime();

        //sorter.sort(input);
        sorter.quickSort(input);
        /* TODO - Make the number of milliseconds printed below as small as you can.
            Question 2.1. Using a single thread.
            Question 2.2. Using K threads.
            Question 2.3. For extra credit - can you explain why the performance improvement you see with K threads isn't nearly as high as you'd expect?
        */
        System.out.println("Sorting took " + (System.nanoTime()-t0)/1000000 + " millis");
    }
}
