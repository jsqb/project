import java.util.*;
public class NegativeGraphDiv2 {

	public static void main(String[] args) {
		NegativeGraphDiv2 s = new NegativeGraphDiv2();

		System.out.println("-9 (5) ==> "+s.findMin(
			3,
			new int[]{1,1,2,2,3,3},
			new int[]{2,3,1,3,1,2},
			new int[]{1,5,1,10,1,1},
		1));

	}

	public long findMin(int N, int[] s, int[] t, int[] weight, int charges) {

	}



}
