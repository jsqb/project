public class SumOfPower {

	public static void main(String[] args) {
		SumOfPower s = new SumOfPower();
		System.out.println("6 ==> "+s.findSum(new int[]{1,2}));
		System.out.println("10 ==> "+s.findSum(new int[]{1,1,1}));
		System.out.println("1323 ==> "+s.findSum(new int[]{3,14,15,92,65}));
		System.out.println("1210 ==> "+s.findSum(new int[]{1,2,3,4,5,6,7,8,9,10}));
	}

	public int findSum(int[] array) {
		final int N = array.length;
		int sum = 0;
		for (int i=1; i<=N; i++) {
			int s = 0;
			for (int k=0; k<i; k++) s += array[k];
			sum += s;

			for (int j=1; j<=(N-i); j++) {
				s += array[j+i-1] - array[j-1]; // add delta
				sum += s;
			}
		}
		return sum;
	}

}
