import java.util.*;
public class Test {

	public static void main(String[] args) {
		test(new BusinessTasks());
		test2(new BusinessTasks_Winner());
	}

	private static void test(BusinessTasks t) {
		long st = System.nanoTime();

		System.out.println("a ==> "+t.getTask(new String[]{"a","b","c","d"}, 2));
		System.out.println("d ==> "+t.getTask(new String[]{"a","b","c","d","e"}, 3));
		System.out.println("epsilon ==> "+t.getTask(new String[]{"alpha","beta","gamma","delta","epsilon"}, 1));
		System.out.println("a ==> "+t.getTask(new String[]{"a","b"}, 1000));
		System.out.println("n ==> "+t.getTask(new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}, 17));
		System.out.println("fxjqzznvg ==> "+t.getTask(new String[]{"zlqamum","yjsrpybmq","tjllfea","fxjqzznvg","nvhekxr","am","skmazcey","piklp","olcqvhg","dnpo","bhcfc","y","h","fj","bjeoaxglt","oafduixsz","kmtbaxu","qgcxjbfx","my","mlhy","bt","bo","q"},9000000));

		System.out.println("Time: "+(System.nanoTime()-st));
	}

	private static void test2(BusinessTasks_Winner t) {
		long st = System.nanoTime();

		System.out.println("a ==> "+t.getTask(new String[]{"a","b","c","d"}, 2));
		System.out.println("d ==> "+t.getTask(new String[]{"a","b","c","d","e"}, 3));
		System.out.println("epsilon ==> "+t.getTask(new String[]{"alpha","beta","gamma","delta","epsilon"}, 1));
		System.out.println("a ==> "+t.getTask(new String[]{"a","b"}, 1000));
		System.out.println("n ==> "+t.getTask(new String[]{"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}, 17));
		System.out.println("fxjqzznvg ==> "+t.getTask(new String[]{"zlqamum","yjsrpybmq","tjllfea","fxjqzznvg","nvhekxr","am","skmazcey","piklp","olcqvhg","dnpo","bhcfc","y","h","fj","bjeoaxglt","oafduixsz","kmtbaxu","qgcxjbfx","my","mlhy","bt","bo","q"},9000000));

		System.out.println("Time: "+(System.nanoTime()-st));
	}
}
