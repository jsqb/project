import java.util.*;
 
public class BusinessTasks_Winner {
  
  final static int oo = 100100100;
  String result;
 
  public String getTask(String[] list, int n) {
    ArrayList al = new ArrayList();
    int m = list.length;
    for (int i=0; i<m; i++) al.add(list[i]);
    int v = 0;
    while (al.size()>1) {
      int v2 = (v+n-1)%al.size();
      al.remove(v2);
      v = v2%al.size();
    }
    result = (String) al.get(0);
    return result;
  }
 
  void pp(String s) {
    System.out.println(s);
  }
 
  void pp(int s) {
    System.out.println(s);
  }
 
}