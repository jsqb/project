import java.util.*;
public class BusinessTasks {

	public String getTask(String[] list, int n) {
		int i = 0, size = list.length;
		List<String> tasks = new ArrayList<String>(size);
		for (String s : list) tasks.add(s);

		n--;
		do {
			i = (i+n) % size;
			tasks.remove(i);
		} while (--size > 1);

		return tasks.get(0);
	}

}
