import java.util.*;
public class TallPeople_Winner {
  public int[] getPeople(String[] people) {
    int[][] a;
    
    StringTokenizer st = new StringTokenizer( people[0] );
    int y = st.countTokens();
    int x = people.length;
    a = new int[x][y];
    int min = 0, max = 0;
    
    for ( int i = 0; i < x; i++ ) {
      st = new StringTokenizer( people[i] );
      
      for ( int j = 0; j < y; j++ ) {
        a[i][j] = Integer.parseInt( st.nextToken() );
      }
    }
    
    int m[] = new int[x];
    
    for ( int i = 0; i < x; i++ ) {
      m[i] = 1000000000;
      for ( int j = 0; j < y; j++ ) m[i] = Math.min( a[i][j], m[i] );
      min = Math.max( min, m[i] );
    }
    
    max = 1000000;
    m = new int[y];
    for ( int i = 0; i < y; i++ ) {
      m[i] = -1;
      for ( int j = 0; j < x; j++ ) m[i] = Math.max( a[j][i], m[i] );
      max = Math.min( max, m[i] );
    }
    
    return new int[] { min, max };
  }
  
}