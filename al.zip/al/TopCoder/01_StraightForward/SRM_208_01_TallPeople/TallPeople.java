public class TallPeople {

	public int[] getPeople(String[] people) {
		int t_max = 0;
		int[] col_maxs = null;

		for (String row : people) {
			int min = 1001, i = 0;
			if (col_maxs == null) col_maxs = new int[(row.length()+1)/2];

			String[] tokens = row.split(" ");
			for (String s : tokens) {
				int n = Integer.parseInt(s);
				if (n < min) min = n;
				if (n > col_maxs[i]) col_maxs[i] = n;
				i++;
			}
			if (min > t_max) t_max = min;
		}

		int t_min = 1001;
		for (int n : col_maxs) if (n < t_min) t_min = n;

		return new int[]{t_max, t_min};
	}
}