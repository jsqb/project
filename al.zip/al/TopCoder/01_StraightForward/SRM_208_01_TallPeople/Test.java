import java.util.*;
import java.util.Arrays;
public class Test {

	public static void main(String[] args) {
		test(new TallPeople());
		test(new TallPeople_Winner());
		test(new TallPeople());
	}

	private static void test(TallPeople t) {
		long st = System.nanoTime();

		System.out.println("[4, 7] ==> "+Arrays.toString(t.getPeople(new String[]{"9 2 3", "4 8 7"})));
		System.out.println("[4, 4] ==> "+Arrays.toString(t.getPeople(new String[]{"1 2", "4 5", "3 6"})));
		System.out.println("[1, 1] ==> "+Arrays.toString(t.getPeople(new String[]{"1 1", "1 1"})));

		System.out.println("Time: "+(System.nanoTime()-st));
	}

	private static void test(TallPeople_Winner t) {
		long st = System.nanoTime();

		System.out.println("[4, 7] ==> "+Arrays.toString(t.getPeople(new String[]{"9 2 3", "4 8 7"})));
		System.out.println("[4, 4] ==> "+Arrays.toString(t.getPeople(new String[]{"1 2", "4 5", "3 6"})));
		System.out.println("[1, 1] ==> "+Arrays.toString(t.getPeople(new String[]{"1 1", "1 1"})));

		System.out.println("Time: "+(System.nanoTime()-st));
	}

}
