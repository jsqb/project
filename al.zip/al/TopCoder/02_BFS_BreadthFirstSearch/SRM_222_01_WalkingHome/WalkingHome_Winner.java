import java.util.*;
public class WalkingHome_Winner {
  int oo = 100100100;
  int m, n;  
  char[][] b;
  int[][] d;
  boolean[][] chua;
  int sx, sy, hx, hy;
  int[] dx = {-1,0,1,0};
  int[] dy = {0,1,0,-1};  
  char[] hh = {'-','|','-','|'};
  
  boolean in(int x, int y) {
    return (0<=x&&x<m&&0<=y&&y<n);
  }
  
  boolean ok(int i, int j) {
    return (b[i][j]=='.')||(b[i][j]=='H')||(b[i][j]=='S');
  }
  
  public int fewestCrossings(String[] map) {
    m = map.length;
    n = map[0].length();
    b = new char[m][n];
    for (int i=0; i<m; i++)
    for (int j=0; j<n; j++) {
      b[i][j] = map[i].charAt(j);
      if (b[i][j]=='S') { sx = i; sy = j; }
      if (b[i][j]=='H') { hx = i; hy = j; }
    }
    
    d = new int[m][n];
    chua = new boolean[m][n];
    
    for (int i=0; i<m; i++)
    for (int j=0; j<n; j++) d[i][j] = oo;
    
    for (int i=0; i<m; i++) 
    for (int j=0; j<n; j++) chua[i][j] = true;
    
    d[sx][sy] = 0;
    chua[sx][sy] = false;
    int lastx = sx, lasty = sy;
    
    while (1==1) {
      for (int h=0; h<4; h++) {
        int x = lastx + dx[h], y = lasty + dy[h];
        int ts = 0;
        while (in(x,y)&&b[x][y]==hh[h]) {
          x = x + dx[h]; 
          y = y + dy[h];
          ts = 1;
        }
        if (!in(x,y)) continue;
        if (ok(x,y)&&chua[x][y]&&d[x][y]>d[lastx][lasty]+ts) d[x][y] = d[lastx][lasty] + ts;                
      }
      
      int min = oo;
      for (int i=0; i<m; i++)
      for (int j=0; j<n; j++)
      if (chua[i][j]&&d[i][j]<min) {
        min = d[i][j];
        lastx = i;
        lasty = j;
      }
      if (min == oo) return -1;
//      System.out.println(lastx+" "+lasty+" "+min);
      if (lastx==hx&&lasty==hy) return min;
      chua[lastx][lasty] = false;
    }
    return -1;
  }
  
}