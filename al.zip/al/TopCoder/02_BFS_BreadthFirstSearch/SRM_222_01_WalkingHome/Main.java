import static org.junit.Assert.assertEquals;
import org.junit.*;

public class Main {

	private WalkingHome t;

	@Before
	public void setUp() {
		t = new WalkingHome();
	}

	@After
	public void tearDown() {
	}

	@Test
	public void test0() {
		int n = t.fewestCrossings(new String[]
{"S.|..",
 "..|.H"});
		assertEquals(1, n);
	}

	@Test
	public void test1() {
		int n = t.fewestCrossings(new String[]
{"S.|..",
 "..|.H",
 "..|..",
 "....."});
		assertEquals(0, n);
	}

	@Test
	public void test2() {
		int n = t.fewestCrossings(new String[]
{"S.||...",
 "..||...",
 "..||...",
 "..||..H"});
		assertEquals(0, n);
	}

}
