import java.util.*;

public class SmartWordToy {

	public int minPresses(String start, String finish, String[] forbid) {
System.out.println("START");
		List<String> list = genForbidList(forbid);
		int count = 0;
		String current = start;

		for (int i=0, len=start.length(); i<len; i++) {
			char s = start.charAt(i), f = finish.charAt(i);
			int c = countPresses(list, current, i, s - 'a', f - 'a');
//System.out.println("c="+c);
			if (c == -1) return -1;
			count += c;
			current = finish.substring(0,i+1) + start.substring(i+1);
		}
		return count;
	}

	private int countPresses(List<String> list, String current, int index, int s, int f) {
//System.out.println("s="+s+", f="+f);
		int count = 0;

		Queue<Node> q = new LinkedList<Node>();
		q.offer(new Node(s, 1));

		while (!q.isEmpty()) {
			Node n = q.poll();
			if (n.level >= 26) break;

			int n1 = (n.n-1+26) % 26,
			    n2 = (n.n+1) % 26;

			String prefix = current.substring(0,index),
			       suffix = current.substring(index+1),
			       c1 = prefix + (n1 + 'a') + suffix,
			       c2 = prefix + (n2 + 'a') + suffix;
			if (list.contains(c1) || list.contains(c2)) return -1;

			if (n1 == f || n2 == f) return n.level;
			q.offer(new Node(n1, n.level+1));
			q.offer(new Node(n2, n.level+1));
		}

		return -1;
	}

	private List<String> genForbidList(String[] forbid) {
		List<String> list = new ArrayList<String>();
		genForbidList(list, forbid, 0, "");
		return list;
	}


	private void genForbidList(List<String> list, String[] forbid, int level, String str) {
		if (level >= forbid.length) {
			list.add(str);
			return;
		}

		for (int i=0; i < forbid[level].length(); i++) {
			str += forbid[level].charAt(i);
			genForbidList(list, forbid, level+1, str);
		}
	}

	private class Node {
		int n;
		int level;
		public Node(int n, int level) {
			this.n = n;
			this.level = level;
		}
	}

}