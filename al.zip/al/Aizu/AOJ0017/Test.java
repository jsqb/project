import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()) {
			String s1 = sc.nextLine();
			for (int i=1; i<26; i++) {
				String s2 = decode(s1, i);
				if (s2.indexOf("the") != -1 || s2.indexOf("this") != -1 || s2.indexOf("that") != -1) {
					System.out.println("("+i+") "+s2);
					break;
				}
			}
		}
	}

	private static String decode(String s, int n) {
		StringBuilder sb = new StringBuilder();
		for (int i=0,len=s.length(); i<len; i++) {
			char c = s.charAt(i);
			if (c >= 'a' && c <= 'z') {
				c = (char) ((c - n) % 26 + 'a');
			}
			sb.append(c);
		}
		return sb.toString();
	}
}
