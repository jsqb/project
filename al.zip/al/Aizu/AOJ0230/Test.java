import java.util.*;
public class Test {
	public static void main(String[] args) {
		new Test().exec();
	}
	void exec() {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;

			int[][] a = new int[2][n];
			for (int y=0; y<2; y++) {
				for (int x=0; x<n; x++) {
					a[y][x] = sc.nextInt();
				}
			}

			List<String> h = new ArrayList<String>();
			Queue<State> q = new LinkedList<State>();
			int count = -1;

			q.offer(new State(0, 0, 0)); // start from upper building
			q.offer(new State(0, 1, 0)); // start from lower building
			while (!q.isEmpty()) {
				State s = q.poll();
				if (h.contains(s.toString())) continue;

				if (s.x >= n) {
					count = s.c;
					break;
				}
				h.add(s.toString());

				for (int i=2; i>=0; i--) {
					State s1 = s.jump(a, i);
					q.offer(s1);
				}
			}
			System.out.println(count > -1 ? count : "NA");
		}
	}

	class State {
		int x, y, c;
		State (int x0, int y0, int c0) {
			x = x0;
			y = y0;
			c = c0;
		}

		State jump(int[][] a, int dx) {
			int y1 = 1 - y;
			int x1 = x + dx;
			int h = a[0].length;
			for (; x1<h-1 && a[y1][x1] == 1 && a[y1][x1+1] == 1; x1++);
			for (; x1>0 && x1<h && a[y1][x1] == 2; x1--);
			return new State(x1, y1, c+1);
		}

		public String toString() {
			return x+":"+y;
		}
	}
}