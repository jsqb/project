import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			sc.nextLine();
			char[][] a = new char[n][n];
			for (int i=0; i<n; i++) {
				String l = sc.nextLine();
				for (int j=0; j<n; j++) {
					a[i][j] = l.charAt(j);
				}
			}

			int[][] b = new int[n][n];
			for (int i=0; i<n; i++) {
				if (a[0][i] == '.') b[0][i] = 1;
				if (a[i][0] == '.') b[i][0] = 1;
			}

			int max = 0;
			for (int i=1; i<n; i++) {
				for (int j=1; j<n; j++) {
					if (a[i][j] == '*') continue;
					b[i][j] = Math.min(Math.min(b[i-1][j-1], b[i-1][j]), b[i][j-1]) + 1;
					if (b[i][j] > max) max = b[i][j];
				}
			}

			System.out.println(max);
		}
	}
}