import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int[] n = new int[]{sc.nextInt(), sc.nextInt()};
			if (n[0] == 0 && n[1] == 0) break;

			if (n[0] < n[1]) swap(n);

			int count = 0;
			while (n[1] != 0) {
				n[0] = n[0] % n[1];
				swap(n);
				count++;
			}
			System.out.println(n[0]+" "+count);
		}
	}

	static void swap(int[] n) {
		int t = n[0];
		n[0] = n[1];
		n[1] = t;
	}
}
