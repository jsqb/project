// # of ODD vertices
// 0 => Euler Circuit (start and end are same node)
// 2 => Euler Path (end node is different from start)
import java.util.*;
public class Test {
	public static void main(String[] args) {
		new Test().exec();
	}

	void exec() {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			int[] nodes = new int[101];
			while (true) {
				int a = sc.nextInt(), b = sc.nextInt();
				if (a == 0 && b == 0) break;
				nodes[a]++;
				nodes[b]++;
			}

			int odd = 0;
			for (int i=1; i<=100; i++) {
				if (nodes[i] % 2 == 1) odd++;
			}
			System.out.println(odd != 2 ? "NG" : (nodes[1]%2==1 && nodes[2]%2==1 ? "OK":"NG"));
		}
	}

	class Node {
		List<Integer> edges = new ArrayList<Integer>();
		void addEdge(int id) {
			//if (!edges.contains(id)) edges.add(id);
			edges.add(id);
		}
	}
}