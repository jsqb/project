import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack<Integer> s = new Stack<Integer>();
		while (sc.hasNext()) {
			int n = sc.nextInt();
			if (n == 0) {
				System.out.println(s.pop());
			} else {
				s.push(n);
			}
		}
	}
}