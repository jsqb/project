import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			String[] l = sc.nextLine().split(",");
			double[] x = new double[5], y = new double[5];
			for (int i=0; i<4; i++) {
				x[i] = Double.parseDouble(l[i*2]);
				y[i] = Double.parseDouble(l[i*2+1]);
			}

			int count = 0;
			boolean hasInc = true;
			for (int i=0; i<4; i++) {
				int ni = (i+1)%4;
				if (i > 0 && x[i] <= x[ni] != hasInc) count++;
				hasInc = x[i] <= x[ni];
			}
			if (count < 3) {
				count = 0;
				for (int i=0; i<4; i++) {
					int ni = (i+1)%4;
					if (i > 0 && y[i] <= y[ni] != hasInc) count++;
					hasInc = y[i] <= y[ni];
				}
			}
			System.out.println(count < 3 ? "YES" : "NO");
		}
	}
}