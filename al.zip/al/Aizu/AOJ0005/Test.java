import java.util.*;
public class Test {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			int g = gcd(a, b);
			System.out.println(g+" "+((long)a*b/g));
		}
	}

	private static int gcd(int a, int b) {
		if (a < b) {
			int t = a;
			a = b;
			b = t;
		}

		while (b != 0) {
			int r = a % b;
			a = b;
			b = r;
		}

		return a;
	}
}
