import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int a = sc.nextInt(), b = sc.nextInt();
			if (a == 0 && b == 0) break;

			boolean[][] uc = new boolean[a+1][b+1];
			int[][] c = new int[a+1][b+1];
			int n = sc.nextInt();
			for (int i=0; i<n; i++) {
				uc[sc.nextInt()-1][sc.nextInt()-1] = true;
			}

			c[a-1][b-1] = 1;
			for (int i=a-1; i>=0; i--) {
				for (int j=b-1; j>=0; j--) {
					if ((i==a-1 && j==b-1) || uc[i][j]) continue;
					c[i][j] = c[i][j+1] + c[i+1][j];
				}
			}

/*
for (int i=0; i<=a; i++) {
	for (int j=0; j<=b; j++) {
		System.out.print("["+c[i][j]+"]");
	}
	System.out.println();
}
*/
			System.out.println(c[0][0]);
		}
	}
}