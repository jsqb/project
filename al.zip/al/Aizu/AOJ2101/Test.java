import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;

			int s = -n;
			for (int i=1; i*i<=n; i++) {
				if (n % i == 0) {
					s += i + n/i;
					if (i == n/i) s -= i;
				}
			}
			System.out.println(s<n?"deficient number":(s>n?"abundant number":"perfect number"));
		}
	}
}