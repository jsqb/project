import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			int[] a = new int[n];
			for (int i=0; i<n; i++) a[i] = sc.nextInt();

			int v = sc.nextInt(), lo=0, hi=n-1, c = 0;

			while (lo <= hi) {
				c++;
				int mi = (lo + hi) / 2;
				int mv = a[mi];
				if (v < mv) hi = mi-1;
				else if (v > mv) lo = mi+1;
				else break;
			}

			System.out.println(c);
		}
	}
}