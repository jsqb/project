import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;

			PriorityQueue<Weight> q = new PriorityQueue<Weight>(1, new QueueComparator());
			for (int i=0; i<n; i++) {
				int m = sc.nextInt(), a = sc.nextInt(), b = sc.nextInt();
				q.offer(new Weight(a, m));
				q.offer(new Weight(b, -m));
			}

			int total = 0;
			while (!q.isEmpty()) {
				total += q.poll().m;
				if (total > 150) break;
			}

			System.out.println(total > 150 ? "NG" : "OK");
		}
	}

	static class Weight {
		int t, m;
		Weight(int t, int m) {
			this.t = t;
			this.m = m;
		}
	}

	static class QueueComparator implements Comparator<Weight> {
		public int compare(Weight w1, Weight w2) {
			return w1.t - w2.t; // asc by time
		}
	}

}
