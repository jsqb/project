import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for (int i=0; i<n; i++) {
			int[] a = new int[2];
			boolean isNoGood = false;
			for (int j=0; j<10; j++) {
				int b = sc.nextInt(), k;
				for (k=0; k<2; k++) {
					if (b > a[k]) {
						a[k] = b;
						break;
					}
				}
				if (k == 2) {
					isNoGood = true;
					//break; // do no break here to read all remaining values
				}
			}
			System.out.println(isNoGood ? "NO" : "YES");
		}
	}
}