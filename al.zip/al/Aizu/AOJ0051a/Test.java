import java.util.*;
public class Test {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		for (int i=0; i<n; i++) {
			String s = sc.nextLine();
			int[] a = new int[8], b = new int[8];
			for (int j=0; j<8; j++) a[j] = s.charAt(j)-'0';

			Arrays.sort(a);
			int n1 = toNum(a);

			for (int j=0; j<8; j++) b[7-j] = a[j];
			int n2 = toNum(b);

			System.out.println(n2-n1);
		}
	}

	static int toNum(int[] a) {
		int n = 0;
		for (int i=0; i<a.length; i++) {
			n = n * 10 + a[i];
		}
		return n;
	}
}