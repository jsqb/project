import java.util.*;
public class Test {
	static int INF = 100000;
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			int m = sc.nextInt();
			sc.nextLine();

			Node[] ns = new Node[n];
			for (int i=0; i<m; i++) {
				String[] nums = sc.nextLine().split(",");
				int a = Integer.parseInt(nums[0]), b = Integer.parseInt(nums[1]), d = Integer.parseInt(nums[2])/100-1;
				if (ns[a] == null) ns[a] = new Node(a);
				if (ns[b] == null) ns[b] = new Node(b);
				ns[a].addEdge(b, d);
				ns[b].addEdge(a, d);
			}

			ns[0].isUsed = true;
			ns[0].cost = 0;

			int total = 0;
			while (true) {
				int min = INF, dest = -1;
				for (int i=0; i<n; i++) if (ns[i].isUsed == false) ns[i].cost = INF;
				for (int i=0; i<n; i++) {
					Node s = ns[i];
					if (s.isUsed == false) continue;
					for (Edge e : s.edges) {
						Node t = ns[e.id];
						if (t.isUsed == false && t.cost > e.dist + s.cost) {
							t.cost = e.dist + s.cost;
							if (min > t.cost) {
								min = t.cost;
								dest = e.id;
							}
						}
					}
				}

				if (dest == -1) break;
				total += ns[dest].cost;
				ns[dest].isUsed = true;
				ns[dest].cost = 0;
			}

			System.out.println(total);
		}
	}

	static class Node {
		int id, cost = INF;
		boolean isUsed = false;
		List<Edge> edges = new ArrayList<Edge>();
		Node(int id0) {
			id = id0;
		}
		void addEdge(int id, int dist) {
			edges.add(new Edge(id, dist));
		}
	}

	static class Edge {
		int id, dist;
		Edge(int id0, int dist0) {
			id = id0;
			dist = dist0;
		}
	}
}
