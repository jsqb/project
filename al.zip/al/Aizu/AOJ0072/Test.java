import java.util.*;
public class Test {
	static int INF = 100000;
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			int m = sc.nextInt();
			sc.nextLine();

			int[][] d = new int[n][n];
			int[] cost = new int[n];
			boolean[] used = new boolean[n];
			for (int i=0; i<n; i++) cost[i] = INF;

			for (int i=0; i<m; i++) {
				String[] nums = sc.nextLine().split(",");
				int a = Integer.parseInt(nums[0]), b = Integer.parseInt(nums[1]), dist = Integer.parseInt(nums[2])/100-1;
				d[a][a] = 0;
				d[a][b] = d[b][a] = dist;
			}

			used[0] = true;
			cost[0] = 0;

			int total = 0;
			while (true) {
				int min = INF, dest = -1;
				for (int i=0; i<n; i++) if (used[i] == false) cost[i] = INF;
				for (int i=0; i<n; i++) {
					for (int j=0; j<n; j++) {
						if (used[i] == true && d[i][j] > 0 && d[i][j] < INF && cost[j] > d[i][j] + cost[i]) {
							cost[j] = d[i][j] + cost[i];
							if (min > cost[j]) {
								min = cost[j];
								dest = j;
							}
						}
					}
				}

				if (dest == -1) break;
				total += cost[dest];
				used[dest] = true;
				cost[dest] = 0;
			}

			System.out.println(total);
		}
	}
}
