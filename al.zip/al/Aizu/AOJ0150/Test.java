import java.util.*;
public class Test {
	static int[] pt = new int[10001], p = new int[10001];
	public static void main(String[] args) {
		for (int i=2,j=0; i<10001 && j<10001; i++) {
			if (pt[i] == 0) {
				p[j++] = i;
				for (int k=i+i; k<10001; k+=i) pt[k] = 1;
			}
		}

		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;

			for (int i=n; i>0; i--) {
				if (p[i] > n) continue;
				if (p[i] == p[i-1]+2) {
					System.out.println(p[i-1]+" "+p[i]);
					break;
				}
			}
		}
	}
}