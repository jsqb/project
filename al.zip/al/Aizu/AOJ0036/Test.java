import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			int[][] a = new int[8][8];
			for (int i=0; i<8; i++) {
				String s = sc.nextLine();
				for (int j=0; j<8; j++) a[i][j] = (s.charAt(j)=='0'?0:1);
			}

			char b = ' ';
			loop1:for (int j=0; j<8; j++) {
				for (int i=0; i<8; i++) {
					if (a[i][j] == 1) {
						if (a[i][j+1] == 0) {
							b = a[i+1][j+1] == 0 ? 'B' : 'F';
						} else {
							if (a[i+1][j+1] == 1) {
								b = a[i+1][j] == 1 ? 'A' : 'E';
							} else {
								if (a[i+1][j] == 1) {
									b = 'D';
								} else {
									b = a[i][j+2] == 1 ? 'C' : 'G';
								}
							}
						}
						break loop1;
					}
				}
			}
			System.out.println(b);
			if (sc.hasNext()) sc.nextLine();
		}
	}
}