import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			boolean[][] a = new boolean[12][12];
			for (int i = 0; i<12; i++) {
				String s = sc.nextLine();
				for (int j = 0; j<12; j++) a[i][j] = s.charAt(j) == '1';
			}

			int c = 0;
			for (int i = 0; i<12; i++) {
				for (int j = 0; j<12; j++) {
					if (a[i][j]) {
						fill(a, i, j);
						c++;
					}
				}
			}
			System.out.println(c);
			if (sc.hasNext()) sc.nextLine();
		}
	}

	static void fill(boolean[][] a, int y, int x) {
		if (y < 0 || y > 11 || x < 0 || x > 11 || !a[y][x]) return;
		a[y][x] = false;
		fill(a, y-1, x);
		fill(a, y, x-1);
		fill(a, y, x+1);
		fill(a, y+1, x);
	}
}