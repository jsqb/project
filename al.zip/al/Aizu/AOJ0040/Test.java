import java.util.*;
public class Test {
	static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		sc.nextLine();
		for (int i=0; i<n; i++) {
			String s = sc.nextLine(), e = null;
			loop1:for (int j=0; j<26; j++) {
				for (int k=0; k<26; k++) {
					e = encrypt(s, j, k);
					if (e.indexOf("this") >= 0 || e.indexOf("that") >= 0) break loop1;
				}
			}
			System.out.println(e);
		}
	}

	static String encrypt(String s, int a, int b) {
		StringBuilder sb = new StringBuilder();
		for (int i=0; i<s.length(); i++) {
			int c = ALPHA.indexOf(s.charAt(i));
			sb.append(c == -1 ? ' ' : ALPHA.charAt((a * c + b) % 26));
		}
		return sb.toString();
	}
}