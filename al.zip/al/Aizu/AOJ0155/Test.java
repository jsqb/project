import java.util.*;
public class Test {
	static final int INF = 100000;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;

			Node[] nodes = new Node[n];
			for (int i=0; i<n; i++) {
				nodes[i] = new Node(sc.nextInt()-1, sc.nextInt(), sc.nextInt());
			}

			for (int i=0; i<n-1; i++) {
				Node n0 = nodes[i];
				for (int j=i+1; j<n; j++) {
					Node n1 = nodes[j];
					double d = Math.sqrt((n1.x-n0.x)*(n1.x-n0.x) + (n1.y-n0.y)*(n1.y-n0.y));
					if (d <= 50.0) {
						n0.addEdge(n1, (int)d);
						n1.addEdge(n0, (int)d);
					}
				}
			}

			int m = sc.nextInt(), start, goal;
			for (int i=0; i<m; i++) {
				start = sc.nextInt()-1;
				goal = sc.nextInt()-1;

				dijkstra(nodes, goal);

				String path = "";
				boolean hasReached = false;
				Node nd = nodes[start];
				while (nd != null) {
					path += (nd.b+1) + " ";
					if (nd.b == goal) {
						hasReached = true;
						break;
					}
					nd = nd.next;
				}
				System.out.println(hasReached ? path.trim() : "NA");
			}
		}
	}

	static void dijkstra(Node[] nodes, int goal) {
		for (int i=0; i<nodes.length; i++) {
			nodes[i].cost = INF;
			nodes[i].next = null;
		}
		nodes[goal].cost = 0;

		// dijkstra
		while (true) {
			Node minNode = null;
			int minCost = INF;
			for (Node nd : nodes) {
				if (!nd.isUsed && nd.cost < minCost) {
					minCost = nd.cost;
					minNode = nd;
				}
			}

			if (minNode == null) break;
			minNode.isUsed = true;

			for (Edge ed : minNode.edges) {
				int newCost = minNode.cost + ed.cost;
				if (newCost < ed.node.cost) {
					ed.node.cost = newCost;
					ed.node.next = minNode;
				}
			}
		}
	}

	static class Node {
		int b, x, y, cost = INF;
		boolean isUsed = false;
		Node next;
		List<Edge> edges = new ArrayList<Edge>();

		Node (int b, int x, int y) {
			this.b = b;
			this.x = x;
			this.y = y;
		}

		void addEdge(Node node, int cost) {
			edges.add(new Edge(node, cost));
		}
	}

	static class Edge {
		Node node; // destination node
		int cost;

		Edge (Node node, int cost) {
			this.node = node;
			this.cost = cost;
		}
	}
}