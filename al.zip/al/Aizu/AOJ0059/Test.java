import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			double[] x = new double[4], y = new double[4];
			for (int i=0; i<4; i++) {
				x[i] = sc.nextDouble();
				y[i] = sc.nextDouble();
			}

			System.out.println((isInRect(x,y,0,0,2,3)||isInRect(x,y,0,1,2,3)||isInRect(x,y,1,0,2,3)||isInRect(x,y,1,1,2,3)||isInRect(x,y,2,2,0,1))?"YES":"NO");
		}
	}

	static boolean isInRect(double[] x, double[] y, int ix, int iy, int rx, int ry) {
		return x[rx] <= x[ix] && x[ry] >= x[ix] && y[rx] <= y[iy] && y[ry] >= y[iy];
	}
}