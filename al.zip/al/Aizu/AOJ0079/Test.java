import java.util.*;
public class Test {
	public static void main(String[] args) {
		double[] x = new double[21], y = new double[21];
		int n = 0;

		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			String[] l = sc.nextLine().split(",");
			x[n] = Double.parseDouble(l[0]);
			y[n++] = Double.parseDouble(l[1]);
		}
		x[n] = x[0];
		y[n] = y[0];

		double s = 0.0;
		for (int i=0; i<n; i++) {
			s += ((y[i]+y[i+1]) * (x[i]-x[i+1]) / 2.0);
		}
		System.out.println(Math.abs(s));
	}
}