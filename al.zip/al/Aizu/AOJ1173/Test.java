import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			Stack<Character> stack = new Stack<Character>();
			String s = sc.nextLine();
			for (int i=0, len=s.length(); i<len; i++) {
				char c = s.charAt(i);
				if (c == '(' || c == '[') {
					stack.push(c);
				} else if (c == ')' || c == ']') {
					if (stack.empty()) {
						stack.push('*'); // dummy
						break;
					}
					char e = stack.peek();
					if ((c == ')' && e != '(') || (c == ']' && e != '[')) break;
					stack.pop();
				}
			}
			System.out.println(stack.empty() ? "yes" : "no");
		}
	}
}