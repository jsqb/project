import java.util.*;
public class Test {
	static Map<String, Integer> map = new HashMap<String, Integer>();
	static int[] dirs = new int[]{1,-1,4,-4};

	public static void main(String[] args) {
		map.put("01234567", 0);
		Queue q = new Queue();
		q.enqueue("01234567");
		while (!q.isEmpty()) {
			String s = q.dequeue();
			String t;
			int cnt = map.get(s)+1;
			for (int i=0; i<4; i++) {
				if ((t = move(s, dirs[i])) != null && !map.containsKey(t)) {
					q.enqueue(t);
					map.put(t, cnt);
				}
			}
		}

		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			String n = sc.nextLine().replace(" ","");
			System.out.println(map.get(n));
		}
	}

	static String move(String s, int n) {
		int p0 = s.indexOf("0"), p1 = p0+n;
		if (p1 < 0 || p1 > 7 || (p0==3 && p1==4) || (p0==4 && p1==3)) return null;
		char c1 = s.charAt(p1);
		String t = "";
		for (int i=0; i<8; i++) {
			if (i == p0) t += c1;
			else if (i == p1) t += '0';
			else t += s.charAt(i);
		}
		return t;
	}

	static class Queue {
		String[] q = new String[10000];
		int tail = 0;

		void enqueue(String s) {
			q[tail++] = s;
		}

		String dequeue() {
			if (tail == 0) return null;
			tail--;
			String s = q[0];
			System.arraycopy(q,1, q,0, tail);
			return s;
		}

		boolean isEmpty() {
			return tail == 0;
		}
	}

}