import java.util.*;
public class Test {
	int[] prime = new int[104730], s = new int[10001];
	public static void main(String[] args) {
		new Test().exec();
	}

	void exec() {
		for (int i=2, j=1; i<104730 && j<10001; i++) {
			if (prime[i] == 0) {
				s[j] = s[j-1] + i;
				j++;
			}
			for (int k=i+i; k < 104730; k+=i) prime[k] = 1;
		}

		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			System.out.println(s[n]);
		}
	}
}