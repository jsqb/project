import java.util.*;
public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			int a = sc.nextInt(), b = sc.nextInt(), c = sc.nextInt();
			int[] d = new int[n];
			for (int i=0; i<n; i++) d[i] = sc.nextInt();

			Arrays.sort(d);
			int tc = c, ta = a;
			double max = 0.0, r = 0.0;
			for (int i=n-1; i>=0; i--) {
				tc += d[i];
				ta += b;
				r = (double)tc / ta;
				if (max >= r) break;
				max = r;
			}
			System.out.println((int)max);
		}
	}
}