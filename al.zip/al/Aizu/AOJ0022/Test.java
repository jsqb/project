import java.util.*;
public class Test {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		while (true) {
			int n = sc.nextInt();
			if (n == 0) break;
			int[] a = new int[n];
			for (int i=0; i<n; i++) a[i] = sc.nextInt();

			int max = Integer.MIN_VALUE;
			for (int i=0; i<n; i++) {
				for (int j=1,len=n-i; j<=len; j++) {
					int s = 0;
					for (int k=i; k<(i+j); k++) s += a[k];
					if (s > max) max = s;
				}
			}
			System.out.println(max);
		}
		sc.close();
	}

}
