class Solution {

	int x = 0, preN = 0;
	Train t = new Train();
	Classifier c = null;
	public int solution(int N) {
		String s = null;
		try {
			if (c == null) c = new Classifier(t);

			if (x > 0) {
				t.train(N+"", new String[]{preN+""});
				c.update();
			}

			s = c.classify(new String[]{N+""});
			preN = N;
			x++;
		} catch (Exception ex) {}

		return s != null ? s.charAt(0) - '0' : 0;
	}

}
