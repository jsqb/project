import java.io.*;
import java.util.*;

public class Classifier {

	private Map<String, Integer> docCountByCat = new HashMap<String, Integer>();
	private Map<String, Map<String, Integer>> wordCountByCat = new HashMap<String, Map<String, Integer>>();
	private Map<String, Integer> totalWordCountByCat = new HashMap<String, Integer>();
	private int vocabularySize = 0;
	private Train train = null;

	public static void main(String[] args) throws Exception {
		Train t = new Train();
		t.train("Positive", new String[]{"This", "is", "an", "apple"});
		t.train("Positive", new String[]{"This", "is", "an", "apple", "juice"});
		t.train("Negative", new String[]{"He", "is", "a", "boy"});
		t.train("Negative", new String[]{"She", "is", "a", "girl"});
		t.train("Negative", new String[]{"They", "are", "boy", "and", "girl"});

		Classifier c = new Classifier(t);

		String[] A = new String[]{"This", "is", "a", "small", "boy"};
		System.out.println("Class ==> '"+c.classify(A)+"' expected(Negative)");

		A = new String[]{"They", "are", "apple", "and", "juice"};
		System.out.println("Class ==> '"+c.classify(A)+"' expected(Positive)");

		A = new String[]{"This", "is", "an", "apple"};
		System.out.println("Class ==> '"+c.classify(A)+"' expected(Positive)");
	}

	public Classifier(Train t) throws Exception {
		this.train = t;
		this.update();
	}

	public void update() throws Exception {
		this.docCountByCat = train.docCountByCat;
		this.wordCountByCat = train.wordCountByCat;

		Set<String> vocabulary = new HashSet<String>();

		for (Map.Entry<String, Map<String, Integer>> ent1 : wordCountByCat.entrySet()) {
			String category = ent1.getKey();
			int totalWordCount = 0;

			Map<String, Integer> wordCount = ent1.getValue();
			for (Map.Entry<String, Integer> ent2 : wordCount.entrySet()) {
				String word = ent2.getKey();
				vocabulary.add(word); // add if the word is not already present.

				Integer countInt = ent2.getValue();
				if (countInt != null) totalWordCount += countInt.intValue();
			}

			totalWordCountByCat.put(category, new Integer(totalWordCount));
		}

		vocabularySize = vocabulary.size();
	}

	public String classify(String[] words) {
		double bestScore = Double.NEGATIVE_INFINITY;
		String bestCategory = null;

		for (Map.Entry<String, Integer> entry : docCountByCat.entrySet()) {
			String category = entry.getKey();
			double score = categoryScore(category, words);
//System.out.println(category+": "+score);
			if (score > bestScore) {
				bestScore = score;
				bestCategory = category;
			}
		}
		return bestCategory;
	}

	private double categoryScore(String category, String[] words) {
		double score = Math.log(priorProb(category));
//System.out.println("cat["+category+"]: "+score);
		for (String word : words) {
			score += Math.log(wordProb(category, word));
//System.out.println("cat["+category+"] word["+word+"]: score="+Math.log(wordProb(category, word)));
		}
    return score;
	}

	// P(category)
	private double priorProb(String category) {
		return getMapNumber(docCountByCat, category) / (double) getMapTotalNumber(docCountByCat);
	}

	// P(word|category)
	private double wordProb(String category, String word) {
		return (getWordCount(category, word) + 1) /
		       (double) (getMapNumber(totalWordCountByCat, category) + vocabularySize);
	}

	private int getWordCount(String category, String word) {
		if (category == null || word == null) return 0;

		Integer count = null;
		Map<String, Integer> wordCount = wordCountByCat.get(category);
		if (wordCount != null) {
			count = wordCount.get(word);
		}
		return count != null ? count.intValue() : 0;
	}

	private int getMapNumber(Map<String, Integer> map, String key) {
		if (key == null) return 0;
		Integer num = map.get(key);
		return num != null ? num.intValue() : 0;
	}

	private int getMapTotalNumber(Map<String, Integer> map) {
		int sum = 0;
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			Integer num = entry.getValue();
			if (num != null) sum += num.intValue();
		}
		return sum;
	}

}
