// Generate Train data

import java.io.*;
import java.util.*;

public class Train {

	// Document count by category
	// String: category name
	// Integer: number of documents associated to the category
	public Map<String, Integer> docCountByCat = new HashMap<String, Integer>();

	// Word count by category
	// String: category name
	// String: word
	// Integer: number of words appeared in documents associated to the category
	public Map<String, Map<String, Integer>> wordCountByCat = new HashMap<String, Map<String, Integer>>();

	public static void main(String[] args) throws Exception {
		Train t = new Train();
		t.train("Positive", new String[]{"This", "is", "an", "apple"});
		t.train("Positive", new String[]{"This", "is", "an", "apple", "juice"});
		t.train("Negative", new String[]{"He", "is", "a", "boy"});
		t.train("Negative", new String[]{"She", "is", "a", "girl"});
		t.train("Negative", new String[]{"They", "are", "boy", "and", "girl"});
	}

	public void train(String category, String[] words) throws Exception {
		countDocument(category);
		for (String word : words) {
			countWord(category, word);
		}
	}

	private void countDocument(String category) {
		if (category == null) return;
		Integer count = docCountByCat.get(category);
		if (count == null) {
			count = new Integer(1);
		} else {
			count = new Integer(count.intValue()+1);
		}
		docCountByCat.put(category, count);
	}

	private void countWord(String category, String word) {
		if (category == null || word == null) return;

		Map<String, Integer> wordCount = wordCountByCat.get(category);
		if (wordCount == null) {
			wordCount = new HashMap<String, Integer>();
			wordCount.put(word, new Integer(1));
		} else {
			Integer count = wordCount.get(word);
			if (count == null) {
				count = new Integer(1);
			} else {
				count = new Integer(count.intValue()+1);
			}
			wordCount.put(word, count);
		}
		wordCountByCat.put(category, wordCount);
	}

}
