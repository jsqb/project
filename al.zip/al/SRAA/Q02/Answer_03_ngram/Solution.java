import java.util.*;

public class Solution {

	private static final int[] NUMS =
	{ 0,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0,1,3,2,3
	 ,2,4,0,3,1,2,3,4,0,1,3,2,3,4,0,3,1,2,3,4
	 ,1,0,1,3,2,3,2,4,0,3,1,2,3,4,0,1,3,2,3,4
	 ,0,3,1,2,3,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0
	 ,1,3,2,3,0,4,0,3,1,2,3,4,0,1,3,2,3,1,4,0 };

	private static List<Integer> nums = new ArrayList<Integer>();
	private static Map<String, int[]> hash = new HashMap<String, int[]>();
	static {
		for (int n : NUMS) nums.add(n);

		for (int i=0; i<NUMS.length-2; i++) {
			String key = ""+NUMS[i]+NUMS[i+1];
			updateHash(key, NUMS[i+2]);
		}
	}

	private static void updateHash(String key, int value) {
		int[] vals = hash.get(key);
		if (vals == null) {
			vals = new int[5];
			hash.put(key, vals);
		}
		vals[value]++;
	}

	public int solution(int N) {
		// update hash table
		int size = nums.size();
		String key = ""+nums.get(size-2)+nums.get(size-1);
		updateHash(key, N);

		// predict next number
		key = ""+nums.get(size-1)+N;
		nums.add(N);

		int[] vals = hash.get(key);
		int maxVal = 0, maxIdx = 0;
		for (int i=0; vals != null && i<vals.length; i++) {
			if (vals[i] > maxVal) {
				maxVal = vals[i];
				maxIdx = i;
			}
		}

		return maxIdx;
	}

}
