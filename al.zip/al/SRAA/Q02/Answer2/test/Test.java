public class Test {

	public static void main(String args[]) throws Exception {
		DecisionTree dt = new DecisionTree();

		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});
		dt.add(new String[]{"3","1","1"});
		dt.add(new String[]{"5","2","3"});
		dt.add(new String[]{"7","3","5"});
		dt.add(new String[]{"9","4","7"});
		dt.add(new String[]{"1","0","9"});

		DecisionTreeNode tree = dt.grow('e'); // Entropy
		dt.prune();

		System.out.println("var tree = "+tree+";");

		System.out.println("1: Class="+dt.classify(new String[]{"0","9"}));
		System.out.println("2: Class="+dt.classify(new String[]{"1","1"}));
		System.out.println("3: Class="+dt.classify(new String[]{"2","3"}));
		System.out.println("4: Class="+dt.classify(new String[]{"3","5"}));
		System.out.println("5: Class="+dt.classify(new String[]{"4","7"}));
		System.out.println("6: Class="+dt.classify(new String[]{"0","9"}));
		System.out.println("7: Class="+dt.classify(new String[]{"1","1"}));
	}

}
