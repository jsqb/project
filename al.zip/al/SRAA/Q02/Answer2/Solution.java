class Solution {

	int x = 0, preN = 0;
	DecisionTree dt = new DecisionTree();
	DecisionTreeNode tree = null;

	public int solution(int N) {
		if (x > 0) dt.add(new String[]{N+"",preN+""});

		if (x < 100 || x % 100 == 0) {
			tree = dt.grow('e'); // Entropy
			//dt.prune();
		}

		String s = dt.classify(new String[]{N+""});
		preN = N;
		x++;

		return s != null ? s.charAt(0) - '0' : 0;
	}

}
