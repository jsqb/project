import java.util.*;

public class DecisionTree {

	private List<Record> records = new ArrayList<Record>();
	private DecisionTreeNode tree = null;

	public DecisionTree() {
	}

	public DecisionTree(DecisionTreeNode tree) {
		this.tree = tree;
	}

	public void add(String[] record) {
		add(record, 1);
	}

	public void add(String[] record, int count) {
		this.records.add(new Record(record, count));
	}

	public DecisionTreeNode grow(char impurityMetricType) {
		this.tree = grow(impurityMetricType, null, null);
		return this.tree;
	}

	@SuppressWarnings("unchecked")
	public DecisionTreeNode grow(char impurityMetricType, List<Record> records, DecisionTreeNode parentNode) {
		if (records == null) {
			records = this.records;
		}
		int recordNum = records.size();
		if (recordNum == 0 || records.get(0) == null || records.get(0).columns == null) return null;

		int totalNum = countTotalRecords(records);

		double maxGain = 0.0;
		double impurity = calcImpurity(impurityMetricType, records, totalNum);
		int nodeAttr = 0;
		String nodeValue = null;
		List<Record> nextLeft = null;
		List<Record> nextRight = null;
		Record record0 = records.get(0);

		for (int attr=1; attr<record0.columns.length; attr++) {
			List<String> attrValues = new ArrayList<String>();
			for (Record record : records) {
				String value = record.columns[attr];
				if (!attrValues.contains(value)) attrValues.add(value);
			}

			for (String value : attrValues) {
				Object[] subSets = divideSets(records, attr, value);
				List<Record> subSet0 = (List<Record>) subSets[0];
				List<Record> subSet1 = (List<Record>) subSets[1];
				int subSet0Size = countTotalRecords(subSet0);
				int subSet1Size = countTotalRecords(subSet1);

				double gain = 0;
				if (subSet0Size < totalNum) {
					double p = (double)subSet0Size / (double)totalNum;
					double ave = p*calcImpurity(impurityMetricType, subSet0, subSet0Size) + (1-p)*calcImpurity(impurityMetricType, subSet1, subSet1Size);
					gain = impurity - ave;
					if (gain > maxGain && !subSet0.isEmpty() && !subSet1.isEmpty()) {
						maxGain = gain;
						nodeAttr = attr;
						nodeValue = value;
						nextLeft = subSet0;
						nextRight = subSet1;
					}
				}
				// If there are only two values in an attr,
				// the second gain should be same as the first one.
				if (attrValues.size() == 2) break;
			}
		}

		DecisionTreeNode node = null;
		if (maxGain > 0.0) {
			node = new DecisionTreeNode(nodeAttr, nodeValue, parentNode, null, null, null, totalNum, impurityMetricType);
			node.left = grow(impurityMetricType, nextLeft, node);
			node.right = grow(impurityMetricType, nextRight, node);
			return node;
		}
		return new DecisionTreeNode(-1, null, null, null, null, countAttr(records, totalNum), totalNum, impurityMetricType);
	}

	public String classify(String[] attrs) {
		if (attrs == null || attrs.length == 0) return null;

		String[] record = new String[attrs.length+1];
		for (int i=0; i<attrs.length; i++) {
			String attr = attrs[i];
			record[i+1] = attr != null && attr instanceof String ? attr.toLowerCase() : attr;
		}
		return classify(this.tree, record);
	}

	private String classify(DecisionTreeNode tree, String[] record) {
		if (tree == null || record == null || record.length == 0) return null;

		if (tree.terminal != null) {
			return getMajorityLabelClass(tree.terminal);
		}

		String value = record[tree.attr];
		DecisionTreeNode branch = null;

		double valueNum = 0.0;
		if (value != null) {
			try {
				valueNum = Double.parseDouble(value);
				value = null;
			} catch (NumberFormatException e) {}
		}

		if (value != null) {
			branch = value.equals(tree.value) ? tree.left : tree.right;
		} else {
			branch = valueNum >= toNumber(tree.value) ? tree.left : tree.right;
		}
		return classify(branch, record);
	}

	// pessimistic pruning
	public DecisionTreeNode prune() {
		prune(this.tree, 0);
		return this.tree;
	}

	private void prune(DecisionTreeNode tree, int level) {
		if (tree == null) return;

		DecisionTreeNode left = tree.left, right = tree.right;
		if (left == null || right == null) return;

		// skip pruning due to too shallow
		if (level < 2) {
			prune(left, level+1);
			prune(right, level+1);
			return;
		}

		// compare static and backed-out errors
		double staticError = calcPruningError(tree);

		double backedUpError =
			(double)left.count/(double)tree.count * calcPruningError(left) + 
			(double)right.count/(double)tree.count * calcPruningError(right);

		if (staticError <= backedUpError) {
			tree.terminal = countAttr(getAllLabelClasses(tree));
			tree.left = null;
			tree.right = null;
		} else {
			prune(left, level+1);
			prune(right, level+1);
		}
	}

	public DecisionTreeNode pruneByMajority() {
		pruneByMajority(this.tree);
		return this.tree;
	}

	private void pruneByMajority(DecisionTreeNode tree) {
		if (tree == null) return;

		DecisionTreeNode left = tree.left, right = tree.right;
		if (left == null || right == null) return;

		boolean doPrune = false;
		if (left.terminal != null && right.terminal != null) {
			// check to see if majority class in both branches are same
			String leftLabel = getMajorityLabelClass(left.terminal);
			String rightLabel = getMajorityLabelClass(right.terminal);
			if (leftLabel != null && leftLabel.equals(rightLabel)) {
				doPrune = true;
			}
		}

		if (doPrune) {
			tree.terminal = countAttr(getAllLabelClasses(tree));
			tree.left = null;
			tree.right = null;
			pruneByMajority(tree.parent);
		} else {
			pruneByMajority(left);
			pruneByMajority(right);
		}
	}

	private double calcPruningError(DecisionTreeNode node) {
		if (node == null) return 0.0;

		final double PESS = 0.5; // pessimistic error constant
		int a = 0; // record count of majority value

		if (node.terminal != null) {
			for (Map.Entry<String, Integer> entry : node.terminal.entrySet()) {
				int count = entry.getValue().intValue();
				if (a < count) a = count;
			}
		} else {
			a = node.left.count;
		}

		// (a,b) : (N-a+0.5) / N
		return (double)(node.count - a + PESS) / (double)node.count;
	}

	private List<Record> getAllLabelClasses(DecisionTreeNode node) {
		return getAllLabelClasses(node, null);
	}

	private List<Record> getAllLabelClasses(DecisionTreeNode node, List<Record> records) {
		if (records == null) records = new ArrayList<Record>();
		if (node == null) return records;

		if (node.terminal == null) {
			getAllLabelClasses(node.left, records);
			getAllLabelClasses(node.right, records);
			return records;
		}

		for (Map.Entry<String, Integer> entry : node.terminal.entrySet()) {
			int count = entry.getValue().intValue();
			records.add(new Record(new String[]{entry.getKey()}, count));
		}
		return records;
	}

	private int countTotalRecords(List<Record> records) {
		if (records == null) return 0;
		int total = 0;
		for (Record record : records) {
			total += record.count;
		}
		return total;
	}

	private Object[] divideSets(List<Record> records, int attr, String value) {
		double valueNum = 0.0;
		if (value != null) {
			try {
				valueNum = Double.parseDouble(value);
				value = null;
			} catch (NumberFormatException e) {}
		}

		List<Record> set1 = new ArrayList<Record>();
		List<Record> set2 = new ArrayList<Record>();

		for (Record record : records) {
			boolean comp = value != null ? value.equals(record.columns[attr]) : toNumber(record.columns[attr]) >= valueNum;
			if (comp) {
				set1.add(record);
			} else {
				set2.add(record);
			}
		}
		return new Object[]{set1, set2};
	}

	private Map<String, Integer> countAttr(List<Record> records) {
		return countAttr(records, -1);
	}

	private Map<String, Integer> countAttr(List<Record> records, int totalNum) {
		Map<String, Integer> counts = new HashMap<String, Integer>();

		if (records == null) return counts;
		int recordsSize = records.size();
		if (recordsSize == 0 || records.get(0) == null) return counts;

		if (totalNum < 0) totalNum = countTotalRecords(records);

		for (Record record : records) {
			String key = record.columns[0];
			if (!counts.containsKey(key)) {
				counts.put(key, new Integer(record.count));
			} else {
				Integer countVal = counts.get(key);
				counts.put(key, new Integer(countVal.intValue()+record.count));
			}
		}
		return counts;
	}

	private double calcImpurity(char impurityMetricType, List<Record> records) {
		return calcImpurity(impurityMetricType, records, -1);
	}

	private double calcImpurity(char impurityMetricType, List<Record> records, int totalNum) {
		int recordsSize = records.size();
		if (recordsSize == 0) return 0.0;

		if (totalNum < 0) totalNum = countTotalRecords(records);

		boolean isGini = impurityMetricType == 'g' || impurityMetricType == 'G';
		double impurity = 0.0;
		Map<String, Integer> counts = countAttr(records, totalNum);

		if (isGini) {
			// Gini Index
			for (Map.Entry<String, Integer> entry : counts.entrySet()) {
				Integer count = entry.getValue();
				double p = (double)count.intValue() / (double)totalNum;
				impurity += p*p;
			}
		} else {
			// Entropy
			double LN2 = Math.log(2);
			for (Map.Entry<String, Integer> entry : counts.entrySet()) {
				Integer count = entry.getValue();
				double p = (double)count.intValue() / (double)totalNum;
				impurity += -p*(Math.log(p)/LN2);
			}
		}

		return isGini ? 1 - impurity : impurity;
	}

	private String getMajorityLabelClass(Map<String, Integer> terminal) {
		if (terminal == null) return null;

		String maxKey = null;
		int maxCount = 0;

		for (Map.Entry<String, Integer> entry : terminal.entrySet()) {
			Integer countVal = entry.getValue();
			if (maxCount < countVal.intValue()) {
				maxCount = countVal.intValue();
				maxKey = entry.getKey();
			}
		}
		return maxKey;
	}

	private double toNumber(String s) {
		if (s == null) return 0.0;
		try {
			return Double.parseDouble(s);
		} catch (NumberFormatException e) {}
		return 0.0;
	}

	// -------------------------
	// Inner Class
	// -------------------------

	private class Record {
		public String[] columns = null;
		public int count = 1;

		public Record(String[] record, int count) {
			if (record != null) {
				for (int i=0; i<record.length; i++) {
					if (record[i] != null) record[i] = record[i].toLowerCase();
				}
				this.columns = record;
			}

			if (count < 1) count = 1;
			this.count = count;
		}
	}

}
