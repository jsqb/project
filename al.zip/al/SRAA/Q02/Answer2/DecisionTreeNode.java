import java.util.*;

public class DecisionTreeNode implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public int attr; // attribute index number
	public String value; // attribute value to be compared
	public DecisionTreeNode parent;
	public DecisionTreeNode left;
	public DecisionTreeNode right;
	public Map<String, Integer> terminal;
	public int count; // num of records in this node

	// root properties
	public char impurityMetricType = ' '; // 'e':Entropy, 'g':Gini Index
	public long trainingErrorCount = 0;
	public long trainingTotal = 0;
	public double trainingErrorRate = 0.0;

	public DecisionTreeNode(int attr, String value, DecisionTreeNode parent, DecisionTreeNode left, DecisionTreeNode right, Map<String, Integer> terminal, int count, char impurityMetricType) {
		this.attr = attr;
		this.value = value;
		this.parent = parent;
		this.left = left;
		this.right = right;
		this.terminal = terminal;
		this.count = count;
		this.impurityMetricType = impurityMetricType;
	}

	public String toString() {
		return "{"+(this.parent==null ? "\"impurityMetricType\":\""+this.impurityMetricType+"\", " : "")+"\"attr\":"+this.attr+", \"value\":"+val(this.value)+", \"left\":"+this.left+", \"right\":"+this.right+", \"terminal\":"+val(this.terminal)+", \"count\":"+this.count+"}";
	}

	@SuppressWarnings("unchecked")
	private Object val(Object s) {
		if (s == null) return "null";
		if (s instanceof String) return isNumber((String)s) ? s : "\""+s+"\"";
		if (s instanceof Map) {
			StringBuffer sb = new StringBuffer();
			for (Map.Entry<String, Integer> entry : ((Map<String, Integer>)s).entrySet()) {
				if (sb.length() > 0) sb.append(",");
				sb.append("\""+entry.getKey()+"\":"+val(entry.getValue()));
			}
			return "{"+sb.toString()+"}";
		}
		return s;
	}

	private boolean isNumber(String s) {
		if (s == null) return false;
		try {
			Double.parseDouble(s);
			return true;
		} catch (NumberFormatException e) {}
		return false;
	}
}
