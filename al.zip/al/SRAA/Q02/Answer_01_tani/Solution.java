import java.util.Arrays;

public class Solution {
    public static final int[] DATA={
              0,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0,1,3,2,3
             ,2,4,0,3,1,2,3,4,0,1,3,2,3,4,0,3,1,2,3,4
             ,1,0,1,3,2,3,2,4,0,3,1,2,3,4,0,1,3,2,3,4
             ,0,3,1,2,3,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0
             ,1,3,2,3,0,4,0,3,1,2,3,4,0,1,3,2,3,1,4,0 };

    private int pages;
    private int[] data;
    private PagePredicton[] p;

    public Solution() {
            this(5, DATA);
    }

    public Solution(int pages,int[] data) {
        this.pages=pages;
        this.data=data;
        this.p=null;
    }

    public static class PagePredicton {
        int[] nextCount;

        public PagePredicton (int pages) {
            nextCount=new int[pages];
            Arrays.fill(nextCount,0);
        }

        public void addNextPage(int pageno) {
            nextCount[pageno]++;
        }

        public int getExpectedPage() {
            int max=0,index=-1;
            for(int i=0;i<nextCount.length;i++) {
                if (nextCount[i]>max) {
                    max=nextCount[i];
                    index=i;
                }
            }
            return index;
        }
    }

    public synchronized void createPrediction() {
        if (p==null) {
            p=new PagePredicton[pages];
            for (int i=0;i<pages;i++) {
                p[i]=new PagePredicton(pages);
            }
            for (int i=0;i<data.length-1;i++) {
                p[data[i]].addNextPage(data[i+1]);
            }
        }
    }

    public int solution(int N) {
        createPrediction();
        return p[N].getExpectedPage();
    }

    public static void main(String[] args) {
        Solution s=new Solution(5,DATA);
        for (int i=0;i<5;i++) {
            System.out.println("solve("+i+")="+s.solution(i));
        }
    }

}
