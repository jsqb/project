class Solution {

	int i = 0;
	int[] n = new int[100];
	public int solution(int N) {
		if (i< 100) n[i] = N;
		i++;
		return n[i % 100];
	}

}
