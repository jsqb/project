public class Test1 {

	private static int[] A = {
		 0,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0,1,3,2,3
		,2,4,0,3,1,2,3,4,0,1,3,2,3,4,0,3,1,2,3,4
		,1,0,1,3,2,3,2,4,0,3,1,2,3,4,0,1,3,2,3,4
		,0,3,1,2,3,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0
		,1,3,2,3,0,4,0,3,1,2,3,4,0,1,3,2,3,1,4,0
	};

	public static void main(String[] args) {
		int[] cur = new int[5];
		int[][] next = new int[5][5];
		int preId = 0;

		for (int i=0; i<A.length; i++) {
			cur[A[i]]++;
			if (i > 0) next[preId][A[i]]++;
			preId = A[i];
		}

		for (int i=0; i<cur.length; i++) {
			System.out.println("Page["+i+"]="+cur[i]);
		}

		for (int i=0; i<next.length; i++) {
			System.out.print("N["+i+"] ==> ");
			for (int j=0; j<next[i].length; j++) {
				System.out.print("["+j+"]("+next[i][j]+") ");
			}
			System.out.println();
		}
	}

}
