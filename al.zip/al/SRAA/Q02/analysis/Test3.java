public class Test3 {

	private static int[] A = {
		 0,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0,1,3,2,3
		,2,4,0,3,1,2,3,4,0,1,3,2,3,4,0,3,1,2,3,4
		,1,0,1,3,2,3,2,4,0,3,1,2,3,4,0,1,3,2,3,4
		,0,3,1,2,3,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0
		,1,3,2,3,0,4,0,3,1,2,3,4,0,1,3,2,3,1,4,0
	};

	private static int CYCLE = 13;

	public static void main(String[] args) {

		for (int i=0; i<A.length; i++) {
			if (i % CYCLE == 0) System.out.println();
			System.out.print(A[i]+", ");
		}
		System.out.println();
	}

}
