public class Test2 {

	private static int[] A = {
		 0,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0,1,3,2,3
		,2,4,0,3,1,2,3,4,0,1,3,2,3,4,0,3,1,2,3,4
		,1,0,1,3,2,3,2,4,0,3,1,2,3,4,0,1,3,2,3,4
		,0,3,1,2,3,4,2,0,1,3,2,3,4,0,3,1,2,3,4,0
		,1,3,2,3,0,4,0,3,1,2,3,4,0,1,3,2,3,1,4,0
	};

	public static void main(String[] args) {
		int N = A[0];
		int[] norms = new int[9];

		for (int i=1; i<A.length; i++) {
			int delta = A[i] - N;

			if (i % 10 == 0) System.out.println();
			System.out.print(delta+",");
			norms[delta+4]++;
			N = A[i];
		}
		System.out.println();

		for (int i=0; i<norms.length; i++) {
			int delta = i-4;
			System.out.print("["+delta+"]("+norms[i]+") ");
		}
		System.out.println();

	}

}
