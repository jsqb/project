public class Main {

	public static void main(String[] args) {
		Main exp = new Main();
		Solution ans = new Solution();

		int preY = 0, expScore = 0, ansScore = 0;
		int[] cnt = new int[5];

		for (int i=0, x=0; i<=10000; i++,x++) {
			int y = 0;
			switch (x % 4) {
				case 0: y = (preY + 1) % 5; break; // 25%
				case 2: y = (preY < 3) ? 3 : (int)(Math.random()*5); break; // 25%
				default: y = (3 * x + 1) % 5; break; // 50%
			}
			if (y == preY) {
				i--;
				continue;
			}
			cnt[y]++;

//if (i % 25 == 0) System.out.println();
//System.out.print(y+",");
			if (exp.solution(preY) == y) expScore++;
			if (ans.solution(preY) == y) ansScore++;
			preY = y;
		}
//System.out.println();

		System.out.println("Exp Score="+expScore);
		System.out.println("Ans Score="+ansScore);
		for (int i=0; i<cnt.length; i++) {
			System.out.println("Page["+i+"]="+cnt[i]);
		}
	}

	public int solution(int N) {
		//return (N + 1) % 5; // 51%
		return N != 3 ? 3 : 4; // 42%
		//return N != 3 ? 3 : (N + 1) % 5; // 42%
		//return 3; // 30%
		//return (int) (Math.random() * 5); // 20%
	}

}
