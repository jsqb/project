import java.util.*;

public class S3 {
    static interface MyList<E> {
        void add(E element);
        E get(int index);
        void clear();
    }

    static class ArrayMyList1<E> implements MyList<E> {
        ArrayList<E> a=new ArrayList<E>();
        public void add(E element) {a.add(element);}
        public E get(int index){return a.get(index);}
        public void clear() { a=new ArrayList<E>();}
    }

    static class ArrayMyList2<E> implements MyList<E> {
        ArrayList<E> a=new ArrayList<E>(1000000);
        public void add(E element) {a.add(element);}
        public E get(int index){return a.get(index);}
        public void clear() { a=new ArrayList<E>(1000000);}
    }

    static class ArrayMyList3<E> implements MyList<E> {
        Object[] a=new Object[1000000];
        int index=0;
        public void add(E element) {a[index++]=element;}
        public E get(int index){return (E)a[index];}
        public void clear() { a=new Object[1000000];index=0;}
    }


    static class LinkedMyList<E> implements MyList<E> {
        LinkedList<E> a=new LinkedList<E>();
        public void add(E element) {a.add(element);}
        public E get(int index){return a.get(index);}
        public void clear() {a=new LinkedList<E>();}
    }


    public static void main(String[] args) {
        String[] p=new String[1000000];
        for(int i=0;i<p.length;i++) {
            p[i]=String.valueOf(i);
        }
        bench(p,new ArrayMyList1<String>());
        bench(p,new ArrayMyList2<String>());
        bench(p,new ArrayMyList3<String>());
        //    bench(p,new LinkedMyList<String>());
        benchList(p,new ArrayList<String>(1000000));
    }

    public static void bench(String[] p, MyList<String> target) {
        long l=System.currentTimeMillis();
        for (int i=0;i<1000;i++ ) {
            target.clear();
            for (String s: p) { target.add(s);}
        }

        long l1=System.currentTimeMillis()-l;
        for (int i=0;i<1000000;i++) { String s=target.get(i);};
        long l2=System.currentTimeMillis()-l1-l;
        System.out.println("Target "+target.getClass().getName()+", Add="+l1+" , Get="+l2); 
    }

    public static void benchList(String[] p, List<String> target) {
        long l=System.currentTimeMillis();
        for (int i=0;i<1000;i++ ) {
            target.clear();
            for (String s: p) { target.add(s);}
        }

        long l1=System.currentTimeMillis()-l;
        for (int i=0;i<1000000;i++) { String s=target.get(i);};
        long l2=System.currentTimeMillis()-l1-l;
        System.out.println("Target "+target.getClass().getName()+", Add="+l1+" , Get="+l2); 
    }
}
