interface MyIntList {
    void add(int element);
    int get(int index);
}
