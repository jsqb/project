interface MyList<E> {
    void add(E element);
    E get(int index);

		// Added for Answer7
//    void addAll(E[] elements);
//    void addAll(MyList<E> list);
//    E[] getElements();
}
