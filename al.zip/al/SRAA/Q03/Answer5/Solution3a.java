class Solution3a implements MyIntList {
	private static final int MAX = 1000000;
	private static final String CAPACITY_EXCEEDED_MSG = "Exceeded capacity limit: "+MAX;
	private int[] elements;
	private int size = 0;

	public Solution3a() {
		elements = new int[10];
	}

	public int get(int index) {
		if (index >= size) {
			throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
		}
		return elements[index];
	}

	public void add(int element) {
		if (size >= MAX) throw new RuntimeException(CAPACITY_EXCEEDED_MSG);
		if (size == elements.length) resize();
		elements[size++] = element;
	}

	private void resize() {
		int[] copy = new int[Math.min(size + (size >> 1), MAX)];
		System.arraycopy(elements, 0, copy, 0, size);
		elements = copy;
	}

	private String outOfBoundsMsg(int index) {
		return "Index: "+index+", Size: "+size;
	}
}
