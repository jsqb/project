class Solution3<E> implements MyList<E> {
	private static final int MAX = 1000000;
	private static final String CAPACITY_EXCEEDED_MSG = "Exceeded capacity limit: "+MAX;
	private Object[][] elements;
	private int size = 0;

	public Solution3() {
		elements = new Object[1000][];
	}

	@SuppressWarnings("unchecked")
	public E get(int index) {
		if (index >= size) {
			throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
		}
		return (E) elements[index / 1000][index % 1000];
	}

	public void add(E element) {
		if (size >= MAX) throw new RuntimeException(CAPACITY_EXCEEDED_MSG);
		int mod = size % 1000;
		if (mod == 0) resize();
		elements[size / 1000][mod] = element;
		size++;
	}

	private void resize() {
		elements[size / 1000] = new Object[1000];
	}

	private String outOfBoundsMsg(int index) {
		return "Index: "+index+", Size: "+size;
	}
}
