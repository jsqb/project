class Solution3<E> implements MyList<E>{
	private static final int MAX = 1000000;
	private static final String CAPACITY_EXCEEDED_MSG = "Exceeded capacity limit: "+MAX;
	private Object[] elements;
	private int size = 0;

	public Solution3() {
		elements = new Object[MAX];
	}

	@SuppressWarnings("unchecked")
	public E get(int index) {
		if (index >= size) {
			throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
		}
		return (E) elements[index];
	}

	public void add(E element) {
		if (size >= MAX) throw new RuntimeException(CAPACITY_EXCEEDED_MSG);
		elements[size++] = element;
	}

	private String outOfBoundsMsg(int index) {
		return "Index: "+index+", Size: "+size;
	}
}
