import java.util.*;

public class Main_int {

	private static final int MAX = 1000000;

	public static void main(String[] args) throws Exception {
		int[] data = new int[MAX];
		for (int i=0; i<MAX; i++) data[i] = i;

		Solution3a s = new Solution3a();
		List<Integer> l = new ArrayList<Integer>();

		for (int i=0; i<MAX; i++) s.add(data[i]);
		try {
			s.add(-1); // dummy
			throw new Exception("(CapacityExceeded)Exception should be thrown.");
		} catch (Exception ex) {}

		Test.assertEquals(0, s.get(0));
		Test.assertEquals(1, s.get(1));
		Test.assertEquals(123, s.get(123));
		Test.assertEquals(1234, s.get(1234));
		Test.assertEquals(12345, s.get(12345));
		Test.assertEquals(999999, s.get(999999));
		try {
			Test.assertEquals(1000000, s.get(1000000));
			throw new Exception("IndexOutOfBoundsException should be thrown.");
		} catch (IndexOutOfBoundsException ex) {}

		for (int i=0; i<MAX; i++) l.add(data[i]);
		Test.assertEquals(0, l.get(0));
		Test.assertEquals(1, l.get(1));
		Test.assertEquals(123, l.get(123));
		Test.assertEquals(1234, l.get(1234));
		Test.assertEquals(12345, l.get(12345));
		Test.assertEquals(999999, l.get(999999));
		Test.printResults();

		// throw the 1st & 2nd results away
		for (int i=0; i<2; i++) {
			testAdd_Solution();
			testAdd_ArrayList();
		}

		long sum_s = 0, sum_a = 0;
		for (int i=0; i<100; i++) {
			sum_s += testAdd_Solution();
			sum_a += testAdd_ArrayList();
		}
		long diff = sum_a - sum_s;
		System.out.println("---------------");
		System.out.println("Solution  = "+sum_s);
		System.out.println("ArrayList = "+sum_a);
		System.out.println("[Add] A-S = "+diff+", "+((diff*100)/(double)sum_a)+"%");


		Solution3a list_s = new Solution3a();
		List<Integer> list_a = new ArrayList<Integer>();
		for (int i=0; i<MAX; i++) {
			list_s.add(i);
			list_a.add(i);
		}

		// throw the 1st & 2nd results away
		for (int i=0; i<2; i++) {
			testGet_Solution(list_s);
			testGet_ArrayList(list_a);
		}

		sum_s = sum_a = 0;
		for (int i=0; i<100; i++) {
			sum_s += testGet_Solution(list_s);
			sum_a += testGet_ArrayList(list_a);
		}
		diff = sum_a - sum_s;
		System.out.println("---------------");
		System.out.println("Solution  = "+sum_s);
		System.out.println("ArrayList = "+sum_a);
		System.out.println("[Get] A-S = "+diff+", "+((diff*100)/(double)sum_a)+"%");
	}

	private static long testAdd_Solution() {
		long st = System.currentTimeMillis();
		Solution3a l = new Solution3a();
		for (int i=0; i<MAX; i++) l.add(i);
		return System.currentTimeMillis() - st;
	}

	private static long testGet_Solution(Solution3a l) {
		long st = System.currentTimeMillis();
		for (int i=0; i<MAX; i++) l.get(i);
		return System.currentTimeMillis() - st;
	}

	private static long testAdd_ArrayList() {
		long st = System.currentTimeMillis();
		List<Integer> l = new ArrayList<Integer>();
		for (int i=0; i<MAX; i++) l.add(i);
		return System.currentTimeMillis() - st;
	}

	private static long testGet_ArrayList(List<Integer> l) {
		long st = System.currentTimeMillis();
		for (int i=0; i<MAX; i++) l.get(i);
		return System.currentTimeMillis() - st;
	}

}
