import java.util.*;

public class Main {

	private static final int MAX = 1000000;

	public static void main(String[] args) throws Exception {
		String[] data = new String[MAX];
		for (int i=0; i<MAX; i++) data[i] = i+"";

		MyList<String> s = new Solution3<String>();
		List<String> l = new ArrayList<String>();

		for (int i=0; i<MAX; i++) s.add(data[i]);
		try {
			s.add("dummy");
			throw new Exception("(CapacityExceeded)Exception should be thrown.");
		} catch (Exception ex) {}

		Test.assertEquals("0", s.get(0));
		Test.assertEquals("1", s.get(1));
		Test.assertEquals("123", s.get(123));
		Test.assertEquals("1234", s.get(1234));
		Test.assertEquals("12345", s.get(12345));
		Test.assertEquals("999999", s.get(999999));
		try {
			Test.assertEquals("1000000", s.get(1000000));
			throw new Exception("IndexOutOfBoundsException should be thrown.");
		} catch (IndexOutOfBoundsException ex) {}

		for (int i=0; i<MAX; i++) l.add(data[i]);
		Test.assertEquals("0", l.get(0));
		Test.assertEquals("1", l.get(1));
		Test.assertEquals("123", l.get(123));
		Test.assertEquals("1234", l.get(1234));
		Test.assertEquals("12345", l.get(12345));
		Test.assertEquals("999999", l.get(999999));
		Test.printResults();

		// ignore the 1st & 2nd results
		for (int i=0; i<2; i++) {
			testAdd_Solution(data);
			testAdd_ArrayList(data);
		}

		long sum_s = 0, sum_a = 0;
		for (int i=0; i<1000; i++) {
			sum_s += testAdd_Solution(data);
			sum_a += testAdd_ArrayList(data);
		}
		long diff = sum_a - sum_s;
		System.out.println("---------------");
		System.out.println("Solution  = "+sum_s);
		System.out.println("ArrayList = "+sum_a);
		System.out.println("[Add] A-S = "+diff+", "+((diff*100)/(double)sum_a)+"%");


		MyList<String> list_s = new Solution3<String>();
		List<String> list_a = new ArrayList<String>();
		for (int i=0; i<MAX; i++) {
			list_s.add(i+"");
			list_a.add(i+"");
		}

		// throw the 1st & 2nd results away
		for (int i=0; i<2; i++) {
			testGet_Solution(list_s);
			testGet_ArrayList(list_a);
		}

		sum_s = sum_a = 0;
		for (int i=0; i<100; i++) {
			sum_s += testGet_Solution(list_s);
			sum_a += testGet_ArrayList(list_a);
		}
		diff = sum_a - sum_s;
		System.out.println("---------------");
		System.out.println("Solution  = "+sum_s);
		System.out.println("ArrayList = "+sum_a);
		System.out.println("[Get] A-S = "+diff+", "+((diff*100)/(double)sum_a)+"%");
	}

	private static long testAdd_Solution(String[] data) {
		long st = System.currentTimeMillis();
		MyList<String> l = new Solution3<String>();
		for (int i=0; i<MAX; i++) l.add(data[i]);
		return System.currentTimeMillis() - st;
	}

	private static long testGet_Solution(MyList l) {
		long st = System.currentTimeMillis();
		for (int i=0; i<MAX; i++) l.get(i);
		return System.currentTimeMillis() - st;
	}

	private static long testAdd_ArrayList(String[] data) {
		long st = System.currentTimeMillis();
		List<String> l = new ArrayList<String>();
//		List<String> l = new ArrayList<String>(MAX);
		for (int i=0; i<MAX; i++) l.add(data[i]);
		return System.currentTimeMillis() - st;
	}

	private static long testGet_ArrayList(List<String> l) {
		long st = System.currentTimeMillis();
		for (int i=0; i<MAX; i++) l.get(i);
		return System.currentTimeMillis() - st;
	}

}
