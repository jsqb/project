class Solution3<E> implements MyList<E> {
	private static final int MAX = 1000000;
	private static final String CAPACITY_EXCEEDED_MSG = "Exceeded capacity limit: "+MAX;
	private Object[] elements;
	private int size = 0;

	public Solution3() {
		elements = new Object[10];
	}

	@SuppressWarnings("unchecked")
	public E get(int index) {
		if (index >= size) {
			throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
		}
		return (E) elements[index];
	}

	public void add(E element) {
		if (size >= MAX) throw new RuntimeException(CAPACITY_EXCEEDED_MSG);
		if (size == elements.length) resize();
		elements[size++] = element;
	}

	private void resize() {
		Object[] copy = new Object[Math.min(size << 1, MAX)];
		System.arraycopy(elements, 0, copy, 0, size);
		elements = copy;
	}

	private String outOfBoundsMsg(int index) {
		return "Index: "+index+", Size: "+size;
	}
}
