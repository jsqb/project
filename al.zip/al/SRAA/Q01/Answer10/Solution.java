class Solution {
	AreaFormula shapes = new Rectangle(new Triangle(null));
	public int solution(String S, int W, int H) {
		AreaFormula af = shapes;
		do {
			if (af.getClass().getSimpleName().equals(S)) {
				return af.calculate(W, H);
			}
		} while ((af = af.parent) != null);
		return -1;
	}
}

abstract class AreaFormula {
	AreaFormula parent;
	public AreaFormula(AreaFormula parent) { this.parent = parent; }
	abstract int calculate(int W, int H);
}

class Rectangle extends AreaFormula {
	public Rectangle(AreaFormula cause) { super(cause); }
	public int calculate(int W, int H) { return W * H; }
}

class Triangle extends AreaFormula {
	public Triangle(AreaFormula cause) { super(cause); }
	public int calculate(int W, int H) { return W * H / 2; }
}
