import java.lang.reflect.Method;
class Solution {
	public int solution(String S, int W, int H) {
		try {
			Method m = Solution.class.getMethod(
			           "calc"+S, Integer.TYPE, Integer.TYPE);
			return ((Integer) m.invoke(this, H, W)).intValue();
		} catch (Exception ex) {}
		return -1;
	}

	public int calcRectangle(int W, int H) { return W * H; }

	public int calcTriangle(int W, int H) { return W * H / 2; }
}
