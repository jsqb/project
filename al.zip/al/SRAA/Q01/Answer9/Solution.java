class Solution {
	public int solution(String S, int W, int H) {
		if (S == null) return -1;
		switch (S.length()) {
			case 1: return calculate1(W, H);
			case 2: return calculate2(W, H);
			case 3: return calculate3(W, H);
			case 4: return calculate4(W, H);
			case 5: return calculate5(W, H);
			case 6: return calculate6(W, H);
			case 7: return calculate7(W, H);
			case 8: return calculate8(W, H);
			case 9: return calculate9(W, H);
		}
		return -1;
	}

	int calculate1(int W, int H) { return -1; }
	int calculate2(int W, int H) { return -1; }
	int calculate3(int W, int H) { return -1; }
	int calculate4(int W, int H) { return -1; }
	int calculate5(int W, int H) { return -1; }
	int calculate6(int W, int H) { return -1; }
	int calculate7(int W, int H) { return -1; }
	int calculate8(int W, int H) { return W * H / 2; }
	int calculate9(int W, int H) { return W * H; }
}
