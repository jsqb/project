import java.util.ResourceBundle;
class Solution {
	public int solution(String S, int W, int H) {
		ResourceBundle bundle = ResourceBundle.getBundle("areaFormula");
		if (S != null && bundle.containsKey(S)) {
			return (int) (W * H * Double.parseDouble(bundle.getString(S)));
		}
		return -1;
	}
}
