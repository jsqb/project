import java.util.*;
class Solution {
	private static Map<String,AreaFormula> beans =
	        new HashMap<String,AreaFormula>();
	static {
		beans.put("Rectangle", (W, H) -> W * H);
		beans.put("Triangle",  (W, H) -> W * H / 2);
	}

	public int solution(String S, int W, int H) {
		AreaFormula af = beans.get(S);
		return af != null ? af.calculate(W, H) : -1;
	}
}

@FunctionalInterface
interface AreaFormula {
	int calculate(int W, int H);
}
