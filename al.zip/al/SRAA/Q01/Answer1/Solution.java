class Solution {
	public int solution(String S, int W, int H) {
		return calculate(S, W, H);
	}

	int calculate(String S, int W, int H) {
		if ("Rectangle".equals(S)) return calcRectangle(W, H);
		if ("Triangle".equals(S))  return calcTriangle(W, H);
		return -1;
	}

	int calcRectangle(int W, int H) {
		return W * H;
	}

	int calcTriangle(int W, int H) {
		return W * H / 2;
	}
}
