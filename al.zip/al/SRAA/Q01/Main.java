public class Main {
	public static void main(String[] args) {
		Solution s = new Solution();

		Test.assertEquals(12, s.solution("Triangle", 4, 6));
		Test.assertEquals(24, s.solution("Rectangle", 4, 6));
		Test.assertEquals(7, s.solution("Triangle", 5, 3));
		Test.assertEquals(-1, s.solution("Unknown", 5, 3));
		Test.assertEquals(-1, s.solution(null, 5, 3));

		Test.assertEquals(0, s.solution("Triangle", 1, 1));
		Test.assertEquals(1, s.solution("Rectangle", 1, 1));
		Test.assertEquals(50000000, s.solution("Triangle", 10000, 10000));
		Test.assertEquals(100000000, s.solution("Rectangle", 10000, 10000));
		Test.printResults();
	}

}
