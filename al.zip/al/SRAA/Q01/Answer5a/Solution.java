import java.util.*;
class Solution {
	private static Map<String,AreaFormula> beans =
	        new HashMap<String,AreaFormula>();
	static {
		beans.put("Rectangle", new Rectangle());
		beans.put("Triangle",  new Triangle());
	}

	public int solution(String S, int W, int H) {
		AreaFormula af = beans.get(S);
		return af != null ? af.calculate(W, H) : -1;
	}
}

interface AreaFormula { int calculate(int W, int H); }

class Rectangle implements AreaFormula {
	public int calculate(int W, int H) { return W * H; }
}

class Triangle implements AreaFormula {
	public int calculate(int W, int H) { return W * H / 2; }
}
