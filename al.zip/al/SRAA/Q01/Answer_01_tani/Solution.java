public class Solution {
	public static final Class[] SEARCH_METHOD_TYPE={int.class, int.class};

	public int solution(String S,int W, int H) {
		try {
			Integer result=
			  (Integer)this.getClass()
			  .getMethod(S,SEARCH_METHOD_TYPE)
			  .invoke(this,W,H);        
			return result.intValue();
		}catch(NoSuchMethodException e){
			// not existed method. returm -1
		}catch(Exception e) {
			// The others will not happen.
			e.printStackTrace();
		}
		return -1;
	}

	public int Rectangle(int W,int H) { return W*H;}
	public int Triangle(int W,int H) { return W*H/2;}
	//public int Rhombus(int W,int H) { return W*H/2;}
	//public int Oval(int W,int H) { return (int)(Math.PI*(double)W*(double)H/4.0);}    

	public static void main(String[] args) {
		Solution s2=new Solution();
		System.out.println(s2.solution("Rectangle",3,5));
		System.out.println(s2.solution("Triangle",3,5));
		System.out.println(s2.solution("Rhombus",3,5));
		System.out.println(s2.solution("Oval",3,5));
		System.out.println(s2.solution("solution",3,5));
	}
}
