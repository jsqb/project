import java.lang.annotation.*;
import java.lang.reflect.Method;
class Solution {
	public int solution(String S, int W, int H) {
		for (Method m : Solution.class.getDeclaredMethods()) {
			AreaFormula af = m.getAnnotation(AreaFormula.class);
			if (af != null && af.value().equals(S)) {
				try {
					return ((Integer) m.invoke(this, H, W)).intValue();
				} catch (Exception ex) {}
			}
		}
		return -1;
	}

	@Retention(RetentionPolicy.RUNTIME)
	@Target(ElementType.METHOD)
	@interface AreaFormula { String value(); }

	@AreaFormula("Rectangle")
	int rectangle(int W, int H) { return W * H; }

	@AreaFormula("Triangle")
	int triangle(int W, int H) { return W * H / 2; }
}
