import java.util.ResourceBundle;
import javax.script.*;
class Solution {
	public int solution(String S, int W, int H) {
		ResourceBundle bundle = ResourceBundle.getBundle("areaFormula");
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("js");

		if (S != null && bundle.containsKey(S)) {
			Bindings bindings = engine.createBindings();
			bindings.put("W", W);
			bindings.put("H", H);
			try {
				return (int) ((Double) engine.eval(
				       bundle.getString(S), bindings)).doubleValue();
			} catch (ScriptException ex) {}
		}
		return -1;
	}
}
