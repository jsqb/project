class Solution {
	public int solution(String S, int W, int H) {
		try {
			AreaFormula af = Class.forName(S)
			                .asSubclass(AreaFormula.class)
			                .newInstance();
			return af.calculate(W, H);
		} catch (Exception ex) {}
		return -1;
	}
}

interface AreaFormula { int calculate(int W, int H); }

class Rectangle implements AreaFormula {
	public int calculate(int W, int H) { return W * H; }
}

class Triangle implements AreaFormula {
	public int calculate(int W, int H) { return W * H / 2; }
}
