public class DiceRollImpl implements DiceRoll {
	public int d6() {
		return (int) (Math.random() * 6) + 1;
	}
}
