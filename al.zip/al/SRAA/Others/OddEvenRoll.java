public class OddEvenRoll implements DiceRoll {
	private boolean isOdd = false;
	public int d6() {
		isOdd = !isOdd;
		int n = ((int)(Math.random() * 3)) * 2 + 1;
		return isOdd ? n : n+1;
	}
}
