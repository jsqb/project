public class CheatDiceRoll6 implements DiceRoll {
	public int d6() {
		return 6;
	}
}
