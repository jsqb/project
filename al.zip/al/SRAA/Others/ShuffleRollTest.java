public class ShuffleRollTest {

	public static void main(String[] args) {
		System.out.println("Result: "+testShuffled(new ShuffledRoll()));
	}

	private static boolean testShuffled(DiceRoll dr) {
		return testUniform(dr) && testChiSquare(dr);
	}

	private static boolean testUniform(DiceRoll dr) {
		final int MAX = 6000;
		final int EXPECTED = MAX / 6;
		int[] nums = new int[6];

		for (int i=0; i<MAX; i++) {
			nums[dr.d6()-1]++;
		}

		for (int i=0; i<6; i++) {
			if (nums[i] != EXPECTED) return false;
		}
		return true;
	}

	private static boolean testChiSquare(DiceRoll dr) {
		final int MAX = 6000;
		final double expected = MAX / 6.0 / 6.0;
		int[][] nums = new int[6][6];

		for (int i=0; i<MAX; i++) {
			nums[i % 6][dr.d6()-1]++;
		}

		for (int i=0; i<6; i++) {
			double xs = 0.0;
			for (int j=0; j<6; j++) {
				xs += ((nums[i][j]-expected) * (nums[i][j]-expected)) / expected;
			}
			if (xs > 11.071) return false; // error rate 5% (n=5)
		}
		return true;
	}

}
