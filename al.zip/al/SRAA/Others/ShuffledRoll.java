public class ShuffledRoll implements DiceRoll {
	private int count = 5;
	private int[] nums = new int[]{1,2,3,4,5,6};

	public int d6() {
		if (++count > 5) {
			count = 0;
			shuffle(nums);
		}
		return nums[count];
	}

	private void shuffle(int[] nums) {
		for (int i=0, len=nums.length; i<len; i++) {
			int dest = (int) (Math.random() * (i+1));
			int tmp = nums[i];
			nums[i] = nums[dest];
			nums[dest] = tmp;
		}
	}
}
