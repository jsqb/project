public interface DiceRoll {
	int d6();
}