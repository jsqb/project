import java.util.*;

public class DiceRollTest {

	public static void main(String[] args) {
		System.out.println("DiceRollImpl: "+testDiceRoll(new DiceRollImpl()));
		System.out.println("CheatDiceRoll6: "+testDiceRoll(new CheatDiceRoll6()));
		System.out.println("FizzBuzzRoll: "+testDiceRoll(new FizzBuzzRoll()));
		System.out.println("ShuffledRoll: "+testDiceRoll(new ShuffledRoll()));
		System.out.println("OddEvenRoll: "+testDiceRoll(new OddEvenRoll()));
	}

	private static boolean testDiceRoll(DiceRoll dr) {
		boolean chiSquare1 = testChiSquare1(dr);
		boolean chiSquare2 = testChiSquare2(dr);
//		boolean pokerTest  = testPoker(dr);

		System.out.println("Chi-square 1 = "+chiSquare1);
		System.out.println("Chi-square 2 = "+chiSquare2);
//		System.out.println("Poker Test   = "+pokerTest);

//		return chiSquare1 && chiSquare2 && pokerTest;
		return chiSquare1 && chiSquare2;
	}

	private static boolean testChiSquare1(DiceRoll dr) {
		final int MAX = 60000;
		int[] nums = new int[6];
		final double expected = MAX / 6.0;

		for (int i=0; i<MAX; i++) {
			nums[dr.d6()-1]++;
		}

		double xs = 0.0;
		for (int i=0; i<6; i++) {
			xs += ((nums[i]-expected) * (nums[i]-expected)) / expected;
		}
		return xs <= 11.071; // error rate 5% (n=5)
	}

	private static boolean testChiSquare2(DiceRoll dr) {
		final int MAX = 60000;
		int[][] nums = new int[6][6];
		final double expected = MAX / 6.0 / 6.0;

		for (int i=0; i<MAX; i++) {
			nums[i % 6][dr.d6()-1]++;
		}

		for (int i=0; i<6; i++) {
			double xs = 0.0;
			for (int j=0; j<6; j++) {
				xs += ((nums[i][j]-expected) * (nums[i][j]-expected)) / expected;
			}
			if (xs > 11.071) return false; // error rate 5% (n=5)
		}
		return true;
	}

/*
	private static final double[] PROB = {
		0.3024, 0.5040, 0.1080, 0.0720, 0.0090, 0.0045, 0.0001
	};
	private static boolean testPoker(DiceRoll dr) {
		final int N = 1000000;
		int[] f  = new int[PROB.length];
		int[] f0 = new int[PROB.length];

		for (int i=0; i<f0.length; i++) {
			f0[i] = (int) (PROB[i] * N);
		}

		for (int i=0; i<N; i++) {
			int[] nums = new int[5];
			for (int j=0; j<5; j++) nums[j] = dr.d6();

			int count = 0;
			for (int j=0; j<4; j++) {
				for (int k=j+1; k<5; k++) {
					if (nums[j] == nums[k]) count++;
				}
			}

			int index = 0; // index of probabilities
			if (count == 10) {
				index = 6;
			} else if (count == 6) {
				index = 5;
			} else {
				index = count;
			}

			f[index]++;
		}

		double xs = 0.0;
		for (int i=0; i<f.length; i++) {
			System.out.println("f["+i+"]=("+f[i]+") f0["+i+"]=("+f0[i]+")");
			xs += ((f[i] - f0[i]) * (f[i] - f0[i])) / (double) f0[i];
		}

		System.out.println("xs = "+xs);
		return xs > 12.592; // error rate 5% (n=6)
	}
*/
}
