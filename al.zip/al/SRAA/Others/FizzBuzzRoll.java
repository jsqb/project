public class FizzBuzzRoll implements DiceRoll {
	private long count = 0;

	public int d6() {
		boolean isDivBy3 = count % 3 == 0,
		        isDivBy5 = (count++) % 5 == 0;

		if (isDivBy3 && isDivBy5) {
			return ((int)(Math.random() * 2)) * 2 + 3; // 3 or 5
		} else if (isDivBy3) {
			return 3; // 3
		} else if (isDivBy5) {
			return 5; // 5
		}

		int n = ((int)(Math.random() * 4)) * 2;
		return n == 0 ? n+1 : n; // 1,2,4 or 6
	}
}
