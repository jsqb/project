class Solution4 {

	public int solution(int N) {
		return walk(N, 0, 0, 0, "");
	}

	private static int walk(final int N, int comb, int sum, int n0, String s) {
		if (n0 == 9) {
if (sum == N) System.out.println(s);
return sum == N ? comb+1 : comb;
}

		n0++;
		comb = walk(N, comb, sum+n0, n0, s+"+"+n0);
		comb = walk(N, comb, sum-n0, n0, s+"-"+n0);
		return comb;
	}

}
