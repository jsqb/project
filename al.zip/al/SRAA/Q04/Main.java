public class Main {

	public static void main(String[] args) {
		Solution4 s = new Solution4();
/*
		Test.assertEquals(12, s.solution(1));
		Test.assertEquals(0, s.solution(2));
		Test.assertEquals(11, s.solution(3));
		Test.assertEquals(0, s.solution(4));
		Test.assertEquals(12, s.solution(5));
		Test.assertEquals(0, s.solution(6));
		Test.assertEquals(10, s.solution(7));
		Test.assertEquals(0, s.solution(8));
		Test.assertEquals(11, s.solution(9));
		Test.assertEquals(0, s.solution(10));
		Test.assertEquals(10, s.solution(11));
		Test.assertEquals(0, s.solution(12));
		Test.assertEquals(9, s.solution(13));
*/
		Test.assertEquals(19, s.solution(-11));
		Test.assertEquals(21, s.solution(-9));
		Test.assertEquals(21, s.solution(-7));
		Test.assertEquals(22, s.solution(-5));
		Test.assertEquals(23, s.solution(-3));
		Test.assertEquals(23, s.solution(-1));
		Test.assertEquals(0, s.solution(0));
		Test.assertEquals(23, s.solution(1));
		Test.assertEquals(23, s.solution(3));
		Test.assertEquals(22, s.solution(5));
		Test.assertEquals(21, s.solution(7));
		Test.assertEquals(21, s.solution(9));
		Test.assertEquals(19, s.solution(11));
		Test.assertEquals(5, s.solution(31));
		Test.assertEquals(4, s.solution(33));
		Test.assertEquals(3, s.solution(35));
		Test.assertEquals(2, s.solution(37));
		Test.printResults();
	}

}
