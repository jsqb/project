// divide and conquer algorithm
import java.util.*;
class Solution4 {

	public int solution(int N) {
		// <sum value, frequency>
		Map<Integer,Integer> leftSums = new HashMap<Integer,Integer>(),
		                    rightSums = new HashMap<Integer,Integer>();
		// left side (1 to 5)
		walk(leftSums, 1, 1, 5);
		walk(leftSums, -1, 1, 5);

		// right side (6 to 9)
		walk(rightSums, 6, 6, 9);
		walk(rightSums, -6, 6, 9);

		int count = 0;
		for (Map.Entry<Integer,Integer> leftEnt : leftSums.entrySet()) {
			int leftNum = leftEnt.getKey();
			int leftFrq = leftEnt.getValue();

			for (Map.Entry<Integer,Integer> rightEnt : rightSums.entrySet()) {
				int rightNum = rightEnt.getKey();
				int rightFrq = rightEnt.getValue();

				if (leftNum + rightNum == N) {
					count += leftFrq * rightFrq;
				}
			}
		}
		return count;
	}

	private static void walk(Map<Integer,Integer> sums, int sum, int ns, int ne) {
		if (ns == ne) {
			if (sums.containsKey(sum)) {
				sums.put(sum, sums.get(sum).intValue()+1);
			} else {
				sums.put(sum, 1);
			}
			return;
		}

		ns++;
		walk(sums, sum+ns, ns, ne);
		walk(sums, sum-ns, ns, ne);
	}
}
