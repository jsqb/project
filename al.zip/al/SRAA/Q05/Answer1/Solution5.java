import java.util.*;
class Solution5 {
	private static final int[][] MOVE = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

	public int solution(String[] S) {
		final int H = S.length, W = S[0].length();
		boolean[][] map = new boolean[H][W];
		for (int y=0; y<H; y++) {
			for (int x=0; x<W; x++) {
				map[y][x] = S[y].charAt(x) == '#';
			}
		}

		Queue<Node> q = new LinkedList<Node>();
		q.offer(new Node(0, 0, 1));
		map[0][0] = true;

		while (!q.isEmpty()) {
			Node n = q.poll();
			if (n.y == map.length-1) return n.steps;

			map[n.y][n.x] = true;

			for (int i=0; i<4; i++) {
				int nx = n.x+MOVE[i][0],
				    ny = n.y+MOVE[i][1];
				if (nx >= 0 && nx < map[0].length &&
				    ny >= 0 && ny < map.length && !map[ny][nx]) {
					q.offer(new Node(nx, ny, n.steps+1));
				}
			}
		}
		return -1;
	}

	private static class Node {
		int x, y, steps = 0;

		public Node(int x, int y, int steps) {
			this.x = x;
			this.y = y;
			this.steps = steps;
		}
	}
}
