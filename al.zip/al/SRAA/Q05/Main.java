public class Main {

	public static void main(String[] args) {
		Solution5 s = new Solution5();

		Test.assertEquals(4, s.solution(new String[]{
			".##",
			"...",
			"#.#"}));

		Test.assertEquals(9, s.solution(new String[]{
			".#...",
			"...#.",
			"##.#.",
			"...#.",
			".###."}));

		Test.assertEquals(18, s.solution(new String[]{
			".#...#",
			"...#.#",
			".###..",
			".####.",
			"....#.",
			"###.#.",
			"....#.",
			".###..",
			".....#",
			"####.#"}));

		Test.printResults();
	}

}
